namespace Supercell.Laser.Server.Logic.Game
{
    public class LeaderboardEntry
    {
        public string Name { get; set; }
        public int Trophies { get; set; }
        public long AccountId { get; set; }
    }
}