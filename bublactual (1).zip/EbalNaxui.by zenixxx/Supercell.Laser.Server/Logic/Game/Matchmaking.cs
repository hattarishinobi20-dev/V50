namespace Supercell.Laser.Server.Logic.Game
{
    using Masuda.Net;
    using Supercell.Laser.Logic.Battle;
    using Supercell.Laser.Logic.Battle.Structures;
    using Supercell.Laser.Logic.Data;
    using Supercell.Laser.Logic.Home.Items;
    using Supercell.Laser.Logic.Listener;
    using Supercell.Laser.Logic.Message.Battle;
    using Supercell.Laser.Logic.Message.Home;
    using Supercell.Laser.Logic.Team;
    using Supercell.Laser.Logic.Util;
    using Supercell.Laser.Server.Networking;
    using Supercell.Laser.Server.Networking.Session;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;
    using System.Threading;
    using Supercell.Laser.Logic.Command.Home;
    using Supercell.Laser.Logic.Notification;

    public static class Matchmaking
    {
        private static Dictionary<int, MatchmakingSlot> Slots;
        private static Thread UpdateThread;

        public static void Init()
        {
            Slots = new Dictionary<int, MatchmakingSlot>();

            foreach (EventData e in Events.GetEvents())
            {
                if (e.Location == null) continue;
                int mode = GameModeUtil.GetGameModeVariation(e.Location.GameModeVariation);
                Slots.Add(e.Slot, new MatchmakingSlot(e, GamePlayUtil.GetPlayerCountWithGameModeVariation(mode))); // players count
            }

            UpdateThread = new Thread(Update);
            UpdateThread.Start();
        }

        private static void Update()
        {
            while (true)
            {
                foreach (MatchmakingSlot slot in Slots.Values)
                {
                    slot.Update();
                }
                Thread.Sleep(250);
            }
        }

        public static void RequestMatchmake(Connection connection, int slot, long team = -1)
        {
            if (!Slots.ContainsKey(slot)) return;

            // Получаем EventData для текущего слота
            var eventData = Events.GetEvent(slot);
            int gameModeVariation = 0;
            if (eventData != null && eventData.Location != null)
                gameModeVariation = GameModeUtil.GetGameModeVariation(eventData.Location.GameModeVariation);

            // Если Solo Showdown и игрок в команде — разделяем команду на соло-игроков
            if (gameModeVariation == 6 && team > 0)
            {
                TeamEntry teamEntry = Teams.Get(team);
                if (teamEntry != null)
                {
                    long groupId = DateTime.UtcNow.Ticks + teamEntry.Id;
                    foreach (var member in teamEntry.Members)
                    {
                        Session session = Sessions.GetSession(member.AccountId);
                        if (session != null && session.Connection != null)
                        {
                            session.Connection.MatchmakeSlot = slot;
                            MatchmakingEntry soloEntry = new MatchmakingEntry(session.Connection);
                            soloEntry.PlayerTeamId = 0; // Соло!
                            soloEntry.GroupId = groupId;
                            session.Connection.MatchmakingEntry = soloEntry;
                            Slots[slot].Add(soloEntry);
                        }
                    }
                }
                return;
            }

            // Обычная логика для других режимов
            connection.MatchmakeSlot = slot;
            MatchmakingEntry entry = new MatchmakingEntry(connection);
            entry.PlayerTeamId = team;
            connection.MatchmakingEntry = entry;
            Slots[slot].Add(entry);
        }

        public static void CancelMatchmake(Connection connection)
        {
            if (connection == null)
                return;

            int slot = connection.MatchmakeSlot;
            if (Slots != null && Slots.ContainsKey(slot))
            {
                connection.MatchmakeSlot = -1;
                if (connection.MatchmakingEntry != null)
                    Slots[slot].Remove(connection.MatchmakingEntry);

                if (connection.MatchmakingEntry != null && connection.MatchmakingEntry.PlayerTeamId > 0)
                {
                    TeamEntry team = Teams.Get(connection.MatchmakingEntry.PlayerTeamId);
                    if (team != null)
                    {
                        foreach (TeamMember member in team.Members)
                        {
                            member.IsReady = false;
                            Session session = Sessions.GetSession(member.AccountId);
                            if (session != null && session.Connection != null && session.Connection.MatchmakingEntry != null)
                            {
                                session.Connection.MatchmakingEntry.PlayerTeamId = -1;
                                CancelMatchmake(session.Connection);
                                MatchMakingCancelledMessage cancelled = new MatchMakingCancelledMessage();
                                session.Connection.Send(cancelled);
                            }
                        }
                        team.TeamUpdated();
                    }
                }
            }
        }
    }

    public class MatchmakingSlot
    {
        private Queue<MatchmakingEntry> RequestQueue;
        private Queue<MatchmakingEntry> RemoveQueue;

        private List<MatchmakingEntry> Queue;

        private int PlayersRequired;
        private EventData EventData;

        public int SecondsLeft;
        private int Turns;

        public const int SEARCH_TIMEOUT = 10;

        public MatchmakingSlot(EventData eventData, int playersRequired)
        {
            PlayersRequired = playersRequired;
            if (GameModeUtil.GetGameModeVariation(eventData.Location.GameModeVariation) == 30)
            {
                PlayersRequired = 1;
            }
            EventData = eventData;
            Queue = new List<MatchmakingEntry>();

            RequestQueue = new Queue<MatchmakingEntry>();
            RemoveQueue = new Queue<MatchmakingEntry>();

            SecondsLeft = SEARCH_TIMEOUT;
        }

        public void Update()
        {
            //try
            {


                if (Sessions.Maintenance) return;

                foreach (MatchmakingEntry entry in Queue)
                {
                    if (!entry.Connection.IsOpen) Remove(entry);
                }

                if (EventData.Slot == 5)
                {
                    LogicAddNotificationCommand logicAddNotificationCommand = new LogicAddNotificationCommand();
                    logicAddNotificationCommand.Notification = new FloaterTextNotification("Sorry, this gamemode unavailable\nTry another gamemode");
                    AvailableServerCommandMessage availableServerCommandMessage = new AvailableServerCommandMessage();
                    availableServerCommandMessage.Command = logicAddNotificationCommand;
                    foreach (MatchmakingEntry member in Queue)
                    {
                        member.Connection.Home.HomeMode.GameListener.SendMessage(availableServerCommandMessage);
                        member.Connection.Home.HomeMode.GameListener.SendMessage(new MatchMakingCancelledMessage());
                        Remove(member);
                    }
                }

                while (RemoveQueue.Count > 0)
                {
                    Queue.Remove(RemoveQueue.Dequeue());
                }

                while (RequestQueue.Count > 0)
                {
                    MatchmakingEntry entry = RequestQueue.Dequeue();
                    MatchmakingEntry check = Queue.Find(x => x.Connection == entry.Connection);
                    if (check != null) continue;

                    Queue.Add(entry);
                }

                // Проверяем, можем ли мы начать игру с правильным распределением команд
                if (Queue.Count >= PlayersRequired)
                {
                    List<MatchmakingEntry> playersToStart = new List<MatchmakingEntry>();
                    
                    if (GameModeUtil.HasTwoTeams(GameModeUtil.GetGameModeVariation(EventData.Location.GameModeVariation)))
                    {
                        // Для режимов с двумя командами группируем игроков правильно
                        Dictionary<long, List<MatchmakingEntry>> teamGroups = new Dictionary<long, List<MatchmakingEntry>>();
                        List<MatchmakingEntry> soloPlayers = new List<MatchmakingEntry>();

                        // Разделяем игроков на команды и соло
                        foreach (MatchmakingEntry entry in Queue)
                        {
                            if (entry.PlayerTeamId > 0)
                            {
                                if (!teamGroups.ContainsKey(entry.PlayerTeamId))
                                {
                                    teamGroups[entry.PlayerTeamId] = new List<MatchmakingEntry>();
                                }
                                teamGroups[entry.PlayerTeamId].Add(entry);
                            }
                            else
                            {
                                soloPlayers.Add(entry);
                            }
                        }

                        // Проверяем, можем ли мы создать сбалансированные команды
                        int totalTeamPlayers = teamGroups.Values.Sum(team => team.Count);
                        int totalPlayers = totalTeamPlayers + soloPlayers.Count;

                        if (totalPlayers >= 6) // Нужно минимум 6 игроков для 3v3
                        {
                            // Берем игроков для старта игры (максимум 6)
                            List<MatchmakingEntry> team1 = new List<MatchmakingEntry>();
                            List<MatchmakingEntry> team2 = new List<MatchmakingEntry>();

                            // Распределяем команды (максимум 3 игрока в каждой)
                            foreach (var teamGroup in teamGroups.Values)
                            {
                                if (team1.Count + teamGroup.Count <= 3)
                                {
                                    team1.AddRange(teamGroup);
                                }
                                else if (team2.Count + teamGroup.Count <= 3)
                                {
                                    team2.AddRange(teamGroup);
                                }
                                // Если обе команды заполнены, игнорируем эту группу
                            }

                            // Добавляем соло игроков (до 3 в каждой команде)
                            foreach (var soloPlayer in soloPlayers)
                            {
                                if (team1.Count < 3)
                                {
                                    team1.Add(soloPlayer);
                                }
                                else if (team2.Count < 3)
                                {
                                    team2.Add(soloPlayer);
                                }
                                // Если обе команды заполнены, игнорируем этого игрока
                            }

                            // Если получилось создать две команды с игроками
                            if (team1.Count > 0 && team2.Count > 0)
                            {
                                playersToStart.AddRange(team1);
                                playersToStart.AddRange(team2);
                                
                                // Удаляем игроков из очереди
                                foreach (var player in playersToStart)
                                {
                                    Queue.Remove(player);
                                }
                                
                                StartGame(playersToStart);
                            }
                        }
                    }
                    else
                    {
                        // Для других режимов используем старую логику
                        playersToStart = Queue.Take(PlayersRequired).ToList();
                        Queue.RemoveRange(0, PlayersRequired);
                        StartGame(playersToStart);
                    }
                }

                if (Queue.Count > 0 && Queue.Count < PlayersRequired && SecondsLeft <= 0)
                {
                    SecondsLeft = SEARCH_TIMEOUT;
                    StartGame(Queue.Take(Queue.Count).ToList());
                    Queue.RemoveRange(0, Queue.Count);
                }

                if (Queue.Count > 0)
                {
                    Turns++;
                    if (Turns >= 4)
                    {
                        Turns = 0;
                        SecondsLeft--;
                    }
                }
                else
                {
                    Turns = 0;
                    SecondsLeft = SEARCH_TIMEOUT;
                }

                if (Queue.Count > 0)
                {
                    MatchMakingStatusMessage message = new MatchMakingStatusMessage();

                    message.Seconds = SecondsLeft;
                    message.Found = Queue.Count;
                    message.Max = PlayersRequired;
                    message.ShowTips = true;

                    foreach (MatchmakingEntry entry in Queue)
                    {
                        entry.Connection.Messaging.Send(message);
                    }
                }
            } //finally
            {
                //    Console.WriteLine("GameMatchmakingManager exception!");
                //    Console.WriteLine($"{e.GetType().Name}, {e.Message}\n{e.StackTrace}");
            }
        }

        public void Remove(MatchmakingEntry entry)
        {
            RemoveQueue.Enqueue(entry);
        }

        public void Add(MatchmakingEntry entry)
        {
            RequestQueue.Enqueue(entry);
        }

        public static readonly int[] botBrawlers = { 1,2,3,4,5,6,9,10 }; // Allowed
        

        public void StartGame(List<MatchmakingEntry> entries)
        {
            // The battle inits here
            // TODO: Merge it to BattleManager or smth..

            //BattleMode battle = new BattleMode(EventData.LocationId);
            BattleMode battle = new BattleMode(EventData.LocationId);
            battle.Id = Battles.Add(battle);

            Random rand = new Random();

            List<MatchmakingEntry> sortedEntries = new List<MatchmakingEntry>();

            if (battle.GetGameModeVariation() == 7)
            {
                sortedEntries = entries;
                for (int i = 0; i < entries.Count; i++)
                {
                    UDPSocket socket = UDPGateway.CreateSocket();
                    socket.TCPConnection = sortedEntries[i].Connection;
                    socket.Battle = battle;
                    sortedEntries[i].Connection.UdpSessionId = socket.SessionId;
                    BattlePlayer player = BattlePlayer.Create(sortedEntries[i].Connection.Home, sortedEntries[i].Connection.Avatar, i, 0);
                    player.TeamId = sortedEntries[i].PlayerTeamId;
                    sortedEntries[i].Player = player;
                    player.HeroPowerLevel = 9;
                    battle.AddPlayer(player, sortedEntries[i].Connection.UdpSessionId);
                }

                List<int> team1BotsCharacters = new List<int>();
                List<int> team2BotsCharacters = new List<int>();

                for (int i = sortedEntries.Count; i < battle.GetPlayersCountWithGameModeVariation(); i++)
                {
                    bool isBotValid = false;

                    int botCharacter = -1;
                    while (!isBotValid)
                    {
                        botCharacter = 16000000 + botBrawlers[rand.Next(0, botBrawlers.Length)];
                        if (i % 2 == 0)
                        {
                            isBotValid = !team1BotsCharacters.Contains(botCharacter);
                        }
                        else
                        {
                            isBotValid = !team2BotsCharacters.Contains(botCharacter);
                        }
                        if (!isBotValid) isBotValid = !GameModeUtil.HasTwoTeams(battle.GetGameModeVariation());
                    }

                    int teamIndex = 0;
                    if (battle.GetTeamPlayersCount(teamIndex) >= 5)
                    {
                        if (teamIndex == 1) teamIndex = 0;
                        else teamIndex = 1;
                    }

                    if (teamIndex == 0)
                    {
                        team1BotsCharacters.Add(botCharacter);
                    }
                    else
                    {
                        team2BotsCharacters.Add(botCharacter);
                    }
                    CharacterData data = DataTables.Get(16).GetDataByGlobalId<CharacterData>(botCharacter);
                    BattlePlayer bot = BattlePlayer.CreateBotInfo((i - sortedEntries.Count + 1).ToString(), i, teamIndex, botCharacter);
                    if (teamIndex == 1)
                    {
                        bot.HeroPowerLevel = 400;
                    }
                    battle.AddPlayer(bot, -1);
                }
            }
            else if (GameModeUtil.HasTwoTeams(battle.GetGameModeVariation()))
            {
                // Сначала группируем игроков по командам
                Dictionary<long, List<MatchmakingEntry>> teamEntries = new Dictionary<long, List<MatchmakingEntry>>();
                List<MatchmakingEntry> soloPlayers = new List<MatchmakingEntry>();

                // Разделяем игроков на команды и соло игроков
                foreach (MatchmakingEntry entry in entries)
                {
                    if (entry.PlayerTeamId > 0)
                    {
                        if (!teamEntries.ContainsKey(entry.PlayerTeamId))
                        {
                            teamEntries[entry.PlayerTeamId] = new List<MatchmakingEntry>();
                        }
                        teamEntries[entry.PlayerTeamId].Add(entry);
                    }
                    else
                    {
                        soloPlayers.Add(entry);
                    }
                }

                // Создаем две команды
                List<MatchmakingEntry> team1 = new List<MatchmakingEntry>();
                List<MatchmakingEntry> team2 = new List<MatchmakingEntry>();

                // Сначала распределяем команды игроков
                foreach (var teamGroup in teamEntries.Values)
                {
                    // Проверяем, в какую команду можно добавить всю группу
                    if (team1.Count + teamGroup.Count <= 3)
                    {
                        // Добавляем всю группу в команду 1
                        foreach (var player in teamGroup)
                        {
                            player.PrefferedTeam = 0;
                            team1.Add(player);
                        }
                    }
                    else if (team2.Count + teamGroup.Count <= 3)
                    {
                        // Добавляем всю группу в команду 2
                        foreach (var player in teamGroup)
                        {
                            player.PrefferedTeam = 1;
                            team2.Add(player);
                        }
                    }
                    else
                    {
                        // Если обе команды заполнены, игнорируем эту группу
                        // (это не должно происходить при нормальной работе)
                    }
                }

                // Затем распределяем соло игроков
                foreach (var soloPlayer in soloPlayers)
                {
                    if (team1.Count < 3)
                    {
                        soloPlayer.PrefferedTeam = 0;
                        team1.Add(soloPlayer);
                    }
                    else if (team2.Count < 3)
                    {
                        soloPlayer.PrefferedTeam = 1;
                        team2.Add(soloPlayer);
                    }
                }

                // Объединяем команды в sortedEntries
                sortedEntries.AddRange(team1);
                sortedEntries.AddRange(team2);

                // Создаем игроков в битве
                for (int i = 0; i < sortedEntries.Count; i++)
                {
                    UDPSocket socket = UDPGateway.CreateSocket();
                    socket.TCPConnection = sortedEntries[i].Connection;
                    socket.Battle = battle;
                    sortedEntries[i].Connection.UdpSessionId = socket.SessionId;

                    int teamIndex = sortedEntries[i].PrefferedTeam;

                    // Проверка данных аккаунта перед созданием игрока
                    if (sortedEntries[i].Connection?.MessageManager?.HomeMode == null || 
                        sortedEntries[i].Connection?.Avatar == null)
                    {
                        var accountId = sortedEntries[i].Connection?.MessageManager?.HomeMode?.Avatar?.AccountId ?? 0;
                        Logger.Error($"Invalid account data for connection {accountId}");
                        continue;
                    }

                    BattlePlayer player = BattlePlayer.Create(sortedEntries[i].Connection.Home, sortedEntries[i].Connection.Avatar, i, teamIndex);
                    player.TeamId = sortedEntries[i].PlayerTeamId;
                    sortedEntries[i].Player = player;
                    // Устанавливаем реальный уровень героя
                    var hero = player.Avatar?.GetHero(player.CharacterId);
                    if (hero != null)
                        player.HeroPowerLevel = hero.PowerLevel;
                    else
                        player.HeroPowerLevel = 1; // fallback
                    battle.AddPlayer(player, sortedEntries[i].Connection.UdpSessionId);
                }

                List<int> team1BotsCharacters = new List<int>();
                List<int> team2BotsCharacters = new List<int>();

                for (int i = sortedEntries.Count; i < battle.GetPlayersCountWithGameModeVariation(); i++)
                {
                    bool isBotValid = false;

                    int botCharacter = -1;
                    while (!isBotValid)
                    {
                        botCharacter = 16000000 + botBrawlers[rand.Next(0, botBrawlers.Length)];
                        if (i % 2 == 0)
                        {
                            isBotValid = !team1BotsCharacters.Contains(botCharacter);
                        }
                        else
                        {
                            isBotValid = !team2BotsCharacters.Contains(botCharacter);
                        }
                        if (!isBotValid) isBotValid = !GameModeUtil.HasTwoTeams(battle.GetGameModeVariation());
                    }

                    int teamIndex = i % 2;
                    if (battle.GetTeamPlayersCount(teamIndex) >= 3)
                    {
                        if (teamIndex == 1) teamIndex = 0;
                        else teamIndex = 1;
                    }

                    if (teamIndex == 0)
                    {
                        team1BotsCharacters.Add(botCharacter);
                    }
                    else
                    {
                        team2BotsCharacters.Add(botCharacter);
                    }
                    CharacterData data = DataTables.Get(16).GetDataByGlobalId<CharacterData>(botCharacter);
                    BattlePlayer bot = BattlePlayer.CreateBotInfo((i - sortedEntries.Count + 1).ToString(), i, teamIndex, botCharacter);
                    // Рандомный уровень для бота в диапазоне 5-11
                    bot.HeroPowerLevel = new Random().Next(5, 12);
                    battle.AddPlayer(bot, -1);
                }
            }
            else
            {
                sortedEntries = entries;
                for (int i = 0; i < entries.Count; i++)
                {
                    UDPSocket socket = UDPGateway.CreateSocket();
                    socket.TCPConnection = sortedEntries[i].Connection;
                    socket.Battle = battle;
                    sortedEntries[i].Connection.UdpSessionId = socket.SessionId;

                    int teamIndex = i;
                    // Проверка данных аккаунта перед созданием игрока
                    if (sortedEntries[i].Connection?.MessageManager?.HomeMode == null || 
                        sortedEntries[i].Connection?.Avatar == null)
                    {
                        var accountId = sortedEntries[i].Connection?.MessageManager?.HomeMode?.Avatar?.AccountId ?? 0;
                        Logger.Error($"Invalid account data for connection {accountId}");
                        continue;
                    }

                    BattlePlayer player = BattlePlayer.Create(sortedEntries[i].Connection.Home, sortedEntries[i].Connection.Avatar, i, teamIndex);
                    player.TeamId = sortedEntries[i].PlayerTeamId;
                    sortedEntries[i].Player = player;
                    // Устанавливаем реальный уровень героя
                    var hero = player.Avatar?.GetHero(player.CharacterId);
                    if (hero != null)
                        player.HeroPowerLevel = hero.PowerLevel;
                    else
                        player.HeroPowerLevel = 1; // fallback
                    battle.AddPlayer(player, sortedEntries[i].Connection.UdpSessionId);
                }

                for (int i = entries.Count; i < battle.GetPlayersCountWithGameModeVariation(); i++)
                {
                    int botCharacter = 16000000 + botBrawlers[rand.Next(0, botBrawlers.Length)];

                    int teamIndex = i;

                    CharacterData data = DataTables.Get(16).GetDataByGlobalId<CharacterData>(botCharacter);
                    BattlePlayer bot = BattlePlayer.CreateBotInfo(data.ItemName.ToUpper(), i, teamIndex, botCharacter);
                    // Рандомный уровень для бота в диапазоне 5-11
                    bot.HeroPowerLevel = new Random().Next(5, 12);
                    battle.AddPlayer(bot, -1);
                }

            }
            if (battle.m_players[0].IsAdmin) for (int i = 0; i < 120; i++) battle.m_time.IncreaseTick();
            if (battle.StoryMode != null) battle.StoryMode.Init();
            battle.AddGameObjects();

            for (int i = 0; i < sortedEntries.Count; i++)
            {
                StartLoadingMessage startLoading = new StartLoadingMessage();
                startLoading.LocationId = battle.Location.GetGlobalId();
                startLoading.TeamIndex = sortedEntries[i].Player.TeamIndex;
                startLoading.OwnIndex = sortedEntries[i].Player.PlayerIndex;
                startLoading.GameMode = battle.GetGameModeVariation();

                sortedEntries[i].Connection.Avatar.UdpSessionId = sortedEntries[i].Connection.UdpSessionId;
                startLoading.Players.AddRange(battle.GetPlayers());
                sortedEntries[i].Connection.Send(startLoading);
                battle.Dummy = startLoading;
                battle.BattleWithTrophies = true;
            }
            //if (entries.Count > 1)
            //{
            //string playernames = "";
            //foreach (MatchmakingEntry entry in sortedEntries)
            //{
            //    playernames += entry.Player.DisplayData.Name;
            //    playernames += "  ";
            //    playernames += entry.Player.Trophies.ToString();
            //    playernames += "🏆\n";
            //}
            //MasudaBot masudaBot = new MasudaBot(102038674, "ElazeGW3722wbRMI9StXcSJbvsRLitBm", "ElazeGW3722wbRMI9StXcSJbvsRLitBm", BotType.Public);
            ////masudaBot.ModifyChannelAsync("156024986", "服务器状态：🟢", 0, 3, "141954264");
            //masudaBot.SendMessageAsync("141955628", new Masuda.Net.HelpMessage.PlainMessage("多人对战开始：玩家：\n" + playernames));
            //}
            battle.Start();

        }
    }

    public class MatchmakingEntry
    {
        public readonly Connection Connection;
        public BattlePlayer Player;
        public long PlayerTeamId;
        public int PrefferedTeam;
        public long GroupId; // Новое поле для группировки команды в соло-матче

        public MatchmakingEntry(Connection connection)
        {
            PrefferedTeam = -1;
            this.Connection = connection;
            GroupId = 0;
        }
    }
}
