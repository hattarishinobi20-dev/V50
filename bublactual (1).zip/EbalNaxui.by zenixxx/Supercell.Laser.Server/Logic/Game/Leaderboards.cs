﻿namespace Supercell.Laser.Server.Logic.Game
{
    using Supercell.Laser.Logic.Club;
    using Supercell.Laser.Server.Database.Models;

    public static class Leaderboards
    {
        private static List<Account> Accounts;
        private static List<Alliance> Alliances;
        private static Thread Thread;

        public static void Init()
        {
            Accounts = new List<Account>();
            Alliances = new List<Alliance>();

            Thread = new Thread(Update);
            Thread.Start();
        }

        public static Account[] GetAvatarRankingList()
        {
            return Accounts.OrderByDescending(a => a.Avatar.Trophies).ToArray();
        }

        public static Account[] GetBrawlerRankingList(int HeroDataId)
        {
            var allAccounts = Database.Accounts.GetRankingList();
            
            var brawlerRanking = allAccounts
                .Where(acc => acc.Avatar != null && acc.Avatar.Heroes != null)
                .Select(acc => {
                    var hero = acc.Avatar.Heroes.FirstOrDefault(h => h.CharacterId == HeroDataId);
                    return new { Account = acc, HeroTrophies = hero?.Trophies ?? 0 };
                })
                .Where(item => item.HeroTrophies > 0)
                .OrderByDescending(item => item.HeroTrophies)
                .Select(item => item.Account)
                .ToArray();
            
            return brawlerRanking;
        }

        public static Alliance[] GetAllianceRankingList()
        {
            return Alliances.ToArray();
        }

        private static void Update()
        {
            while (true)
            {
                Accounts = Database.Accounts.GetRankingList();
                Alliances = Database.Alliances.GetRankingList();
                Thread.Sleep(15 * 60 * 1000); // 15 минут
            }
        }
    }
}
