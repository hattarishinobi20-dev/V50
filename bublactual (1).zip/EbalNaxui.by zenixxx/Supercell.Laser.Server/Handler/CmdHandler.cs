namespace Supercell.Laser.Server.Handler
{
    using Supercell.Laser.Logic.Avatar;
    using Supercell.Laser.Logic.Battle.Level;
    using Supercell.Laser.Logic.Data;
    using Supercell.Laser.Logic.Data.Helper;
    using Supercell.Laser.Logic.Home;
    using Supercell.Laser.Logic.Listener;
    using Supercell.Laser.Logic.Message.Account;
    using Supercell.Laser.Logic.Message.Account.Auth;
    using Supercell.Laser.Logic.Util;
    using Supercell.Laser.Server.Database;
    using Supercell.Laser.Server.Database.Cache;
    using Supercell.Laser.Server.Database.Models;
    using Supercell.Laser.Server.Networking.Session;
    using System.Reflection;

    public static class CmdHandler
    {
        public static void Start()
        {
            while (true)
            {
                try
                {
                    string cmd = Console.ReadLine();
                    if (cmd == null) continue;
                    if (!cmd.StartsWith("/")) continue;
                    HandleCmd(cmd);
                }
                catch (Exception) { }
            }
        }

        public static void HandleCmd(string cmd, long OwnAccountId = -1)
        {
            cmd = cmd.Substring(1);
            string[] args = cmd.Split(" ");
            if (args.Length < 1) return;
            switch (args[0])
            {
                case "premium":
                    ExecuteGivePremiumToAccount(args);
                    break;
                case "ban":
                    ExecuteBanAccount(args);
                    break;
                case "ToID":
                    Console.WriteLine(LogicLongCodeGenerator.ToId(args[1]));
                    break;
                case "unban":
                    ExecuteUnbanAccount(args);
                    break;
                case "changename":
                    ExecuteChangeNameForAccount(args);
                    break;
                case "getvalue":
                    ExecuteGetFieldValue(args);
                    break;
                case "changevalue":
                    ExecuteChangeValueForAccount(args);
                    break;
                case "unlockall":
                    ExecuteUnlockAllForAccount(args);
                    break;
                case "removeall":
                    ExecuteRemoveAllForAccount(args);
                    break;
                case "maintenance":
                    Console.WriteLine("Starting maintenance...");
                    ExecuteShutdown();
                    Console.WriteLine("Maintenance started!");
                    break;
                case "m":
                    Console.WriteLine("Starting maintenance...");
                    ExecuteShutdown();
                    Console.WriteLine("Maintenance started!");
                    break;
                case "md":
                    List<LogicData> logicDatas = DataTables.Get(DataType.Map).GetDatas();
                    LogicData logicData = logicDatas[0];
                    string s = logicData.GetCSVRow().GetValueAt(1);
                    int o = logicData.GetCSVRow().GetArraySizeAt(1);
                    string[] m = MapLoader.InitWithMapFromDataTable(null, DataTables.Get(19), "Tutorial");
                    break;
                case "login":
                    if (OwnAccountId == -1) break;
                    long id = LogicLongCodeGenerator.ToId(args[1]);
                    Account account = Accounts.Load(id);
                    if (account == null)
                    {
                        Console.WriteLine("Fail: account not found!");
                        return;
                    }
                    if (LogicServerListener.Instance.IsPlayerOnline(OwnAccountId))
                    {
                        LogicServerListener.Instance.GetGameListener(OwnAccountId).SendTCPMessage(new UnlockAccountOkMessage()
                        {
                            AccountId = account.AccountId,
                            PassToken = account.PassToken
                        });
                    }
                    break;
                case "changetheme":
                    if (OwnAccountId == -1) break;
                    Account account1 = Accounts.Load(OwnAccountId);
                    int i = -1;
                    try
                    {
                        i = int.Parse(args[1]);
                    }
                    catch (Exception) { }
                    account1.Home.PreferredThemeId = i;
                    break;
                case "givegems":
                    ExecuteGiveGemsToAccount(args);
                    break;
                case "giveblings":
                    ExecuteGiveBlingsToAccount(args);
                    break;
                case "givegold":
                    ExecuteGiveGoldToAccount(args);
                    break;
            }
        }

        static void ExecuteUnlockAllForAccount(string[] args)
        {
            if (args.Length != 2)
            {
                Console.WriteLine("Usage: /unlockall [TAG]");
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);
            if (account == null)
            {
                Console.WriteLine("Fail: account not found!");
                return;
            }

            account.Avatar.Refresh();

            AccountCache.SaveAll();
            Logger.Print($"Successfully unlocked all brawlers for account {account.AccountId.GetHigherInt()}-{account.AccountId.GetLowerInt()} ({args[1]})");

            if (Sessions.IsSessionActive(id))
            {
                var session = Sessions.GetSession(id);
                session.GameListener.SendTCPMessage(new AuthenticationFailedMessage()
                {
                    Message = "6"
                });
                Sessions.Remove(id);
            }
        }

        static void ExecuteRemoveAllForAccount(string[] args)
        {
            if (args.Length != 2)
            {
                Console.WriteLine("Usage: /removeall [TAG]");
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);
            if (account == null)
            {
                Console.WriteLine("Fail: account not found!");
                return;
            }

            for (int i = 1; ; i++)
            {
                if (account.Avatar.HasHero(16000000 + i))
                {
                    CharacterData character = DataTables.Get(16).GetDataWithId<CharacterData>(i);
                    if (!character.IsHero()) break;

                    account.Avatar.RemoveHero(character.GetGlobalId());
                }
                else
                {
                    break;
                }
            }

            Logger.Print($"Successfully removed all brawlers for account {account.AccountId.GetHigherInt()}-{account.AccountId.GetLowerInt()} ({args[1]})");

            if (Sessions.IsSessionActive(id))
            {
                var session = Sessions.GetSession(id);
                session.GameListener.SendTCPMessage(new AuthenticationFailedMessage()
                {
                    Message = "Your account updated!"
                });
                Sessions.Remove(id);
            }
        }

        static void ExecuteGivePremiumToAccount(string[] args)
        {
            if (args.Length != 3)
            {
                Console.WriteLine("Usage: /premium [TAG] [days]");
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);
            if (account == null)
            {
                Console.WriteLine("Fail: account not found!");
                return;
            }

            if (int.TryParse(args[2], out int days))
            {
                account.Avatar.IsVIP = true;
                account.Avatar.VIPExpire = DateTime.UtcNow.AddDays(days);
                AccountCache.SaveAll();
                Console.WriteLine($"VIP issued to account {args[1]} for {days} days!");
            }
            else
            {
                Console.WriteLine("Invalid format! Use: /premium [TAG] [days]");
            }

            if (Sessions.IsSessionActive(id))
            {
                var session = Sessions.GetSession(id);
                session.GameListener.SendTCPMessage(new AuthenticationFailedMessage()
                {
                    Message = "Your account updated!"
                });
                Sessions.Remove(id);
            }
        }

        static void ExecuteUnbanAccount(string[] args)
        {
            if (args.Length != 2)
            {
                Console.WriteLine("Usage: /unban [TAG]");
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);
            if (account == null)
            {
                Console.WriteLine("Fail: account not found!");
                return;
            }

            account.Avatar.BanUntil = null;
            account.Avatar.BanReason = null;
            AccountCache.SaveAll();
            Console.WriteLine($"Unbanned account {args[1]}");
            if (Sessions.IsSessionActive(id))
            {
                var session = Sessions.GetSession(id);
                session.GameListener.SendTCPMessage(new AuthenticationFailedMessage()
                {
                    Message = "Ваш аккаунт разбанен!"
                });
                Sessions.Remove(id);
            }
        }

        static void ExecuteBanAccount(string[] args)
        {
            if (args.Length < 2)
            {
                Console.WriteLine("Usage: /ban [TAG] [days] [reason]");
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);
            if (account == null)
            {
                Console.WriteLine("Fail: account not found!");
                return;
            }

            DateTime? until = null;
            string reason = null;
            if (args.Length >= 3 && int.TryParse(args[2], out int days))
            {
                until = DateTime.UtcNow.AddDays(days);
                if (args.Length > 3)
                    reason = string.Join(" ", args, 3, args.Length - 3);
            }
            else if (args.Length > 2)
            {
                reason = string.Join(" ", args, 2, args.Length - 2);
            }

            account.Avatar.BanUntil = until ?? DateTime.MaxValue; // MaxValue = бан навсегда
            account.Avatar.BanReason = reason;
            // Не сбрасываем кубки и ник
            AccountCache.SaveAll();
            Console.WriteLine($"Banned account {args[1]} until {account.Avatar.BanUntil} reason: {account.Avatar.BanReason}");
            if (Sessions.IsSessionActive(id))
            {
                var session = Sessions.GetSession(id);
                session.GameListener.SendTCPMessage(new AuthenticationFailedMessage()
                {
                    Message = $"Вы забанены до {account.Avatar.BanUntil?.ToString("yyyy-MM-dd HH:mm")}\nПричина: {account.Avatar.BanReason ?? "Не указана"}"
                });
                Sessions.Remove(id);
            }
        }

        static void ExecuteChangeNameForAccount(string[] args)
        {
            if (args.Length != 3)
            {
                Console.WriteLine("Usage: /changename [TAG] [NewName]");
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);
            if (account == null)
            {
                Console.WriteLine("Fail: account not found!");
                return;
            }

            account.Avatar.Name = args[2];
            if (Sessions.IsSessionActive(id))
            {
                var session = Sessions.GetSession(id);
                session.GameListener.SendTCPMessage(new AuthenticationFailedMessage()
                {
                    Message = "Your account updated!"
                });
                Sessions.Remove(id);
            }
        }

        static void ExecuteGetFieldValue(string[] args)
        {
            if (args.Length != 3)
            {
                Console.WriteLine("Usage: /getvalue [TAG] [FieldName]");
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);
            if (account == null)
            {
                Console.WriteLine("Fail: account not found!");
                return;
            }

            Type type = typeof(ClientAvatar);
            FieldInfo field = type.GetField(args[2]);
            if (field == null)
            {
                Console.WriteLine($"Fail: LogicClientAvatar::{args[2]} not found!");
                return;
            }

            int value = (int)field.GetValue(account.Avatar);
            Console.WriteLine($"LogicClientAvatar::{args[2]} = {value}");
        }

        static void ExecuteChangeValueForAccount(string[] args)
        {
            if (args.Length != 4)
            {
                Console.WriteLine("Usage: /changevalue [TAG] [FieldName] [Value]");
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);
            if (account == null)
            {
                Console.WriteLine("Fail: account not found!");
                return;
            }

            Type type = typeof(ClientAvatar);
            FieldInfo field = type.GetField(args[2]);
            if (field == null)
            {
                Console.WriteLine($"Fail: LogicClientAvatar::{args[2]} not found!");
                return;
            }

            if (int.TryParse(args[3], out int value))
            {
                field.SetValue(account.Avatar, value);
                if (Sessions.IsSessionActive(id))
                {
                    var session = Sessions.GetSession(id);
                    session.GameListener.SendTCPMessage(new AuthenticationFailedMessage()
                    {
                        Message = "Your account updated!"
                    });
                    Sessions.Remove(id);
                }
            }
            else
            {
                Console.WriteLine("Invalid value! Must be an integer.");
            }
        }

        static void ExecuteGiveGemsToAccount(string[] args)
        {
            if (args.Length != 3)
            {
                Console.WriteLine("Usage: /givegems [TAG] [amount]");
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);
            if (account == null)
            {
                Console.WriteLine("Fail: account not found!");
                return;
            }

            if (int.TryParse(args[2], out int gems))
            {
                account.Avatar.Diamonds += gems;
                AccountCache.SaveAll();
                Console.WriteLine($"{gems} gems issued to account {args[1]}!");
                if (Sessions.IsSessionActive(id))
                {
                    var session = Sessions.GetSession(id);
                    session.GameListener.SendTCPMessage(new AuthenticationFailedMessage()
                    {
                        Message = "Your account updated!"
                    });
                    Sessions.Remove(id);
                }
            }
            else
            {
                Console.WriteLine("Invalid format! Use: /givegems [TAG] [amount]");
            }
        }

        static void ExecuteGiveBlingsToAccount(string[] args)
        {
            if (args.Length != 3)
            {
                Console.WriteLine("Usage: /giveblings [TAG] [amount]");
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);
            if (account == null)
            {
                Console.WriteLine("Fail: account not found!");
                return;
            }

            if (int.TryParse(args[2], out int blings))
            {
                account.Avatar.Blings += blings;
                AccountCache.SaveAll();
                Console.WriteLine($"{blings} blings issued to account {args[1]}!");
                if (Sessions.IsSessionActive(id))
                {
                    var session = Sessions.GetSession(id);
                    session.GameListener.SendTCPMessage(new AuthenticationFailedMessage()
                    {
                        Message = "Your account updated!"
                    });
                    Sessions.Remove(id);
                }
            }
            else
            {
                Console.WriteLine("Invalid format! Use: /giveblings [TAG] [amount]");
            }
        }

        static void ExecuteGiveGoldToAccount(string[] args)
        {
            if (args.Length != 3)
            {
                Console.WriteLine("Usage: /givegold [TAG] [amount]");
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);
            if (account == null)
            {
                Console.WriteLine("Fail: account not found!");
                return;
            }

            if (int.TryParse(args[2], out int gold))
            {
                account.Avatar.Gold += gold;
                AccountCache.SaveAll();
                Console.WriteLine($"{gold} coins issued to account {args[1]}!");
                if (Sessions.IsSessionActive(id))
                {
                    var session = Sessions.GetSession(id);
                    session.GameListener.SendTCPMessage(new AuthenticationFailedMessage()
                    {
                        Message = "Your account updated!"
                    });
                    Sessions.Remove(id);
                }
            }
            else
            {
                Console.WriteLine("Invalid format! Use: /givegold [TAG] [amount]");
            }
        }

        static void ExecuteShutdown()
        {
            Sessions.StartShutdown();
            AccountCache.SaveAll();
            AllianceCache.SaveAll();

            AccountCache.Started = false;
            AllianceCache.Started = false;
        }
    }
}