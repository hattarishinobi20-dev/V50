#!/bin/bash
PROJECT_DIR="/root/bubl/Supercell.Laser.Server"
LOG_FILE="$PROJECT_DIR/server.log"

cd "$PROJECT_DIR"

echo "[Watchdog] Запуск сервера..." | tee -a "$LOG_FILE"

while true; do
    date "+[%F %T] Перезапуск dotnet run..." | tee -a "$LOG_FILE"
    dotnet run >> "$LOG_FILE" 2>&1
    EXIT_CODE=$?
    echo "[Watchdog] Сервер завершился с кодом $EXIT_CODE" | tee -a "$LOG_FILE"
    sleep 2
done
