using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Supercell.Laser.Logic.Util;
using Supercell.Laser.Server.Database;
using Supercell.Laser.Server.Database.Cache;
using Supercell.Laser.Server.Database.Models;
using Supercell.Laser.Server.Networking.Session;
using Supercell.Laser.Logic.Home.Items;
using Telegram.Bot;
using Telegram.Bot.Polling;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using Supercell.Laser.Logic.Message.Account;
using Supercell.Laser.Logic.Message.Account.Auth;

namespace Supercell.Laser.Logic.Avatar
{
    public class Bot
    {
        private static List<long> AdminIds = new List<long> { 7967459430 };
        private readonly ITelegramBotClient _botClient;
        private Dictionary<long, OfferCreationState> _offerCreationStates = new Dictionary<long, OfferCreationState>();

        public Bot(string botToken)
        {
            _botClient = new TelegramBotClient(botToken);
        }

        private static bool IsAdmin(long userId)
        {
            return AdminIds.Contains(userId);
        }

        public async Task StartBotAsync(CancellationToken cancellationToken)
        {
            var receiverOptions = new ReceiverOptions
            {
                AllowedUpdates = Array.Empty<UpdateType>()
            };

            // Диагностика: вывод списка админов при запуске
            Console.WriteLine($"Бот запущен. Администраторы: {string.Join(", ", AdminIds)}");

            _botClient.StartReceiving(
                HandleUpdateAsync,
                HandleErrorAsync,
                receiverOptions,
                cancellationToken: cancellationToken
            );

            Console.WriteLine("Бот готов к приему сообщений.");
        }

        private async Task HandleUpdateAsync(ITelegramBotClient botClient, Update update, CancellationToken token)
        {
            try
            {
                if (update.Message != null && update.Message.Text != null)
                {
                    var message = update.Message;
                    var chatId = message.Chat.Id;
                    var text = message.Text;

                    // Диагностика: вывод информации о сообщении
                    Console.WriteLine($"Получено сообщение: [ID: {chatId}, Текст: '{text}']");

                    if (text.StartsWith("/"))
                    {
                        await HandleCommandAsync(chatId, text, token);
                        return;
                    }
                    else
                    {
                        await HandleTextMessage(chatId, text, token);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при обработке обновления: {ex.Message}");
            }
        }

        private async Task HandleCommandAsync(long chatId, string cmd, CancellationToken token)
        {
            if (!cmd.StartsWith("/"))
                return;

            // Диагностика: вывод информации о правах доступа
            Console.WriteLine($"Обработка команды: '{cmd}' от пользователя {chatId}");
            Console.WriteLine($"Права администратора: {IsAdmin(chatId)}");

            if (!IsAdmin(chatId))
            {
                Console.WriteLine($"Отказ в доступе для {chatId}");
                await _botClient.SendMessage(chatId, "Ошибка: У вас нет прав администратора!", cancellationToken: token);
                return;
            }

            cmd = cmd.Substring(1);
            string[] args = cmd.Split(' ');

            switch (args[0])
            {
                case "help":
                    await ExecuteHelp(chatId, args, token);
                    break;
                case "premium":
                    await ExecuteGivePremiumToAccount(chatId, args, token);
                    break;
                case "ban":
                    await ExecuteBanAccount(chatId, args, token);
                    break;
                case "unban":
                    await ExecuteUnbanAccount(chatId, args, token);
                    break;
                case "changename":
                    await ExecuteChangeNameForAccount(chatId, args, token);
                    break;
                case "addblings":
                    await ExecuteAddBlingByTheVild(chatId, args, token);
                    break;
                case "addgems":
                    await ExecuteAddGemsByTheVild(chatId, args, token);
                    break;
                case "addcoins":
                    await ExecuteAddCoinsByTheVild(chatId, args, token);
                    break;
                case "addtokens":
                    await ExecuteAddTokensByTheVild(chatId, args, token);
                    break;
                case "addstokens":
                    await ExecuteAddStarTokensByTheVild(chatId, args, token);
                    break;
                case "addspoints":
                    await ExecuteAddStarPointsByTheVild(chatId, args, token);
                    break;
                case "addppoints":
                    await ExecuteAddPowerPointsByTheVild(chatId, args, token);
                    break;
                case "addrtokens":
                    await ExecuteAddRareTokensByTheVild(chatId, args, token);
                    break;
                case "addDev":
                    await ExecuteAddDevByTheVild(chatId, args, token);
                    break;
                case "unDev":
                    await ExecuteUnDevByTheVild(chatId, args, token);
                    break;
                case "addwinstreak":
                    await ExecuteAddWinStreakByTheVild(chatId, args, token);
                    break;
                case "createoffer":
                    await ExecuteCreateOfferByTheVild(chatId, args, token);
                    break;
                case "maintenance":
                    await ExecuteShutdown(chatId, token);
                    break;
                case "debug":
                    await _botClient.SendMessage(chatId, $"Ваш ID: {chatId}", cancellationToken: token);
                    break;
                default:
                    await _botClient.SendMessage(chatId, "Неизвестная команда.", cancellationToken: token);
                    break;
            }
        }

        private async Task ExecuteHelp(long chatId, string[] args, CancellationToken token)
        {
            string helpText = "*Доступные команды:*\n" +
                              "- /help - Показать список команд\n" +
                              "- /createoffer - Создать оффер (пошаговый процесс)\n" +
                              "- /premium - Выдать премиум аккаунту\n" +
                              "- /ban - Забанить аккаунт\n" +
                              "- /unban - Разбанить аккаунт\n" +
                              "- /changename - Изменить имя аккаунта\n" +
                              "- /addblings - Добавить блинги аккаунту\n" +
                              "- /addgems - Выдать гемы аккаунту\n" +
                              "- /addcoins - Выдать золото аккаунту\n" +
                              "- /addtokens - Добавить токены аккаунту\n" +
                              "- /addstokens - Добавить стар токены аккаунту\n" +
                              "- /addspoints - Добавить старки аккаунту\n" +
                              "- /addppoints - Добавить поверпоинты аккаунту\n" +
                              "- /addrtokens - Добавить редкие токены аккаунту\n" +
                              "- /addDev - Добавить дева\n" +
                              "- /unDev - Убрать дева\n" +
                              "- /addwinstreak - Добавить побед подряд аккаунту\n" +
                              "- /maintenance - Включить режим обслуживания\n" +
                              "- /debug - Показать ваш ID";
            await _botClient.SendMessage(chatId, helpText, cancellationToken: token);
        }

        private async Task ExecuteCreateOfferByTheVild(long chatId, string[] args, CancellationToken token)
        {
            try
            {
                if (_offerCreationStates.ContainsKey(chatId))
                {
                    await _botClient.SendMessage(chatId, "Вы уже находитесь в процессе создания оффера. Ответьте на текущий вопрос или напишите 'отмена' для завершения.", cancellationToken: token);
                    return;
                }

                _offerCreationStates[chatId] = new OfferCreationState { ChatId = chatId };
                await SendNextQuestion(chatId, token);
            }
            catch (Exception ex)
            {
                string error = $"Ошибка: {ex.Message}\n" +
                              "Используйте: /createoffer для начала пошагового создания оффера.";
                await _botClient.SendMessage(chatId, error, cancellationToken: token);
                Console.WriteLine(error);
            }
        }

        private async Task SendNextQuestion(long chatId, CancellationToken token)
        {
            var state = _offerCreationStates[chatId];
            string question = string.Empty;

            switch (state.Step)
            {
                case 0:
                    question = "Давайте создадим оффер. Вы можете ответить на вопросы по очереди.\n" +
                               "1. Укажите дату начала оффера (формат ДД.ММ.ГГГГ ЧЧ:ММ). Для текущего времени напишите 'DateTime.UtcNow'.";
                    break;
                case 1:
                    question = "2. Укажите дату окончания оффера (формат ДД.ММ.ГГГГ ЧЧ:ММ). Например, DateTime.UtcNow.AddDays(кол-во дней).";
                    break;
                case 2:
                    question = "3. Укажите количество предметов или наград в оффере (например, 60).";
                    break;
                case 3:
                    question = "4. Укажите ID бравлера, если оффер связан с конкретным персонажем (или 999, если не нужно).";
                    break;
                case 4:
                    question = "5. Укажите дополнительный параметр для награды (обычно 0, если нет особых требований).";
                    break;
                case 5:
                    question = "6. Укажите тип награды (например, Gems, Coin, MegaBox и т.д.).";
                    break;
                case 6:
                    question = "7. Укажите стоимость оффера (0, если бесплатно).";
                    break;
                case 7:
                    question = "8. Укажите старую цену для отображения скидки (0, если скидки нет).";
                    break;
                case 8:
                    question = "9. Укажите тип валюты (0 - алмазы, 1 - золото, 2 - бесплатно, 6 - блинг).";
                    break;
                case 9:
                    question = "10. Укажите название оффера, которое будет отображаться пользователю (например, 'Супер Акция').";
                    break;
                case 10:
                    question = "11. Укажите фон оффера (например, 'offer_special' или другой доступный идентификатор).";
                    break;
                case 11:
                    question = "12. Укажите, является ли название текстом из таблицы переводов (0 - нет, 1 - да).";
                    break;
                case 12:
                    question = "13. Укажите тип ежедневного оффера (например, 0, если не ежедневный).";
                    break;
                case 13:
                    question = "14. Укажите, является ли оффер одноразовым (true/false).";
                    break;
                case 14:
                    question = "15. Укажите, загружается ли оффер при старте (true/false).";
                    break;
                case 15:
                    question = "16. Укажите, обработан ли оффер (true/false).";
                    break;
                case 16:
                    question = "17. Укажите тип бонуса (например, 0, если нет бонуса).";
                    break;
                case 17:
                    question = "18. Укажите значение бонуса (например, 0, если нет бонуса).";
                    break;
                case 18:
                    question = "19. Укажите класс панели (например, 0).";
                    break;
                case 19:
                    question = "20. Укажите тип панели (например, 0).";
                    break;
                case 20:
                    question = "21. Укажите класс стиля (например, 0).";
                    break;
                case 21:
                    question = "22. Укажите тип стиля (например, 0).";
                    break;
                case 22:
                    question = "23. Укажите расположение оффера (rasstanovka, например, 0).";
                    break;
                case 23:
                    question = "24. Укажите логический флаг cl (true или false в зависимости от нужного поведения).";
                    break;
                case 24:
                    question = "25. Укажите дату, связанную с обработкой оффера (формат ДД.ММ.ГГГГ, если нужно, иначе напишите 'DateTime.MinValue').";
                    break;
            }

            await _botClient.SendMessage(chatId, question, cancellationToken: token);
            state.Step++;
        }

        private string GenerateOfferCode(string[] parameters)
        {
            return $"GenerateOffer3(\n" +
                   $"    {parameters[0]}, // OfferStart\n" +
                   $"    {parameters[1]}, // OfferEnd\n" +
                   $"    {parameters[2]}, // Count\n" +
                   $"    {parameters[3]}, // BrawlerID\n" +
                   $"    {parameters[4]}, // Extra\n" +
                   $"    ShopItem.{parameters[5]}, // Item\n" +
                   $"    {parameters[6]}, // Cost\n" +
                   $"    {parameters[7]}, // OldCost\n" +
                   $"    {parameters[8]}, // Currency\n" +
                   $"    \"offer_unique_id\", // Claim\n" +
                   $"    \"{parameters[9]}\", // Title\n" +
                   $"    \"{parameters[10]}\", // BGR\n" +
                   $"    {parameters[11]}, // IsTID\n" +
                   $"    {parameters[12]}, // DailyOfferType\n" +
                   $"    {parameters[13]}, // OneTimeOffer\n" +
                   $"    {parameters[14]}, // LoadOnStartup\n" +
                   $"    {parameters[15]}, // Processed\n" +
                   $"    {parameters[16]}, // TypeBenefit\n" +
                   $"    {parameters[17]}, // Benefit\n" +
                   $"    {parameters[18]}, // panelClass\n" +
                   $"    {parameters[19]}, // panelType\n" +
                   $"    {parameters[20]}, // styleClass\n" +
                   $"    {parameters[21]}, // styleType\n" +
                   $"    {parameters[22]}, // rasstanovka\n" +
                   $"    {parameters[23]}, // cl\n" +
                   $"    {parameters[24]} // al\n" +
                   $");";
        }

        private async Task CreateOfferFromState(long chatId, OfferCreationState state, CancellationToken token)
        {
            try
            {
                DateTime offerStart = state.Parameters[0] == "сейчас" ? DateTime.UtcNow : DateTime.ParseExact(state.Parameters[0], "dd.MM.yyyy HH:mm", null);
                DateTime offerEnd = DateTime.ParseExact(state.Parameters[1], "dd.MM.yyyy HH:mm", null);
                int count = int.Parse(state.Parameters[2]);
                int brawlerId = int.Parse(state.Parameters[3]);
                int extra = int.Parse(state.Parameters[4]);
                ShopItem item = Enum.Parse<ShopItem>(state.Parameters[5]);
                int cost = int.Parse(state.Parameters[6]);
                int oldCost = int.Parse(state.Parameters[7]);
                int currency = int.Parse(state.Parameters[8]);
                string title = state.Parameters[9];
                string bgr = state.Parameters[10];
                int isTid = int.Parse(state.Parameters[11]);
                int dailyOfferType = int.Parse(state.Parameters[12]);
                bool oneTimeOffer = bool.Parse(state.Parameters[13]);
                bool loadOnStartup = bool.Parse(state.Parameters[14]);
                bool processed = bool.Parse(state.Parameters[15]);
                int typeBenefit = int.Parse(state.Parameters[16]);
                int benefit = int.Parse(state.Parameters[17]);
                int panelClass = int.Parse(state.Parameters[18]);
                int panelType = int.Parse(state.Parameters[19]);
                int styleClass = int.Parse(state.Parameters[20]);
                int styleType = int.Parse(state.Parameters[21]);
                int rasstanovka = int.Parse(state.Parameters[22]);
                bool cl = bool.Parse(state.Parameters[23]);
                DateTime al = state.Parameters[24] == "нет" ? DateTime.MinValue : DateTime.ParseExact(state.Parameters[24], "dd.MM.yyyy", null);

                long lastAccId = Accounts.GetMaxAvatarId();
                int successCount = 0;
                int errorCount = 0;
                int homeNullCount = 0;
                int homeModeNullCount = 0;

                Console.WriteLine($"Начинаем обработку аккаунтов (максимальный ID: {lastAccId})");

                for (long accId = 1; accId <= lastAccId; accId++)
                {
                    try
                    {
                        var account = Accounts.Load(accId);
                        if (account == null)
                        {
                            Console.WriteLine($"Аккаунт {accId} не найден");
                            errorCount++;
                            continue;
                        }

                        if (account.Home == null)
                        {
                            Console.WriteLine($"Аккаунт {accId}: Home = null");
                            homeNullCount++;
                            continue;
                        }

                        if (account.Home.HomeMode == null)
                        {
                            Console.WriteLine($"Аккаунт {accId}: HomeMode = null");
                            homeModeNullCount++;
                            continue;
                        }

                        string claimId = $"offer_{accId}_{DateTime.Now.Ticks}";
                        account.Home.GenerateOffer3(
                            offerStart, offerEnd, count, brawlerId, extra, item, cost, oldCost, currency,
                            claimId, title, bgr, isTid, dailyOfferType, oneTimeOffer, loadOnStartup,
                            processed, typeBenefit, benefit, panelClass, panelType, styleClass, styleType,
                            rasstanovka, cl, al
                        );

                        Accounts.Save(account);
                        Console.WriteLine($"Аккаунт {accId}: Оффер успешно создан");
                        successCount++;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Ошибка для аккаунта {accId}: {ex.Message}");
                        errorCount++;
                    }
                }

                await _botClient.SendMessage(chatId, $"Создание офферов завершено!\nУспешно: {successCount}\nОшибок: {errorCount}\nHome=null: {homeNullCount}\nHomeMode=null: {homeModeNullCount}", cancellationToken: token);
            }
            catch (Exception ex)
            {
                await _botClient.SendMessage(chatId, $"Ошибка при создании оффера: {ex.Message}", cancellationToken: token);
            }
        }

        private async Task HandleTextMessage(long chatId, string text, CancellationToken token)
        {
            if (_offerCreationStates.TryGetValue(chatId, out var state))
            {
                if (text.ToLower() == "отмена")
                {
                    _offerCreationStates.Remove(chatId);
                    await _botClient.SendMessage(chatId, "Процесс создания оффера отменен.", cancellationToken: token);
                    return;
                }

                try
                {
                    switch (state.Step)
                    {
                        case 0: // OfferStart
                            if (text.ToLower() == "datetime.utcnow")
                            {
                                state.Parameters[0] = "сейчас";
                            }
                            else
                            {
                                state.Parameters[0] = text;
                            }
                            break;
                        case 1: // OfferEnd
                            if (text.ToLower().Contains("datetime.utcnow.adddays"))
                            {
                                var daysStr = text.Split('(')[1].Split(')')[0];
                                if (int.TryParse(daysStr, out int days))
                                {
                                    state.Parameters[1] = $"DateTime.UtcNow.AddDays({days})";
                                }
                                else
                                {
                                    throw new FormatException("Неверный формат количества дней.");
                                }
                            }
                            else
                            {
                                state.Parameters[1] = text;
                            }
                            break;
                        case 2: // Count
                            state.Parameters[2] = text;
                            break;
                        case 3: // BrawlerID
                            state.Parameters[3] = text;
                            break;
                        case 4: // Extra
                            state.Parameters[4] = text;
                            break;
                        case 5: // Item
                            state.Parameters[5] = text;
                            break;
                        case 6: // Cost
                            state.Parameters[6] = text;
                            break;
                        case 7: // OldCost
                            state.Parameters[7] = text;
                            break;
                        case 8: // Currency
                            state.Parameters[8] = text;
                            break;
                        case 9: // Title
                            state.Parameters[9] = text;
                            break;
                        case 10: // BGR
                            state.Parameters[10] = text;
                            break;
                        case 11: // IsTID
                            state.Parameters[11] = text;
                            break;
                        case 12: // DailyOfferType
                            state.Parameters[12] = text;
                            break;
                        case 13: // OneTimeOffer
                            state.Parameters[13] = text;
                            break;
                        case 14: // LoadOnStartup
                            state.Parameters[14] = text;
                            break;
                        case 15: // Processed
                            state.Parameters[15] = text;
                            break;
                        case 16: // TypeBenefit
                            state.Parameters[16] = text;
                            break;
                        case 17: // Benefit
                            state.Parameters[17] = text;
                            break;
                        case 18: // panelClass
                            state.Parameters[18] = text;
                            break;
                        case 19: // panelType
                            state.Parameters[19] = text;
                            break;
                        case 20: // styleClass
                            state.Parameters[20] = text;
                            break;
                        case 21: // styleType
                            state.Parameters[21] = text;
                            break;
                        case 22: // rasstanovka
                            state.Parameters[22] = text;
                            break;
                        case 23: // cl
                            state.Parameters[23] = text;
                            break;
                        case 24: // al
                            if (text.ToLower() == "datetime.minvalue")
                            {
                                state.Parameters[24] = "нет";
                            }
                            else
                            {
                                state.Parameters[24] = text;
                            }
                            break;
                    }

                    state.Step++;
                    if (state.Step < 25)
                    {
                        await SendNextQuestion(chatId, token);
                    }
                    else
                    {
                        await _botClient.SendMessage(chatId, "Все параметры собраны! Давайте проверим код оффера, который вы создали:\n" + GenerateOfferCode(state.Parameters), cancellationToken: token);
                        await CreateOfferFromState(chatId, state, token);
                        _offerCreationStates.Remove(chatId);
                    }
                }
                catch (Exception ex)
                {
                    await _botClient.SendMessage(chatId, $"Ошибка при обработке ввода: {ex.Message}. Пожалуйста, попробуйте снова.", cancellationToken: token);
                }
            }
            else
            {
                await _botClient.SendMessage(chatId, "Неизвестная команда или сообщение. Используйте /help для списка команд.", cancellationToken: token);
            }
        }

        private async Task ExecuteGivePremiumToAccount(long chatId, string[] args, CancellationToken token)
        {
            if (args.Length != 3)
            {
                await _botClient.SendMessage(chatId, "Использование: /premium [TAG] [days]", cancellationToken: token);
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);
            if (account == null)
            {
                await _botClient.SendMessage(chatId, "Ошибка: аккаунт не найден!", cancellationToken: token);
                return;
            }

            if (int.TryParse(args[2], out int days))
            {
                account.Avatar.IsVIP = true;
                account.Avatar.VIPExpire = DateTime.UtcNow.AddDays(days);
                AccountCache.SaveAll();
                await _botClient.SendMessage(chatId, $"VIP выдан аккаунту {args[1]} на {days} дней!", cancellationToken: token);
            }
            else
            {
                await _botClient.SendMessage(chatId, "Неверный формат! Используйте: /premium [TAG] [days]", cancellationToken: token);
            }

            if (Sessions.IsSessionActive(id))
            {
                var session = Sessions.GetSession(id);
                session.GameListener.SendTCPMessage(new AuthenticationFailedMessage()
                {
                    Message = "Your account updated!"
                });
                Sessions.Remove(id);
            }
        }

        private async Task ExecuteBanAccount(long chatId, string[] args, CancellationToken token)
        {
            if (args.Length < 2)
            {
                await _botClient.SendMessage(chatId, "Использование: /ban [TAG] [days] [reason]", cancellationToken: token);
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);

            if (account == null)
            {
                await _botClient.SendMessage(chatId, "Ошибка: аккаунт не найден!", cancellationToken: token);
                return;
            }

            DateTime? until = null;
            string reason = null;
            if (args.Length >= 3 && int.TryParse(args[2], out int days))
            {
                until = DateTime.UtcNow.AddDays(days);
                if (args.Length > 3)
                    reason = string.Join(" ", args, 3, args.Length - 3);
            }
            else if (args.Length > 2)
            {
                reason = string.Join(" ", args, 2, args.Length - 2);
            }

            account.Avatar.BanUntil = until ?? DateTime.MaxValue; // MaxValue = бан навсегда
            account.Avatar.BanReason = reason;
            // Не сбрасываем кубки и ник
            AccountCache.SaveAll();
            await _botClient.SendMessage(chatId, $"Banned account {args[1]} until {account.Avatar.BanUntil} reason: {account.Avatar.BanReason}", cancellationToken: token);
            if (Sessions.IsSessionActive(id))
            {
                var session = Sessions.GetSession(id);
                session.GameListener.SendTCPMessage(new AuthenticationFailedMessage()
                {
                    Message = $"Вы забанены до {account.Avatar.BanUntil?.ToString("yyyy-MM-dd HH:mm")}\nПричина: {account.Avatar.BanReason ?? "Не указана"}"
                });
                Sessions.Remove(id);
            }
        }

        private async Task ExecuteUnbanAccount(long chatId, string[] args, CancellationToken token)
        {
            if (args.Length != 2)
            {
                await _botClient.SendMessage(chatId, "Использование: /unban [TAG]", cancellationToken: token);
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);

            if (account == null)
            {
                await _botClient.SendMessage(chatId, "Ошибка: аккаунт не найден!", cancellationToken: token);
                return;
            }

            account.Avatar.BanUntil = null;
            account.Avatar.BanReason = null;
            AccountCache.SaveAll();
            await _botClient.SendMessage(chatId, $"Unbanned account {args[1]}", cancellationToken: token);
            if (Sessions.IsSessionActive(id))
            {
                var session = Sessions.GetSession(id);
                session.GameListener.SendTCPMessage(new AuthenticationFailedMessage()
                {
                    Message = "Ваш аккаунт разбанен!"
                });
                Sessions.Remove(id);
            }
        }

        private async Task ExecuteChangeNameForAccount(long chatId, string[] args, CancellationToken token)
        {
            if (args.Length != 3)
            {
                await _botClient.SendMessage(chatId, "Использование: /changename [TAG] [NewName]", cancellationToken: token);
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);

            if (account == null)
            {
                await _botClient.SendMessage(chatId, "Ошибка: аккаунт не найден!", cancellationToken: token);
                return;
            }

            account.Avatar.Name = args[2];

            await _botClient.SendMessage(chatId, $"Имя аккаунта {args[1]} успешно изменено на {args[2]}.", cancellationToken: token);
            Accounts.Save(account);
        }

        private async Task ExecuteAddBlingByTheVild(long chatId, string[] args, CancellationToken token)
        {
            if (args.Length != 3)
            {
                await _botClient.SendMessage(chatId, "Использование: /addblings [TAG] [Count]", cancellationToken: token);
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);

            if (account == null)
            {
                await _botClient.SendMessage(chatId, "Ошибка: аккаунт не найден!", cancellationToken: token);
                return;
            }

            account.Avatar.Blings += int.Parse(args[2]);

            await _botClient.SendMessage(chatId, $"Аккаунту {args[1]} успешно добавлено {args[2]} блингов.", cancellationToken: token);
            Accounts.Save(account);
        }

        private async Task ExecuteAddGemsByTheVild(long chatId, string[] args, CancellationToken token)
        {
            if (args.Length != 3)
            {
                await _botClient.SendMessage(chatId, "Использование: /addgems [TAG] [Count]", cancellationToken: token);
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);

            if (account == null)
            {
                await _botClient.SendMessage(chatId, "Ошибка: аккаунт не найден!", cancellationToken: token);
                return;
            }

            account.Avatar.Diamonds += int.Parse(args[2]);

            await _botClient.SendMessage(chatId, $"Аккаунту {args[1]} успешно добавлено {args[2]} гемов.", cancellationToken: token);
            Accounts.Save(account);
        }

        private async Task ExecuteAddCoinsByTheVild(long chatId, string[] args, CancellationToken token)
        {
            if (args.Length != 3)
            {
                await _botClient.SendMessage(chatId, "Использование: /addcoins [TAG] [Count]", cancellationToken: token);
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);

            if (account == null)
            {
                await _botClient.SendMessage(chatId, "Ошибка: аккаунт не найден!", cancellationToken: token);
                return;
            }

            account.Avatar.Gold += int.Parse(args[2]);

            await _botClient.SendMessage(chatId, $"Аккаунту {args[1]} успешно добавлено {args[2]} монет.", cancellationToken: token);
            Accounts.Save(account);
        }

        private async Task ExecuteAddTokensByTheVild(long chatId, string[] args, CancellationToken token)
        {
            if (args.Length != 3)
            {
                await _botClient.SendMessage(chatId, "Использование: /addtokens [TAG] [Count]", cancellationToken: token);
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);

            if (account == null)
            {
                await _botClient.SendMessage(chatId, "Ошибка: аккаунт не найден!", cancellationToken: token);
                return;
            }

            account.Avatar.Tokens += int.Parse(args[2]);

            await _botClient.SendMessage(chatId, $"Аккаунту {args[1]} успешно добавлено {args[2]} токенов.", cancellationToken: token);
            Accounts.Save(account);
        }

        private async Task ExecuteAddStarTokensByTheVild(long chatId, string[] args, CancellationToken token)
        {
            if (args.Length != 3)
            {
                await _botClient.SendMessage(chatId, "Использование: /addstokens [TAG] [Count]", cancellationToken: token);
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);

            if (account == null)
            {
                await _botClient.SendMessage(chatId, "Ошибка: аккаунт не найден!", cancellationToken: token);
                return;
            }

            account.Avatar.StarTokens += int.Parse(args[2]);

            await _botClient.SendMessage(chatId, $"Аккаунту {args[1]} успешно добавлено {args[2]} стар токенов.", cancellationToken: token);
            Accounts.Save(account);
        }

        private async Task ExecuteAddStarPointsByTheVild(long chatId, string[] args, CancellationToken token)
        {
            if (args.Length != 3)
            {
                await _botClient.SendMessage(chatId, "Использование: /addspoints [TAG] [Count]", cancellationToken: token);
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);

            if (account == null)
            {
                await _botClient.SendMessage(chatId, "Ошибка: аккаунт не найден!", cancellationToken: token);
                return;
            }

            account.Avatar.StarPoints += int.Parse(args[2]);

            await _botClient.SendMessage(chatId, $"Аккаунту {args[1]} успешно добавлено {args[2]} старпоинтов.", cancellationToken: token);
            Accounts.Save(account);
        }

        private async Task ExecuteAddPowerPointsByTheVild(long chatId, string[] args, CancellationToken token)
        {
            if (args.Length != 3)
            {
                await _botClient.SendMessage(chatId, "Использование: /addppoints [TAG] [Count]", cancellationToken: token);
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);

            if (account == null)
            {
                await _botClient.SendMessage(chatId, "Ошибка: аккаунт не найден!", cancellationToken: token);
                return;
            }

            account.Avatar.PowerPoints += int.Parse(args[2]);

            await _botClient.SendMessage(chatId, $"Аккаунту {args[1]} успешно добавлено {args[2]} поверпоинтов", cancellationToken: token);
            Accounts.Save(account);
        }

        private async Task ExecuteAddRareTokensByTheVild(long chatId, string[] args, CancellationToken token)
        {
            if (args.Length != 3)
            {
                await _botClient.SendMessage(chatId, "Использование: /addrtokens [TAG] [Count]", cancellationToken: token);
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);

            if (account == null)
            {
                await _botClient.SendMessage(chatId, "Ошибка: аккаунт не найден!", cancellationToken: token);
                return;
            }

            account.Avatar.Diamonds += int.Parse(args[2]);

            await _botClient.SendMessage(chatId, $"Аккаунту {args[1]} успешно добавлено {args[2]} редких токенов.", cancellationToken: token);
            Accounts.Save(account);
        }

        private async Task ExecuteAddDevByTheVild(long chatId, string[] args, CancellationToken token)
        {
            if (args.Length != 2)
            {
                await _botClient.SendMessage(chatId, "Использование: /addDev [TAG]", cancellationToken: token);
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);

            if (account == null)
            {
                await _botClient.SendMessage(chatId, "Ошибка: аккаунт не найден!", cancellationToken: token);
                return;
            }

            account.Avatar.IsDev = true;

            await _botClient.SendMessage(chatId, $"Аккаунт {args[1]} успешно стал девом", cancellationToken: token);
            Accounts.Save(account);
        }

        private async Task ExecuteUnDevByTheVild(long chatId, string[] args, CancellationToken token)
        {
            if (args.Length != 2)
            {
                await _botClient.SendMessage(chatId, "Использование: /unDev [TAG]", cancellationToken: token);
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);

            if (account == null)
            {
                await _botClient.SendMessage(chatId, "Ошибка: аккаунт не найден!", cancellationToken: token);
                return;
            }

            account.Avatar.IsDev = false;

            await _botClient.SendMessage(chatId, $"Аккаунт {args[1]} успешно перестал быть девом", cancellationToken: token);
            Accounts.Save(account);
        }

        private async Task ExecuteAddWinStreakByTheVild(long chatId, string[] args, CancellationToken token)
        {
            if (args.Length != 3)
            {
                await _botClient.SendMessage(chatId, "Использование: /addwinstreak [TAG] [Count]", cancellationToken: token);
                return;
            }

            long id = LogicLongCodeGenerator.ToId(args[1]);
            Account account = Accounts.Load(id);

            if (account == null)
            {
                await _botClient.SendMessage(chatId, "Ошибка: аккаунт не найден!", cancellationToken: token);
                return;
            }

            account.Avatar.WinStreak += int.Parse(args[2]);

            await _botClient.SendMessage(chatId, $"Аккаунту {args[1]} успешно добавлено {args[2]} побед подряд.", cancellationToken: token);
            Accounts.Save(account);
        }

        private async Task ExecuteShutdown(long chatId, CancellationToken token)
        {
            await _botClient.SendMessage(chatId, "Начинаю техническое обслуживание...", cancellationToken: token);
            Sessions.StartShutdown();
            AccountCache.SaveAll();
            AllianceCache.SaveAll();
            AccountCache.Started = false;
            AllianceCache.Started = false;
            await _botClient.SendMessage(chatId, "Техническое обслуживание начато!", cancellationToken: token);
        }

        private static async Task HandleErrorAsync(ITelegramBotClient botClient, Exception exception, CancellationToken token)
        {
            Console.WriteLine($"Ошибка при работе с Telegram API: {exception.Message}");
        }
    }

    public class OfferCreationState
    {
        public int Step { get; set; } = 0;
        public string[] Parameters { get; set; } = new string[26];
        public long ChatId { get; set; }
    }
}