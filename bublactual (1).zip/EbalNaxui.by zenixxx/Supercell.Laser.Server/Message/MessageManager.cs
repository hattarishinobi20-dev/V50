namespace Supercell.Laser.Server.Message
{
    using Supercell.Laser.Logic.Avatar;
    using Supercell.Laser.Logic.Avatar.Structures;
    using Supercell.Laser.Logic.Club;
    using Supercell.Laser.Logic.Command.Avatar;
    using Supercell.Laser.Logic.Data;
    using Supercell.Laser.Logic.Friends;
    using Supercell.Laser.Logic.Home;
    using Supercell.Laser.Logic.Home.Structures;
    using Supercell.Laser.Logic.Listener;
    using Supercell.Laser.Logic.Message.Account;
    using Supercell.Laser.Logic.Message.Club;
    using Supercell.Laser.Logic.Message.Friends;
    using Supercell.Laser.Logic.Message.Home;
    using Supercell.Laser.Logic.Message.Ranking;
    using Supercell.Laser.Logic.Message.Security;
    using Supercell.Laser.Logic.Message.Team;
    using Supercell.Laser.Logic.Message.Udp;
    using Supercell.Laser.Logic.Stream.Entry;
    using Supercell.Laser.Logic.Team;
    using Supercell.Laser.Server.Database;
    using Supercell.Laser.Server.Database.Models;
    using Supercell.Laser.Server.Logic.Game;
    using Supercell.Laser.Server.Networking;
    using Supercell.Laser.Server.Networking.Session;
    using Supercell.Laser.Server.Settings;
    using Supercell.Laser.Server.Logic;
    using Supercell.Laser.Server.Utils;
    using System.Diagnostics;
    using Supercell.Laser.Server.Database.Cache;
    using Supercell.Laser.Logic.Util;
    using Supercell.Laser.Logic.Battle;
    using Supercell.Laser.Logic.Message.Battle;
    using Supercell.Laser.Server.Networking.UDP.Game;
    using Supercell.Laser.Server.Networking.Security;
    using Supercell.Laser.Logic.Home.Items;
    using Supercell.Laser.Logic.Team.Stream;
    using Supercell.Laser.Logic.Message.Team.Stream;
    using Supercell.Laser.Logic.Message;
    using Supercell.Laser.Logic.Message.Account.Auth;
    using Supercell.Laser.Titan.Debug;
    using Supercell.Laser.Logic.Battle.Structures;
    using System.Reflection.Metadata.Ecma335;
    using Debugger = Titan.Debug.Debugger;
    using Supercell.Laser.Logic.Command.Home;
    using Supercell.Laser.Logic.Notification;
    using Org.BouncyCastle.Crypto;
    using Google.Protobuf.WellKnownTypes;
    using K4os.Compression.LZ4.Internal;
    using Masuda.Net.Models;
    using Org.BouncyCastle.Math;
    using Supercell.Laser.Logic.Battle.Component;
    using System.Security.Cryptography;
    using System.Security.Policy;
    using System.Threading;
    using Supercell.Laser.Logic.Data.Helper;
    using Supercell.Laser.Titan.Math;
    using Supercell.Laser.Logic.Battle.Level;
    using Supercell.Laser.Server.Handler;
    using System.Buffers;
    using System.Runtime.InteropServices;
    using Supercell.Laser.Logic.Home.Gatcha;
    using System.IO;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System;
    using System.Text.RegularExpressions;
    using Newtonsoft.Json.Linq;
    using Newtonsoft.Json;

    public class MessageManager
    {
        public Connection Connection { get; }

        public HomeMode HomeMode;

        public DateTime LastKeepAlive;

        private Dictionary<int, int> accrelay;
        public MessageManager(Connection connection)
        {
            Connection = connection;
            LastKeepAlive = DateTime.UtcNow;
        }

        public bool IsAlive()
        {
            return (int)(DateTime.UtcNow - LastKeepAlive).TotalSeconds < 15;
            //return true;
        }

        public void ReceiveMessage(GameMessage message)
        {
            if (message.GetMessageType() != 10100)
            {
                LobbyInfoMessage lim = new LobbyInfoMessage();
                lim.playercount = Sessions.Count;
                Connection.Send(lim);
            }
            switch (message.GetMessageType())
            {
               case 10100:
                    ClientHelloReceived((ClientHelloMessage)message);
                    break;
                case 10101:
                    LoginReceived((AuthenticationMessage)message);
                    break;
                case 10107:
                    ClientInfoReceived((ClientInfoMessage)message);
                    break;
                case 10108:
                    LastKeepAlive = DateTime.UtcNow;
                    //Connection.Send(new KeepAliveServerMessage());
                    break;
                case 10110:
                    AnalyticEventsReceived((AnalyticEventMessage)message);
                    break;
                case 10212:
                    ChangeName((ChangeAvatarNameMessage)message);
                    break;
                case 10177:
                    ClientInfoReceived((ClientInfoMessage)message);
                    break;
                case 10501:
                    AcceptFriendReceived((AcceptFriendMessage)message);
                    break;
                case 10502:
                    AddFriendReceived((AddFriendMessage)message);
                    break;
                case 10504:
                    AskForFriendListReceived((AskForFriendListMessage)message);
                    break;
                case 10506:
                    RemoveFriendReceived((RemoveFriendMessage)message);
                   break;
                case 12100:
                    CreatePlayerMapReceived((CreatePlayerMapMessage)message);
                    break;
                case 12101:
                    DeletePlayerMapReceived((DeletePlayerMapMessage)message);
                    break;
                case 12102:
                    GetPlayerMapsReceived((GetPlayerMapsMessage)message);
                    break;
                case 12103:
                    UpdatePlayerMapReceived((UpdatePlayerMapMessage)message);
                    break;
                case 12108:
                    GoHomeFromMapEditorReceived((GoHomeFromMapEditorMessage)message);
                    break;
                case 12110:
                    TeamSetPlayerMapReceived((TeamSetPlayerMapMessage)message);
                    break;
                case 14456:
                    GoHomeReceived((GoHomeMessage)message);
                    break;
                case 14102:
                    EndClientTurnReceived((EndClientTurnMessage)message);
                    break;
                case 18977:
                    MatchmakeRequestReceived((MatchmakeRequestMessage)message);
                    break;
                case 14104:
                    StartSpectateReceived((StartSpectateMessage)message);
                    break;
                case 14106:
                    CancelMatchMaking((CancelMatchmakingMessage)message);
                    break;
                case 14107:
                    StopSpectateReceived((StopSpectateMessage)message);
                    break;
                case 14109:
                    GoHomeFromOfflinePractiseReceived((GoHomeFromOfflinePractiseMessage)message);
                    break;
                case 15081:
                    GetPlayerProfile((GetPlayerProfileMessage)message);
                    break;
                case 14118:
                    SinglePlayerMatchRequestReceived((SinglePlayerMatchRequestMessage)message);
                    break;
                case 14166:
                    break;
                case 14301:
                    CreateAllianceReceived((CreateAllianceMessage)message);
                    break;
                case 14302:
                    AskForAllianceDataReceived((AskForAllianceDataMessage)message);
                    break;
                case 14303:
                    AskForJoinableAllianceListReceived((AskForJoinableAllianceListMessage)message);
                    break;
                case 14305:
                    JoinAllianceReceived((JoinAllianceMessage)message);
                    break;
                case 14307:
                    KickAllianceMemberReceived((KickAllianceMemberMessage)message);
                    break;
                case 14308:
                    LeaveAllianceReceived((LeaveAllianceMessage)message);
                    break;
                case 14315:
                    ChatToAllianceStreamReceived((ChatToAllianceStreamMessage)message);
                    break;
                case 14316:
                    ChangeAllianceSettingsReceived((ChangeAllianceSettingsMessage)message);
                    break;
                case 12541:
                    TeamCreateReceived((TeamCreateMessage)message);
                    break;
                case 14353:
                    TeamLeaveReceived((TeamLeaveMessage)message);
                    break;
                case 14354:
                    TeamChangeMemberSettingsReceived((TeamChangeMemberSettingsMessage)message);
                    break;
                case 14355:
                    TeamSetMemberReadyReceived((TeamSetMemberReadyMessage)message);
                    break;
                case 14357:
                    TeamToggleMemberSideReceived((TeamToggleMemberSideMessage)message);
                    break;
                case 14358:
                    TeamSpectateMessageReceived((TeamSpectateMessage)message);
                    break;
                case 14049:
                    TeamChatReceived((TeamChatMessage)message);
                    break;
                case 14361:
                    TeamMemberStatusReceived((TeamMemberStatusMessage)message);
                    break;
                case 14362:
                    TeamSetEventReceived((TeamSetEventMessage)message);
                    break;
                case 14363:
                    TeamSetLocationReceived((TeamSetLocationMessage)message);
                    break;
                case 14365:
                    TeamInviteReceived((TeamInviteMessage)message);
                    break;
                case 14366:
                    PlayerStatusReceived((PlayerStatusMessage)message);
                    break;
                case 14369:
                    TeamPremadeChatReceived((TeamPremadeChatMessage)message);
                    break;
                case 14373:
                    TeamBotSlotDisableReceived((TeamBotSlotDisableMessage)message);
                    break;
                case 14403:
                    GetLeaderboardReceived((GetLeaderboardMessage)message);
                    break;
                case 14479:
                    TeamInvitationResponseReceived((TeamInvitationResponseMessage)message);
                    break;
                case 14600:
                    AvatarNameCheckRequestReceived((AvatarNameCheckRequestMessage)message);
                    break;
                case 14881:
                    TeamRequestJoinReceived((TeamRequestJoinMessage)message);
                    break;
                case 18686:
                    SetSupportedCreatorReceived((SetSupportedCreatorMessage)message);
                    break;
                   
                case 10555: // ClientInputMessage
                    // Обработка входных данных игрока
                    var inputMsg = message as Supercell.Laser.Logic.Message.Battle.ClientInputMessage;
                    if (inputMsg != null && Connection.Avatar != null)
                    {
                        var battle = Supercell.Laser.Server.Logic.Game.Battles.Get(Connection.Avatar.BattleId);
                        if (battle != null)
                        {
                            while (inputMsg.Inputs.Count > 0)
                            {
                                var input = inputMsg.Inputs.Dequeue();
                                battle.AddClientInput(input, Connection.UdpSessionId);
                            }
                        }
                    }
                    break;
                default:
                    Logger.Print($"MessageManager::ReceiveMessage - no case for {message.GetType().Name} ({message.GetMessageType()})");
                    break;
            }
            //Logger.Print($"MessageManager::ReceiveMessage - received {message.GetType().Name} ({message.GetMessageType()})");
        }

        private void SetSupportedCreatorReceived(SetSupportedCreatorMessage message)
        {
            Console.WriteLine("Hiiiiiiii");
            string jsonTextc = File.ReadAllText("creators.json");
            dynamic jsonObjc = JsonConvert.DeserializeObject(jsonTextc);
            string jsonText = File.ReadAllText("promocodes.json");
            dynamic jsonObj = JsonConvert.DeserializeObject(jsonText);
            LogicSetSupportCreatorCommand command = new LogicSetSupportCreatorCommand();
            if (jsonObjc[message.Code] != null)
            {
                HomeMode.Home.CreatorCode = message.Code;
                string creator_tag = "";
                creator_tag = jsonObjc[message.Code];
                long qwidGems = LogicLongCodeGenerator.ToId(creator_tag);
                if (HomeMode.Home.CreatorCodes.Count == 0)
                {
                    HomeMode.Home.CreatorCodes.Add(message.Code);
                    Account targetAccountGems = Accounts.Load(qwidGems);
                    targetAccountGems.Avatar.Diamonds += 10;
                    Accounts.Save(targetAccountGems);

                    LogicGiveDeliveryItemsCommand _command = new LogicGiveDeliveryItemsCommand();
                    DeliveryUnit unit = new DeliveryUnit(100);
                    GatchaDrop reward = new GatchaDrop(8);
                    reward.Count = 30;
                    unit.AddDrop(reward);
                    _command.DeliveryUnits.Add(unit);
                    _command.Execute(HomeMode);

                    AvailableServerCommandMessage _message = new AvailableServerCommandMessage();
                    _message.Command = _command;
                    Connection.Send(_message);
                }
                else {
                    Account targetAccountGems = Accounts.Load(qwidGems);
                    targetAccountGems.Avatar.Diamonds += 5;
                    Accounts.Save(targetAccountGems);
                }

                command.Code = message.Code;
                command.Execute(HomeMode);
                AvailableServerCommandMessage serverCommandMessage = new AvailableServerCommandMessage();
                serverCommandMessage.Command = command;
                Connection.Send(serverCommandMessage);
            }
            else if (jsonObj[message.Code] != null)
            {
                if (jsonObj[message.Code] == null) return;
                string _value = jsonObj[message.Code];

                if (_value.StartsWith("gems"))
                {
                    int gems = 0;
                    string numberPart = _value[4..]; // Получаем часть строки после "gems"

                    if (int.TryParse(numberPart, out int parsedValue))
                    {
                        gems = parsedValue;
                        LogicGiveDeliveryItemsCommand _command = new LogicGiveDeliveryItemsCommand();
                        DeliveryUnit unit = new DeliveryUnit(100);
                        GatchaDrop reward = new GatchaDrop(8);
                        reward.Count = gems;
                        unit.AddDrop(reward);

                        _command.DeliveryUnits.Add(unit);
                        _command.Execute(HomeMode);

                        AvailableServerCommandMessage _message = new AvailableServerCommandMessage();
                        _message.Command = _command;
                        Connection.Send(_message);
                    }
                    else return;
                }

                if (_value.StartsWith("coin"))
                {
                    int gems = 0;
                    string numberPart = _value[4..]; // Получаем часть строки после "gems"

                    if (int.TryParse(numberPart, out int parsedValue))
                    {
                        gems = parsedValue;
                        LogicGiveDeliveryItemsCommand _command = new LogicGiveDeliveryItemsCommand();
                        DeliveryUnit unit = new DeliveryUnit(100);
                        GatchaDrop reward = new GatchaDrop(7);
                        reward.Count = gems;
                        unit.AddDrop(reward);

                        _command.DeliveryUnits.Add(unit);
                        _command.Execute(HomeMode);

                        AvailableServerCommandMessage _message = new AvailableServerCommandMessage();
                        _message.Command = _command;
                        Connection.Send(_message);
                    }
                    else return;
                }

                if (_value.StartsWith("credit"))
                {
                    int gems = 0;
                    string numberPart = _value[6..]; // Получаем часть строки после "gems"

                    if (int.TryParse(numberPart, out int parsedValue))
                    {
                        gems = parsedValue;
                        LogicGiveDeliveryItemsCommand _command = new LogicGiveDeliveryItemsCommand();
                        DeliveryUnit unit = new DeliveryUnit(100);
                        GatchaDrop reward = new GatchaDrop(22);
                        reward.Count = gems;
                        unit.AddDrop(reward);

                        _command.DeliveryUnits.Add(unit);
                        _command.Execute(HomeMode);

                        AvailableServerCommandMessage _message = new AvailableServerCommandMessage();
                        _message.Command = _command;
                        Connection.Send(_message);
                    }
                    else return;
                }

                if (_value.StartsWith("title"))
                {
                    int gems = 0;
                    string numberPart = _value[5..]; // Получаем часть строки после "gems"

                    if (int.TryParse(numberPart, out int parsedValue))
                    {
                        gems = parsedValue;
                        LogicGiveDeliveryItemsCommand _command = new LogicGiveDeliveryItemsCommand();
                        DeliveryUnit unit = new DeliveryUnit(100);
                        GatchaDrop reward = new GatchaDrop(11);
                        reward.Count = 1;
                        reward.DataGlobalId = 76000000 + gems;
                        unit.AddDrop(reward);

                        _command.DeliveryUnits.Add(unit);
                        _command.Execute(HomeMode);

                        AvailableServerCommandMessage _message = new AvailableServerCommandMessage();
                        _message.Command = _command;
                        Connection.Send(_message);
                    }
                    else return;
                }

                if (_value.StartsWith("mega"))
                {
                    int gems = 0;
                    string numberPart = _value[4..]; // Получаем часть строки после "gems"

                    if (int.TryParse(numberPart, out int parsedValue))
                    {
                        gems = parsedValue;
                        var _command = new LogicGiveDeliveryItemsCommand();
                        for (int i = 0; i < gems; i++)
                        {
                            DeliveryUnit unit = new DeliveryUnit(11); // 11 — MegaBox
                            HomeMode.SimulateGatcha(unit);
                            _command.DeliveryUnits.Add(unit);
                        }
                        _command.Execute(HomeMode);
                        AvailableServerCommandMessage __message = new AvailableServerCommandMessage();
                        __message.Command = _command;
                        Connection.Send(__message);
                    }
                    else return;
                }

                if (_value.StartsWith("omega"))
                {
                    int gems = 0;
                    string numberPart = _value[5..]; // Получаем часть строки после "gems"

                    if (int.TryParse(numberPart, out int parsedValue))
                    {
                        gems = parsedValue;
                        var _command = new LogicGiveDeliveryItemsCommand();
                        for (int i = 0; i < gems; i++)
                        {
                            DeliveryUnit unit = new DeliveryUnit(13); // 11 — MegaBox
                            HomeMode.SimulateGatcha(unit);
                            _command.DeliveryUnits.Add(unit);
                        }
                        _command.Execute(HomeMode);
                        AvailableServerCommandMessage __message = new AvailableServerCommandMessage();
                        __message.Command = _command;
                        Connection.Send(__message);
                    }
                    else return;
                }

                if (_value.StartsWith("vip"))
                {
                    int gems = 0;
                    string numberPart = _value[3..]; // Получаем часть строки после "gems"

                    if (int.TryParse(numberPart, out int parsedValue))
                    {
                        gems = parsedValue;
                        HomeMode.Avatar.IsVIP = true;
                        HomeMode.Avatar.VIPExpire = DateTime.UtcNow.AddDays(gems);
                    }
                    else return;
                }

                if (_value.StartsWith("bling"))
                {
                    int gems = 0;
                    string numberPart = _value[5..]; // Получаем часть строки после "gems"

                    if (int.TryParse(numberPart, out int parsedValue))
                    {
                        gems = parsedValue;
                        LogicGiveDeliveryItemsCommand _command = new LogicGiveDeliveryItemsCommand();
                        DeliveryUnit unit = new DeliveryUnit(100);
                        GatchaDrop reward = new GatchaDrop(25);
                        reward.Count = gems;
                        unit.AddDrop(reward);

                        _command.DeliveryUnits.Add(unit);
                        _command.Execute(HomeMode);

                        AvailableServerCommandMessage _message = new AvailableServerCommandMessage();
                        _message.Command = _command;
                        Connection.Send(_message);
                    }
                    else return;
                }

                if (_value.StartsWith("pp"))
                {
                    int gems = 0;
                    string numberPart = _value[2..]; // Получаем часть строки после "gems"

                    if (int.TryParse(numberPart, out int parsedValue))
                    {
                        gems = parsedValue;
                        LogicGiveDeliveryItemsCommand _command = new LogicGiveDeliveryItemsCommand();
                        DeliveryUnit unit = new DeliveryUnit(100);
                        GatchaDrop reward = new GatchaDrop(24);
                        reward.Count = gems;
                        unit.AddDrop(reward);

                        _command.DeliveryUnits.Add(unit);
                        _command.Execute(HomeMode);

                        AvailableServerCommandMessage _message = new AvailableServerCommandMessage();
                        _message.Command = _command;
                        Connection.Send(_message);
                    }
                    else return;
                }

                else if (_value.StartsWith("brawler"))
                {
                    int gems = 0;
                    string numberPart = _value[7..]; // Получаем часть строки после "gems"

                    if (int.TryParse(numberPart, out int parsedValue))
                    {
                        gems = parsedValue;
                        LogicGiveDeliveryItemsCommand _command = new LogicGiveDeliveryItemsCommand();
                        DeliveryUnit unit = new DeliveryUnit(100);
                        GatchaDrop reward = new GatchaDrop(1);
                        reward.Count = 1;
                        reward.DataGlobalId = 16000000 + gems;
                        unit.AddDrop(reward);
                        _command.DeliveryUnits.Add(unit);
                        _command.Execute(HomeMode);

                        AvailableServerCommandMessage _message = new AvailableServerCommandMessage();
                        _message.Command = _command;
                        Connection.Send(_message);
                    }
                    else return;
                }

                else if (_value == "bp")
                {
                    if (!HomeMode.Home.HasPremiumPass)
                    {
                        HomeMode.Home.HasPremiumPass = true;
                        // AuthenticationFailedMessage loginFailed = new AuthenticationFailedMessage();
                        // loginFailed.ErrorCode = 1;
                        // loginFailed.Message = "Готово!";
                        // Connection.Send(loginFailed);
                    }
                    else
                    {
                        LogicGiveDeliveryItemsCommand _command = new LogicGiveDeliveryItemsCommand();
                        DeliveryUnit unit = new DeliveryUnit(100);
                        GatchaDrop reward = new GatchaDrop(8);
                        reward.Count = 120;
                        unit.AddDrop(reward);
                        _command.DeliveryUnits.Add(unit);
                        _command.Execute(HomeMode);

                        AvailableServerCommandMessage _message = new AvailableServerCommandMessage();
                        _message.Command = _command;
                        Connection.Send(_message);
                    }
                }
                else if (_value == "bp+")
                {
                    if (!HomeMode.Home.HasPremiumPassPlus)
                    {
                        HomeMode.Home.HasPremiumPassPlus = true;
                        HomeMode.Home.BrawlPassTokens += 8000;
                        // AuthenticationFailedMessage loginFailed = new AuthenticationFailedMessage();
                        // loginFailed.ErrorCode = 1;
                        // loginFailed.Message = "Готово!";
                        // Connection.Send(loginFailed);
                    }
                    else
                    {
                        LogicGiveDeliveryItemsCommand _command = new LogicGiveDeliveryItemsCommand();
                        DeliveryUnit unit = new DeliveryUnit(100);
                        GatchaDrop reward = new GatchaDrop(8);
                        reward.Count = 170;
                        unit.AddDrop(reward);
                        _command.DeliveryUnits.Add(unit);
                        _command.Execute(HomeMode);

                        AvailableServerCommandMessage _message = new AvailableServerCommandMessage();
                        _message.Command = _command;
                        Connection.Send(_message);
                    }
                }


                else if (_value.StartsWith("skin"))
                {
                    int gems = 0;
                    string numberPart = _value[4..]; // Получаем часть строки после "gems"

                    if (int.TryParse(numberPart, out int parsedValue))
                    {
                        gems = parsedValue;
                        LogicGiveDeliveryItemsCommand _command = new LogicGiveDeliveryItemsCommand();
                        DeliveryUnit unit = new DeliveryUnit(100);
                        GatchaDrop reward = new GatchaDrop(9);
                        reward.SkinGlobalId = GlobalId.CreateGlobalId(29, gems);
                        unit.AddDrop(reward);
                        _command.DeliveryUnits.Add(unit);
                        SkinData skinData = DataTables.Get(DataType.Skin).GetDataWithId<SkinData>(GlobalId.CreateGlobalId(29, gems));
                        _command.Execute(HomeMode);

                        AvailableServerCommandMessage _message = new AvailableServerCommandMessage();
                        _message.Command = _command;
                        Connection.Send(_message);

                    }
                    else return;
                }



                else if (_value.StartsWith("offer"))
                {
                    int gems = 0;

                    if (HomeMode.Home.PaidOffers.Contains(_value))
                    {
                        if (_value == "offer_test") gems = 170;
                        else if (_value == "offer_testz") gems = 2000;
                        else if (_value == "offer_testv") gems = 3450;
                    }

                    LogicGiveDeliveryItemsCommand _command = new LogicGiveDeliveryItemsCommand();
                    DeliveryUnit unit = new DeliveryUnit(100);
                    GatchaDrop reward = new GatchaDrop(8);
                    reward.Count = gems;
                    unit.AddDrop(reward);
                    _command.DeliveryUnits.Add(unit);
                    _command.Execute(HomeMode);
                }

                HomeMode.Home.PaidOffers.Add(_value);
                // HomeMode.Home.RefreshOffers();
                // LogicOffersChangedMessage refreshoffers = new LogicOffersChangedMessage();
                // refreshoffers.OfferBundles = HomeMode.Home.OfferBundles;
                // HomeMode.GameListener.SendMessage(refreshoffers);

                jsonObj.Remove(message.Code);
                string updatedJson = JsonConvert.SerializeObject(jsonObj, Formatting.Indented);
                File.WriteAllText("promocodes.json", updatedJson); // Записываем обновленный JSON обратно в файл
            }
            else
            {
                SetSupportedCreatorResponceMessage responseMessage = new SetSupportedCreatorResponceMessage();
                responseMessage.creator = message.Code;
                Connection.Send(responseMessage);
            }


        }

        private void StartBrawlTVReceived(StartBrawlTVMessage message)
        {
            LogicAddNotificationCommand logicAddNotificationCommand = new LogicAddNotificationCommand();
            logicAddNotificationCommand.Notification = new FloaterTextNotification("BrawlTV not initialized");
            AvailableServerCommandMessage availableServerCommandMessage = new AvailableServerCommandMessage();
            availableServerCommandMessage.Command = logicAddNotificationCommand;
            HomeMode.GameListener.SendMessage(availableServerCommandMessage);
            logicAddNotificationCommand.Execute(HomeMode);
            AvailableServerCommandMessage server = new AvailableServerCommandMessage();
            server.Command = logicAddNotificationCommand;
            HomeMode.GameListener.SendMessage(server);
        }
        private void DoNotDisturbReceived(DoNotDisturbMessage message)
        {
            LogicSetDoNotDisturb command = new LogicSetDoNotDisturb();
            command.DoNotDistrub = message.state;
            command.Execute(HomeMode);
            AvailableServerCommandMessage serverCommand = new AvailableServerCommandMessage();
            serverCommand.Command = command;
            HomeMode.GameListener.SendMessage(serverCommand);
        }
        private void SetCountryReceived(SetCountryMessage message)
        {
            SetCountryResponseMessage response = new SetCountryResponseMessage();
            response.CountryID = message.CountryID;
            HomeMode.Avatar.Region = DataTables.Get(14).GetDataWithId<RegionData>(message.CountryID).Name;
            Console.WriteLine(HomeMode.Avatar.Region);
            Connection.Send(response);
        }
        private void GetBattleLogReceived(GetBattleLogMessage message)
        {
            BattleLogMessage log = new BattleLogMessage();
            log.homeMode = HomeMode;
            Connection.Send(log);
        }
        private void AlliancePremadeChatReceived(AlliancePremadeChatMessage message)
        {
            // skip
        }
        private void TeamSpectateMessageReceived(TeamSpectateMessage message)
        {
            TeamEntry team = Teams.Get(message.TeamId);
            if (team == null) return;
            HomeMode.Avatar.TeamId = team.Id;
            TeamMember member = new TeamMember();
            member.AccountId = HomeMode.Avatar.AccountId;
            member.CharacterId = HomeMode.Home.CharacterId;
            member.DisplayData = new PlayerDisplayData(HomeMode.Home.ThumbnailId, HomeMode.Home.NameColorId, HomeMode.Avatar.Name);
            member.homeMode = HomeMode;
            Hero hero = HomeMode.Avatar.GetHero(HomeMode.Home.CharacterId);
            member.HeroTrophies = hero.Trophies;
            member.HeroHighestTrophies = hero.HighestTrophies;
            member.HeroLevel = hero.PowerLevel;
            member.IsOwner = false;
            member.State = 0;
            if (!team.AddMember(member))
            {
                SendNotification("Команда заполнена. Пожалуйста, попробуйте позже.");
                return;
            }
            team.TeamUpdated();
        }

        private void TeamPremadeChatReceived(TeamPremadeChatMessage message)
        {
            if (HomeMode.Avatar.TeamId <= 0) return;

            TeamEntry team = GetTeam();
            if (team == null) return;

            QuickChatStreamEntry entry = new QuickChatStreamEntry();
            entry.AccountId = HomeMode.Avatar.AccountId;
            entry.TargetId = message.TargetId;
            entry.Name = HomeMode.Avatar.Name;

            if (message.TargetId > 0)
            {
                TeamMember member = team.GetMember(message.TargetId);
                if (member != null)
                {
                    entry.TargetPlayerName = member.DisplayData.Name;
                }
            }

            entry.MessageDataId = message.MessageDataId;
            entry.Unknown1 = message.Unknown1;
            entry.Unknown2 = message.Unknown2;

            team.AddStreamEntry(entry);
        }

        private void TeamBotSlotDisableReceived(TeamBotSlotDisableMessage message)
        {
            if (HomeMode.Avatar.TeamId <= 0) return;

            TeamEntry team = GetTeam();
            if (team == null) return;

            if (message.Disable)
            {
                team.DisabledBots.Add(message.BotSlot);
            }
            else team.DisabledBots.Remove(message.BotSlot);
            team.TeamUpdated();
        }

        private void TeamToggleMemberSideReceived(TeamToggleMemberSideMessage message)
        {
            if (HomeMode.Avatar.TeamId <= 0) return;

            TeamEntry team = GetTeam();
            if (team == null) return;
            team.GetMember(message.Longs[0]).TeamIndex = message.Unk1 >= 3 ? 1 : 0;
            team.TeamUpdated();
        }

        private void TeamChatReceived(TeamChatMessage message)
        {
            if (HomeMode.Avatar.IsBanned)
            {
                var left = HomeMode.Avatar.BanUntil.HasValue ? HomeMode.Avatar.BanUntil.Value - DateTime.UtcNow : (TimeSpan?)null;
                SendBanNotification(
                    $"Вы не можете писать в чат, пока не пройдет бан.\n" +
                    $"{HomeMode.Avatar.BanReason ?? "Причина не указана."}" +
                    (left.HasValue ? $"\nДо окончания: {left.Value.Hours} ч. {left.Value.Minutes} мин." : "")
                );
                return;
            }

            if (message.Message.StartsWith("/"))
            {
                CmdHandler.HandleCmd(message.Message, HomeMode.Avatar.AccountId);
                return;
            }

            if (HomeMode.Avatar.TeamId <= 0) return;

            TeamEntry team = GetTeam();
            if (team == null) return;

            ChatStreamEntry entry = new ChatStreamEntry();
            entry.AccountId = HomeMode.Avatar.AccountId;
            entry.Name = HomeMode.Avatar.Name;
            entry.Message = message.Message;

            team.AddStreamEntry(entry);
            team.TeamUpdated();
        }

        private void AvatarNameCheckRequestReceived(AvatarNameCheckRequestMessage message)
        {
            LogicChangeAvatarNameCommand command = new LogicChangeAvatarNameCommand();
            command.Name = message.Name;
            command.ChangeNameCost = 0;
            command.Execute(HomeMode);
            AvailableServerCommandMessage serverCommandMessage = new AvailableServerCommandMessage();
            serverCommandMessage.Command = command;
            Connection.Send(serverCommandMessage);
        }
        private void TeamRequestJoinReceived(TeamRequestJoinMessage message)
        {
            TeamEntry team = Teams.Get(message.TeamId);
            if (team == null) return;

            // Check if team is full
            if (!team.CanAddMember())
            {
                LogicAddNotificationCommand logicAddNotificationCommand = new LogicAddNotificationCommand();
                logicAddNotificationCommand.Notification = new Supercell.Laser.Logic.Notification.FloaterTextNotification("Команда заполнена. Пожалуйста, попробуйте позже.");
                AvailableServerCommandMessage availableServerCommandMessage = new AvailableServerCommandMessage();
                availableServerCommandMessage.Command = logicAddNotificationCommand;
                HomeMode.GameListener.SendMessage(availableServerCommandMessage);
                return;
            }

            TeamEntry team1 = Teams.Get(HomeMode.Avatar.TeamId);
            if (team1 != null)
            {
                TeamMember entry = team1.GetMember(HomeMode.Avatar.AccountId);

                if (entry == null) return;
                HomeMode.Avatar.TeamId = -1;

                team1.Members.Remove(entry);

                Connection.Send(new TeamLeftMessage());
                team1.TeamUpdated();

                if (team1.Members.Count == 0)
                {
                    Teams.Remove(team1.Id);
                }
            }

            TeamJoinRequest request = new TeamJoinRequest();
            // You may need to fill in necessary details for the request here
            team.JoinRequests.Add(request);
            team.TeamUpdated();

            LogicAddNotificationCommand joinRequestNotification = new LogicAddNotificationCommand();
            joinRequestNotification.Notification = new Supercell.Laser.Logic.Notification.FloaterTextNotification("Запрос на присоединение отправлен. Ожидайте ответа.");
            AvailableServerCommandMessage joinRequestMessage = new AvailableServerCommandMessage();
            joinRequestMessage.Command = joinRequestNotification;
            HomeMode.GameListener.SendMessage(joinRequestMessage);
        }
        private void AnalyticEventsReceived(AnalyticEventMessage message)
        {
            //Debugger.Print(message.str1 +" "+ message.str2);
            ;
        }

        private void TeamSetEventReceived(TeamSetEventMessage message)
        {
            if (HomeMode.Avatar.TeamId <= 0) return;

            TeamEntry team = GetTeam();
            if (team == null) return;

            EventData data = Events.GetEvent(message.EventSlot);
            if (data == null) return;

            team.EventSlot = message.EventSlot;
            team.LocationId = data.LocationId;
            team.Type = 0;
            HomeMode.Home.EventId = message.EventSlot;
            team.TeamUpdated();
            FriendOnlineStatusEntryMessage entryMessage = new FriendOnlineStatusEntryMessage();
            entryMessage.AvatarId = HomeMode.Avatar.AccountId;
            entryMessage.PlayerStatus = HomeMode.Avatar.PlayerStatus;
            entryMessage.AllianceTeamEntry = team;

            foreach (Friend friend in HomeMode.Avatar.Friends.ToArray())
            {
                if (LogicServerListener.Instance.IsPlayerOnline(friend.AccountId))
                {
                    LogicServerListener.Instance.GetGameListener(friend.AccountId).SendTCPMessage(entryMessage);
                }
            }

        }
        private void GetPlayerMapsReceived(GetPlayerMapsMessage message)
        {
            Connection.Send(new PlayerMapsMessage()
            {
                maps = Connection.Home.PlayerMaps.ToArray()
            });
        }
        private void CreatePlayerMapReceived(CreatePlayerMapMessage message)
        {
            PlayerMap map = new PlayerMap()
            {
                MapEnvironmentData = message.PMED,
                MapName = message.name,
                GMV = message.GMV,
                MapId = RandomNumberGenerator.GetInt32(0, 2147483647),
                AccountId = Connection.Avatar.AccountId,
                AvatarName = Connection.Avatar.Name
            };
            Connection.Home.PlayerMaps.Add(map);
            Connection.Send(new CreatePlayerMapResponseMessage()
            {
                map = map
            });
        }
        private void UpdatePlayerMapReceived(UpdatePlayerMapMessage message)
        {
            PlayerMap map = Connection.Home.PlayerMaps.Find(map => map.MapId == message.MapId);
            if (map == null)
            {
                Connection.Send(new UpdatePlayerMapResponseMessage()
                {
                    ErrorCode = 1
                });
                return;
            }
            map.MapData = message.MapData;
            Connection.Send(new UpdatePlayerMapResponseMessage()
            {
                MapId = message.MapId
            });
        }
        private void DeletePlayerMapReceived(DeletePlayerMapMessage message)
        {
            PlayerMap map = Connection.Home.PlayerMaps.Find(map => map.MapId == message.MapId);
            if (map == null)
            {
                Connection.Send(new DeletePlayerMapResponseMessage()
                {
                    ErrorCode = 1
                });
                return;
            }
            Connection.Home.PlayerMaps.Remove(map);
            Connection.Send(new DeletePlayerMapResponseMessage()
            {
                MapId = message.MapId
            });
        }
        private void TeamSetPlayerMapReceived(TeamSetPlayerMapMessage message)
        {
            if (HomeMode.Avatar.TeamId <= 0) return;

            TeamEntry team = GetTeam();
            if (team == null) return;

            PlayerMap map = Connection.Home.PlayerMaps.Find(map => map.MapId == message.mapid);
            if (map == null) return;

            team.BattlePlayerMap = new BattlePlayerMap(map);
            team.Type = 1;
            team.TeamUpdated();

        }
        private BattleMode SpectatedBattle;
        private void StopSpectateReceived(StopSpectateMessage message)
        {
            if (SpectatedBattle != null)
            {
                SpectatedBattle.RemoveSpectator(Connection.UdpSessionId);
                SpectatedBattle = null;
            }

            if (Connection.Home != null && Connection.Avatar != null)
            {
                OwnHomeDataMessage ohd = new OwnHomeDataMessage();
                ohd.Home = Connection.Home;
                ohd.Avatar = Connection.Avatar;
                Connection.Send(ohd);
            }
        }

        private void StartSpectateReceived(StartSpectateMessage message)
        {
            Account data = Accounts.Load(message.AccountId);
            if (data == null) return;

            ClientAvatar avatar = data.Avatar;
            long battleId = avatar.BattleId;

            BattleMode battle = Battles.Get(battleId);
            if (battle == null) return;

            SpectatedBattle = battle;
            UDPSocket socket = UDPGateway.CreateSocket();
            socket.Battle = battle;
            socket.IsSpectator = true;
            socket.TCPConnection = Connection;
            Connection.UdpSessionId = socket.SessionId;
            battle.AddSpectator(socket.SessionId, new UDPGameListener(socket, Connection));

            StartLoadingMessage startLoading = battle.Dummy;
            startLoading.TeamIndex = 0;
            startLoading.OwnIndex = 0;
            startLoading.SpectateMode = 1;

            Connection.Avatar.UdpSessionId = Connection.UdpSessionId;
            startLoading.Players.AddRange(battle.GetPlayers());
            Connection.Send(startLoading);

            UdpConnectionInfoMessage info = new UdpConnectionInfoMessage();
            info.SessionId = Connection.UdpSessionId;
            info.ServerAddress = Configuration.Instance.UdpHost;
            info.ServerPort = Configuration.Instance.UdpPort;
            Connection.Send(info);
        }

        private void GoHomeFromOfflinePractiseReceived(GoHomeFromOfflinePractiseMessage message)
        {
            if (Connection.Home != null && Connection.Avatar != null)
            {
                if (Connection.Avatar.IsTutorialState())
                {
                    Connection.Avatar.SkipTutorial();
                }

                OwnHomeDataMessage ohd = new OwnHomeDataMessage();
                ohd.Home = Connection.Home;
                ohd.Avatar = Connection.Avatar;
                Connection.Send(ohd);
            }
        }

        private void TeamSetLocationReceived(TeamSetLocationMessage message)
        {
            if (HomeMode.Avatar.TeamId <= 0) return;

            TeamEntry team = GetTeam();
            if (team == null) return;
            team.LocationId = message.locid;
            team.CustomModifiers = message.CustomModifiers.ToList();
            team.Type = 1;
            team.TeamUpdated();
            FriendOnlineStatusEntryMessage entryMessage = new FriendOnlineStatusEntryMessage();
            entryMessage.AvatarId = HomeMode.Avatar.AccountId;
            entryMessage.PlayerStatus = HomeMode.Avatar.PlayerStatus;
            entryMessage.AllianceTeamEntry = team;

            foreach (Friend friend in HomeMode.Avatar.Friends.ToArray())
            {
                if (LogicServerListener.Instance.IsPlayerOnline(friend.AccountId))
                {
                    LogicServerListener.Instance.GetGameListener(friend.AccountId).SendTCPMessage(entryMessage);
                }
            }
            //HomeMode.Home.EventId = message.locid;

        }

        private void ChangeAllianceSettingsReceived(ChangeAllianceSettingsMessage message)
        {
            if (HomeMode.Avatar.AllianceId <= 0) return;

            if (HomeMode.Avatar.AllianceRole != AllianceRole.Leader) return;

            Alliance alliance = Alliances.Load(HomeMode.Avatar.AllianceId);
            if (alliance == null) return;

            if (message.BadgeId >= 8000000 && message.BadgeId < 8000000 + DataTables.Get(DataType.AllianceBadge).Count)
            {
                alliance.AllianceBadgeId = message.BadgeId;
            }
            else
            {
                alliance.AllianceBadgeId = 8000000;
            }

            alliance.Description = message.Description;
            alliance.RequiredTrophies = message.RequiredTrophies;

            Connection.Send(new AllianceResponseMessage()
            {
                ResponseType = 10
            });

            MyAllianceMessage myAlliance = new MyAllianceMessage();
            myAlliance.Role = HomeMode.Avatar.AllianceRole;
            myAlliance.OnlineMembers = alliance.OnlinePlayers;
            myAlliance.AllianceHeader = alliance.Header;
            Connection.Send(myAlliance);
        }

        private void KickAllianceMemberReceived(KickAllianceMemberMessage message)
        {
            if (HomeMode.Avatar.AllianceId <= 0) return;

            Alliance alliance = Alliances.Load(HomeMode.Avatar.AllianceId);
            if (alliance == null) return;

            AllianceMember member = alliance.GetMemberById(message.AccountId);
            if (member == null) return;

            ClientAvatar avatar = Accounts.Load(message.AccountId).Avatar;

            if (HomeMode.Avatar.AllianceRole <= avatar.AllianceRole) return;

            alliance.Members.Remove(member);
            avatar.AllianceId = -1;

            AllianceStreamEntry entry = new AllianceStreamEntry();
            entry.AuthorId = HomeMode.Avatar.AccountId;
            entry.AuthorName = HomeMode.Avatar.Name;
            entry.Id = ++alliance.Stream.EntryIdCounter;
            entry.PlayerId = avatar.AccountId;
            entry.PlayerName = avatar.Name;
            entry.Type = 4;
            entry.Event = 1; // kicked
            entry.AuthorRole = HomeMode.Avatar.AllianceRole;
            alliance.AddStreamEntry(entry);

            AllianceResponseMessage response = new AllianceResponseMessage();
            response.ResponseType = 70;
            Connection.Send(response);

            if (LogicServerListener.Instance.IsPlayerOnline(avatar.AccountId))
            {
                LogicServerListener.Instance.GetGameListener(avatar.AccountId).SendTCPMessage(new AllianceResponseMessage()
                {
                    ResponseType = 100
                });
                LogicServerListener.Instance.GetGameListener(avatar.AccountId).SendTCPMessage(new MyAllianceMessage());
            }
        }

        private void TeamSetMemberReadyReceived(TeamSetMemberReadyMessage message)
        {
            TeamEntry team = Teams.Get(HomeMode.Avatar.TeamId);
            if (team == null) return;
            /*
            if (HomeMode.Home.Character.Disabled)
            {
                Connection.Send(new OutOfSyncMessage());
                return;
            }
            */

            TeamMember member = team.GetMember(HomeMode.Avatar.AccountId);
            if (member == null) return;

            member.IsReady = message.IsReady;

            team.TeamUpdated();

            if (team.IsEveryoneReady())
            {
                Teams.StartGame(team);
            }
        }

        private void TeamChangeMemberSettingsReceived(TeamChangeMemberSettingsMessage message)
        {
            TeamEntry team = Teams.Get(HomeMode.Avatar.TeamId);
            if (team == null) return;

            TeamMember member = team.GetMember(HomeMode.Avatar.AccountId);
            if (member == null) return;

            team.TeamUpdated();
        }

        private void TeamMemberStatusReceived(TeamMemberStatusMessage message)
        {
            TeamEntry team = Teams.Get(HomeMode.Avatar.TeamId);
            if (team == null) return;

            TeamMember member = team.GetMember(HomeMode.Avatar.AccountId);
            if (member == null) return;

            member.State = message.Status;
            team.TeamUpdated();
        }

        private void TeamInvitationResponseReceived(TeamInvitationResponseMessage message)
        {
            bool isAccept = message.Response == 1;

            TeamEntry team = Teams.Get(message.TeamId);
            if (team == null) return;

            TeamInviteEntry invite = team.GetInviteById(HomeMode.Avatar.AccountId);
            if (invite == null) return;

            team.Invites.Remove(invite);

            if (isAccept)
            {
                // Проверяем, не заполнена ли команда
                if (!team.CanAddMember())
                {
                    SendNotification("Команда заполнена. Пожалуйста, попробуйте позже.");
                    return;
                }
                
                TeamMember member = new TeamMember();
                member.AccountId = HomeMode.Avatar.AccountId;
                member.CharacterId = HomeMode.Home.CharacterId;
                member.DisplayData = new PlayerDisplayData(HomeMode.Home.ThumbnailId, HomeMode.Home.NameColorId, HomeMode.Avatar.Name);
                member.homeMode = HomeMode;
                Hero hero = HomeMode.Avatar.GetHero(HomeMode.Home.CharacterId);
                member.HeroTrophies = hero.Trophies;
                member.HeroHighestTrophies = hero.HighestTrophies;
                member.HeroLevel = hero.PowerLevel;
                member.IsOwner = false;
                member.State = 0;
                if (!team.AddMember(member))
                {
                    SendNotification("Команда заполнена. Пожалуйста, попробуйте позже.");
                    return;
                }
                HomeMode.Avatar.TeamId = team.Id;
            }

            team.TeamUpdated();
        }

        private TeamEntry GetTeam()
        {
            return Teams.Get(HomeMode.Avatar.TeamId);
        }

        private void TeamInviteReceived(TeamInviteMessage message)
        {
            TeamEntry team = GetTeam();
            if (team == null) return;

            Account data = Accounts.Load(message.AvatarId);
            if (data == null) return;

            TeamInviteEntry entry = new TeamInviteEntry();
            entry.Slot = message.Team;
            entry.Name = data.Avatar.Name;
            entry.Id = message.AvatarId;
            entry.InviterId = HomeMode.Avatar.AccountId;

            team.Invites.Add(entry);

            team.TeamUpdated();

            LogicGameListener gameListener = LogicServerListener.Instance.GetGameListener(message.AvatarId);
            if (gameListener != null)
            {
                TeamInvitationMessage teamInvitationMessage = new TeamInvitationMessage();
                teamInvitationMessage.TeamId = team.Id;

                Friend friendEntry = new Friend();
                friendEntry.AccountId = HomeMode.Avatar.AccountId;
                friendEntry.DisplayData = new PlayerDisplayData(HomeMode.Home.ThumbnailId, HomeMode.Home.NameColorId, HomeMode.Avatar.Name);
                friendEntry.Trophies = HomeMode.Avatar.Trophies;
                teamInvitationMessage.Unknown = 1;
                teamInvitationMessage.FriendEntry = friendEntry;

                gameListener.SendTCPMessage(teamInvitationMessage);
            }
        }

        private void TeamLeaveReceived(TeamLeaveMessage message)
        {
            if (HomeMode.Avatar.TeamId <= 0) return;

            TeamEntry team = Teams.Get(HomeMode.Avatar.TeamId);

            if (team == null)
            {
                Logger.Print("TeamLeave - Team is NULL!");
                HomeMode.Avatar.TeamId = -1;
                Connection.Send(new TeamLeftMessage());
                return;
            }

            TeamMember entry = team.GetMember(HomeMode.Avatar.AccountId);

            if (entry == null) return;
            HomeMode.Avatar.TeamId = -1;

            team.Members.Remove(entry);

            Connection.Send(new TeamLeftMessage());
            team.TeamUpdated();

            if (team.Members.Count == 0)
            {
                Teams.Remove(team.Id);
            }
            FriendOnlineStatusEntryMessage entryMessage = new FriendOnlineStatusEntryMessage();
            entryMessage.AvatarId = HomeMode.Avatar.AccountId;
            entryMessage.PlayerStatus = HomeMode.Avatar.PlayerStatus;

            foreach (Friend friend in HomeMode.Avatar.Friends.ToArray())
            {
                if (LogicServerListener.Instance.IsPlayerOnline(friend.AccountId))
                {
                    LogicServerListener.Instance.GetGameListener(friend.AccountId).SendTCPMessage(entryMessage);
                }
            }
            //TeamCreateReceived(new TeamCreateMessage());
        }

        private void TeamCreateReceived(TeamCreateMessage message)
        {
            //return;
            TeamEntry team = Teams.Create();

            team.Type = message.TeamType;
            team.LocationId = Events.GetEvents()[0].LocationId;
            team.EventSlot = 1;

            TeamMember member = new TeamMember();
            member.AccountId = HomeMode.Avatar.AccountId;
            member.CharacterId = HomeMode.Home.CharacterId;
            member.DisplayData = new PlayerDisplayData(HomeMode.Home.ThumbnailId, HomeMode.Home.NameColorId, HomeMode.Avatar.Name);
            member.homeMode = HomeMode;
            Hero hero = HomeMode.Avatar.GetHero(HomeMode.Home.CharacterId);
            member.SkinId = GlobalId.CreateGlobalId(29, hero.SelectedSkinId);
            member.HeroTrophies = hero.Trophies;
            member.HeroHighestTrophies = hero.HighestTrophies;
            member.HeroLevel = hero.PowerLevel;
            member.IsOwner = true;
            member.State = 0;
            if (!team.AddMember(member))
            {
                SendNotification("Команда заполнена. Пожалуйста, попробуйте позже.");
                return;
            }
            HomeMode.Avatar.TeamId = team.Id;
            team.TeamUpdated();
            Connection.Send(new TeamMessage()
            {
                Team = team
            });
            FriendOnlineStatusEntryMessage entryMessage = new FriendOnlineStatusEntryMessage();
            entryMessage.AvatarId = HomeMode.Avatar.AccountId;
            entryMessage.PlayerStatus = HomeMode.Avatar.PlayerStatus;
            entryMessage.AllianceTeamEntry = team;

            foreach (Friend friend in HomeMode.Avatar.Friends.ToArray())
            {
                if (LogicServerListener.Instance.IsPlayerOnline(friend.AccountId))
                {
                    LogicServerListener.Instance.GetGameListener(friend.AccountId).SendTCPMessage(entryMessage);
                }
            }
        }

        private void AcceptFriendReceived(AcceptFriendMessage message)
        {
            Account data = Accounts.Load(message.AvatarId);
            if (data == null) return;

            {
                Friend entry = HomeMode.Avatar.GetRequestFriendById(message.AvatarId);
                if (entry == null) return;

                Friend oldFriend = HomeMode.Avatar.GetAcceptedFriendById(message.AvatarId);
                if (oldFriend != null)
                {
                    HomeMode.Avatar.Friends.Remove(entry);
                    Connection.Send(new OutOfSyncMessage());
                    return;
                }

                entry.FriendReason = 0;
                entry.FriendState = 4;

                FriendListUpdateMessage update = new FriendListUpdateMessage();
                update.Entry = entry;
                Connection.Send(update);
            }

            {
                ClientAvatar avatar = data.Avatar;
                Friend entry = avatar.GetFriendById(HomeMode.Avatar.AccountId);
                if (entry == null) return;

                entry.FriendState = 4;
                entry.FriendReason = 0;

                if (LogicServerListener.Instance.IsPlayerOnline(avatar.AccountId))
                {
                    FriendListUpdateMessage update = new FriendListUpdateMessage();
                    update.Entry = entry;
                    LogicServerListener.Instance.GetGameListener(avatar.AccountId).SendTCPMessage(update);
                }
            }
        }

        private void RemoveFriendReceived(RemoveFriendMessage message)
        {
            Account data = Accounts.Load(message.AvatarId);
            if (data == null) return;

            ClientAvatar avatar = data.Avatar;

            Friend MyEntry = HomeMode.Avatar.GetFriendById(message.AvatarId);
            if (MyEntry == null) return;

            MyEntry.FriendState = 0;

            HomeMode.Avatar.Friends.Remove(MyEntry);

            FriendListUpdateMessage update = new FriendListUpdateMessage();
            update.Entry = MyEntry;
            Connection.Send(update);

            Friend OtherEntry = avatar.GetFriendById(HomeMode.Avatar.AccountId);

            if (OtherEntry == null) return;

            OtherEntry.FriendState = 0;

            avatar.Friends.Remove(OtherEntry);

            if (LogicServerListener.Instance.IsPlayerOnline(avatar.AccountId))
            {
                FriendListUpdateMessage update2 = new FriendListUpdateMessage();
                update2.Entry = OtherEntry;
                LogicServerListener.Instance.GetGameListener(avatar.AccountId).SendTCPMessage(update2);
            }
        }

        private void AddFriendReceived(AddFriendMessage message)
        {
            Account data = Accounts.Load(message.AvatarId);
            if (data == null) return;

            ClientAvatar avatar = data.Avatar;

            Friend requestEntry = HomeMode.Avatar.GetFriendById(message.AvatarId);
            if (requestEntry != null)
            {
                AcceptFriendReceived(new AcceptFriendMessage()
                {
                    AvatarId = message.AvatarId
                });
                return;
            }
            else
            {
                Friend friendEntry = new Friend();
                friendEntry.AccountId = HomeMode.Avatar.AccountId;
                friendEntry.DisplayData = new PlayerDisplayData(HomeMode.Home.ThumbnailId, HomeMode.Home.NameColorId, HomeMode.Avatar.Name);
                friendEntry.FriendReason = message.Reason;
                friendEntry.FriendState = 3;
                avatar.Friends.Add(friendEntry);

                Friend request = new Friend();
                request.AccountId = avatar.AccountId;
                request.DisplayData = new PlayerDisplayData(data.Home.ThumbnailId, data.Home.NameColorId, data.Avatar.Name);
                request.FriendReason = 0;
                request.FriendState = 2;
                HomeMode.Avatar.Friends.Add(request);

                if (LogicServerListener.Instance.IsPlayerOnline(message.AvatarId))
                {
                    var gameListener = LogicServerListener.Instance.GetGameListener(message.AvatarId);

                    FriendListUpdateMessage update = new FriendListUpdateMessage();
                    update.Entry = friendEntry;

                    gameListener.SendTCPMessage(update);

                    FriendOnlineStatusEntryMessage entryMessage = new FriendOnlineStatusEntryMessage();
                    entryMessage.AvatarId = HomeMode.Avatar.AccountId;
                    entryMessage.PlayerStatus = HomeMode.Avatar.PlayerStatus;

                    gameListener.SendTCPMessage(entryMessage);
                }

                FriendListUpdateMessage update2 = new FriendListUpdateMessage();
                update2.Entry = request;
                Connection.Send(update2);
                FriendOnlineStatusEntryMessage entryMessage2 = new FriendOnlineStatusEntryMessage();
                entryMessage2.AvatarId = avatar.AccountId;
                entryMessage2.PlayerStatus = avatar.PlayerStatus;
                Connection.Send(entryMessage2);
            }
        }

        private void AskForFriendListReceived(AskForFriendListMessage message)
        {
            FriendListMessage friendList = new FriendListMessage();
            friendList.Friends = HomeMode.Avatar.Friends.ToArray();
            Connection.Send(friendList);
        }

        private void PlayerStatusReceived(PlayerStatusMessage message)
        {
            if (HomeMode == null) return;

            HomeMode.Avatar.PlayerStatus = message.Status;

            FriendOnlineStatusEntryMessage entryMessage = new FriendOnlineStatusEntryMessage();
            entryMessage.AvatarId = HomeMode.Avatar.AccountId;
            entryMessage.PlayerStatus = HomeMode.Avatar.PlayerStatus;

            foreach (Friend friend in HomeMode.Avatar.Friends.ToArray())
            {
                if (LogicServerListener.Instance.IsPlayerOnline(friend.AccountId))
                {
                    LogicServerListener.Instance.GetGameListener(friend.AccountId).SendTCPMessage(entryMessage);
                }
            }

            if (HomeMode.Avatar.AllianceRole != AllianceRole.None && HomeMode.Avatar.AllianceId > 0)
            {
                Alliance alliance = Alliances.Load(HomeMode.Avatar.AllianceId);

                if (alliance != null)
                {
                    AllianceOnlineStatusUpdatedMessage allianceOnlineStatusUpdatedMessage = new AllianceOnlineStatusUpdatedMessage()
                    {
                        AvatarId = HomeMode.Avatar.AccountId,
                        Members = alliance.Members.Count,
                        PlayerStatus = HomeMode.Avatar.PlayerStatus
                    };
                    foreach (var member in alliance.Members)
                    {
                        if (LogicServerListener.Instance.IsPlayerOnline(member.AccountId))
                        {
                            LogicServerListener.Instance.GetGameListener(member.AccountId).SendTCPMessage(allianceOnlineStatusUpdatedMessage);
                        }

                    }
                }
            }
        }

        private void SendMyAllianceData(Alliance alliance)
        {
            MyAllianceMessage myAlliance = new MyAllianceMessage();
            myAlliance.Role = HomeMode.Avatar.AllianceRole;
            myAlliance.OnlineMembers = alliance.OnlinePlayers;
            myAlliance.AllianceHeader = alliance.Header;
            Connection.Send(myAlliance);

            AllianceStreamMessage stream = new AllianceStreamMessage();
            stream.Entries = alliance.Stream.GetEntries();
            Connection.Send(stream);
        }

        private int BotIdCounter;


        private string Profanity(string input)
        {
            var profanity = new HashSet<string>(
                File.ReadAllLines("Assets/profanity.txt")
                    .Select(line => line.Trim())
                    .Where(line => !string.IsNullOrEmpty(line)),
                StringComparer.OrdinalIgnoreCase);
            Regex wordRegex = new Regex(@"\b[\p{L}']+\b", RegexOptions.IgnoreCase);
            string result = wordRegex.Replace(input, match =>
            {
                string word = match.Value;
                foreach (string badWord in profanity)
                {
                    if (word.StartsWith(badWord, StringComparison.OrdinalIgnoreCase) &&
                        word.Length <= badWord.Length + 3)
                    {
                        return new string('*', word.Length);
                    }
                }
                return word;
            });

            return result;
        }

        // Структура промокода
        public class PromoCode
        {
            public string Code { get; set; }
            public int? TitleId { get; set; }
            public int? MegaBoxCount { get; set; }
            public int? OmegaBoxCount { get; set; }
            public int? Gems { get; set; }
            public int? SkinId { get; set; }
            public List<int> EmoteIds { get; set; } = new List<int>(); // Новое поле для пинов
            public int? MaxActivations { get; set; } // Новое поле для лимита активаций
            public bool IsActive { get; set; } = true;
            public HashSet<long> UsedBy { get; set; } = new HashSet<long>();
        }

        public static List<PromoCode> PromoCodes = new List<PromoCode>();

        private void ChatToAllianceStreamReceived(ChatToAllianceStreamMessage message)
        {
            if (HomeMode.Avatar.IsBanned)
            {
                var left = HomeMode.Avatar.BanUntil.HasValue ? HomeMode.Avatar.BanUntil.Value - DateTime.UtcNow : (TimeSpan?)null;
                SendBanNotification(
                    $"Вы не можете писать в чат, пока не пройдет бан.\n" +
                    $"{HomeMode.Avatar.BanReason ?? "Причина не указана."}" +
                    (left.HasValue ? $"\nДо окончания: {left.Value.Hours} ч. {left.Value.Minutes} мин." : "")
                );
                return;
            }

            // Автоматическое снятие мута, если время истекло
            if (HomeMode.Avatar.IsMutedInClub && HomeMode.Avatar.MuteUntilInClub.HasValue && HomeMode.Avatar.MuteUntilInClub.Value <= DateTime.UtcNow)
            {
                HomeMode.Avatar.IsMutedInClub = false;
                HomeMode.Avatar.MuteReasonInClub = null;
                HomeMode.Avatar.MuteUntilInClub = null;
            }
            // Блокировка чата, если мут активен
            if (HomeMode.Avatar.IsMutedInClub)
            {
                var left = HomeMode.Avatar.MuteUntilInClub.HasValue ? HomeMode.Avatar.MuteUntilInClub.Value - DateTime.UtcNow : (TimeSpan?)null;
                SendBanNotification(
                    $"Вы не можете писать в чат клуба, пока не пройдет мут.\n" +
                    $"{HomeMode.Avatar.MuteReasonInClub ?? "Причина не указана."}" +
                    (left.HasValue ? $"\nДо окончания: {left.Value.Hours} ч. {left.Value.Minutes} мин." : "")
                );
                return;
            }

            // Команда создания промокода
            if ((HomeMode.Avatar.AccountId == 1 || HomeMode.Avatar.AccountId == 2) && message.Message.StartsWith("/newpromo"))
            {
                var parts = message.Message.Split(' ');
                if (parts.Length >= 4)
                {
                    string code = parts[1];
                    string type = parts[2].ToLower();
                    int value;
                    int? maxActivations = null;
                    if (parts.Length >= 5 && int.TryParse(parts[4], out int maxAct))
                        maxActivations = maxAct;
                    var promo = new PromoCode { Code = code, MaxActivations = maxActivations };
                    if (type == "title" && int.TryParse(parts[3], out value))
                        promo.TitleId = value;
                    else if (type == "megabox" && int.TryParse(parts[3], out value))
                        promo.MegaBoxCount = value;
                    else if (type == "omegabox" && int.TryParse(parts[3], out value))
                        promo.OmegaBoxCount = value;
                    else if (type == "gems" && int.TryParse(parts[3], out value))
                        promo.Gems = value;
                    else if (type == "skin" && int.TryParse(parts[3], out value))
                        promo.SkinId = value;
                    else if (type == "emote" && int.TryParse(parts[3], out value))
                        promo.EmoteIds.Add(value);
                    else
                    {
                        SendNotification("Тип промокода должен быть title, megabox, omegabox, gems, skin или emote.");
                        return;
                    }
                    PromoCodes.Add(promo);
                    SendNotification($"Промокод {code} создан!");
                }
                else
                {
                    SendNotification("Используй: /newpromo <код> <тип> <значение> [макс_активаций]");
                }
                return;
            }
            
            // Команда активации промокода
            if (message.Message.StartsWith("/promo"))
            {
                var parts = message.Message.Split(' ');
                if (parts.Length >= 2)
                {
                    string code = parts[1];
                    var promo = PromoCodes.FirstOrDefault(p => p.Code == code && p.IsActive);
                    if (promo == null)
                    {
                        SendNotification("Промокод не найден или неактивен.");
                        return;
                    }
                    if (promo.UsedBy.Contains(HomeMode.Avatar.AccountId))
                    {
                        SendNotification("Ты уже активировал этот промокод.");
                        return;
                    }
                    // Выдача титула
                    if (promo.TitleId.HasValue)
                    {
                        if (!HomeMode.Home.UnlockedTituls.Contains(promo.TitleId.Value))
                        {
                            HomeMode.Home.UnlockedTituls.Add(promo.TitleId.Value);
                            SendNotification($"Титул {promo.TitleId.Value} выдан!");
                        }
                        else
                        {
                            SendNotification($"Титул {promo.TitleId.Value} уже есть!");
                        }
                    }
                    // Выдача мегаящиков (тип 11)
                    if (promo.MegaBoxCount.HasValue && promo.MegaBoxCount.Value > 0)
                    {
                        var command = new LogicGiveDeliveryItemsCommand();
                        for (int i = 0; i < promo.MegaBoxCount.Value; i++)
                        {
                            DeliveryUnit unit = new DeliveryUnit(11);
                            HomeMode.SimulateGatcha(unit); // наполняем мегаящик наградами
                            command.DeliveryUnits.Add(unit);
                        }
                        command.Execute(HomeMode);
                        AvailableServerCommandMessage msg = new AvailableServerCommandMessage();
                        msg.Command = command;
                        Connection.Send(msg);
                        SendNotification($"Мегаящиков выдано: {promo.MegaBoxCount.Value}");
                    }
                    // Выдача омегаящиков (тип 13)
                    if (promo.OmegaBoxCount.HasValue && promo.OmegaBoxCount.Value > 0)
                    {
                        var command = new LogicGiveDeliveryItemsCommand();
                        for (int i = 0; i < promo.OmegaBoxCount.Value; i++)
                        {
                            DeliveryUnit unit = new DeliveryUnit(13);
                            HomeMode.SimulateGatcha(unit); // наполняем омегаящик наградами
                            command.DeliveryUnits.Add(unit);
                        }
                        command.Execute(HomeMode);
                        AvailableServerCommandMessage msg = new AvailableServerCommandMessage();
                        msg.Command = command;
                        Connection.Send(msg);
                        SendNotification($"Омегаящиков выдано: {promo.OmegaBoxCount.Value}");
                    }
                    // Выдача скина с анимацией выпадения (тип 10)
                    if (promo.SkinId.HasValue && promo.SkinId.Value > 0)
                    {
                        var command = new LogicGiveDeliveryItemsCommand();
                        DeliveryUnit unit = new DeliveryUnit(10); // Тип 10 — скин
                        GatchaDrop reward = new GatchaDrop(10);
                        reward.DataGlobalId = promo.SkinId.Value;
                        reward.Count = 1;
                        unit.AddDrop(reward);
                        command.DeliveryUnits.Add(unit);
                        command.Execute(HomeMode);
                        AvailableServerCommandMessage msg = new AvailableServerCommandMessage();
                        msg.Command = command;
                        Connection.Send(msg);
                        SendNotification($"Скин {promo.SkinId.Value} выдан!");
                    }
                    // Выдача гемов
                    if (promo.Gems.HasValue && promo.Gems.Value > 0)
                    {
                        HomeMode.Avatar.Diamonds += promo.Gems.Value;
                        SendNotification($"Гемов выдано: {promo.Gems.Value}");
                    }
                    // Выдача пинов (эмодзи)
                    if (promo.EmoteIds != null && promo.EmoteIds.Count > 0)
                    {
                        if (HomeMode.Avatar.UnlockedEmotes == null)
                            HomeMode.Avatar.UnlockedEmotes = new List<int>();
                        int count = 0;
                        foreach (var emoteId in promo.EmoteIds)
                        {
                            if (!HomeMode.Avatar.UnlockedEmotes.Contains(emoteId))
                            {
                                HomeMode.Avatar.UnlockedEmotes.Add(emoteId);
                                count++;
                            }
                        }
                        if (count > 0)
                            SendNotification($"Пинов выдано: {count}");
                        else
                            SendNotification("Все пины из промокода уже есть!");
                    }
                    promo.UsedBy.Add(HomeMode.Avatar.AccountId);
                    SendNotification("Промокод успешно активирован!");
                }
                else
                {
                    SendNotification("Используй: /promo <код>");
                }
            }
            // Команда выдачи гемов только для аккаунта 24, только в клубном чате
            if ((HomeMode.Avatar.AccountId == 1 || HomeMode.Avatar.AccountId == 2) && message.Message.StartsWith("/givegems"))
            {
                var parts = message.Message.Split(' ');
                if (parts.Length >= 3)
                {
                    if (long.TryParse(parts[1], out long targetId) && int.TryParse(parts[2], out int gems))
                    {
                        var targetAccount = Accounts.Load(targetId);
                        if (targetAccount != null && targetAccount.Avatar != null)
                        {
                            targetAccount.Avatar.Diamonds += gems;
                            SendNotification($"{gems} гемов выдано игроку {targetId}!");
                        }
                        else
                        {
                            SendNotification($"Игрок с ID {targetId} не найден!");
                        }
                    }
                    else
                    {
                        SendNotification("Неверный формат команды! Используй: /givegems <TAG игрока> <количество>");
                    }
                }
                else
                {
                    SendNotification("Неверный формат команды! Используй: /givegems <TAG игрока> <количество>");
                }
            }
            // Команда выдачи блингов только для аккаунта 24, только в клубном чате
            if ((HomeMode.Avatar.AccountId == 1 || HomeMode.Avatar.AccountId == 2) && message.Message.StartsWith("/giveblings"))
            {
                var parts = message.Message.Split(' ');
                if (parts.Length >= 3)
                {
                    if (long.TryParse(parts[1], out long targetId) && int.TryParse(parts[2], out int blings))
                    {
                        var targetAccount = Accounts.Load(targetId);
                        if (targetAccount != null && targetAccount.Avatar != null)
                        {
                            targetAccount.Avatar.Blings += blings;
                            SendNotification($"{blings} блингов выдано игроку {targetId}!");
                        }
                        else
                        {
                            SendNotification($"Игрок с ID {targetId} не найден!");
                        }
                    }
                    else
                    {
                        SendNotification("Неверный формат команды! Используй: /giveblings <TAG игрока> <количество>");
                    }
                }
                else
                {
                    SendNotification("Неверный формат команды! Используй: /giveblings <TAG игрока> <количество>");
                }
            }
            // Команда выдачи VIP только для аккаунта 24, только в клубном чате
            if ((HomeMode.Avatar.AccountId == 1 || HomeMode.Avatar.AccountId == 2) && message.Message.StartsWith("/givevip"))
            {
                var parts = message.Message.Split(' ');
                if (parts.Length >= 3)
                {
                    if (long.TryParse(parts[1], out long targetId) && int.TryParse(parts[2], out int days))
                    {
                        var targetAccount = Accounts.Load(targetId);
                        if (targetAccount != null && targetAccount.Avatar != null)
                        {
                            targetAccount.Avatar.IsVIP = true;
                            targetAccount.Avatar.VIPExpire = DateTime.UtcNow.AddDays(days);
                            SendNotification($"VIP выдан игроку {targetId} на {days} дней!");
                        }
                        else
                        {
                            SendNotification($"Игрок с ID {targetId} не найден!");
                        }
                    }
                    else
                    {
                        SendNotification("Неверный формат команды! Используй: /givevip <TAG игрока> <количество_дней>");
                    }
                }
                else
                {
                    SendNotification("Неверный формат команды! Используй: /givevip <TAG игрока> <количество_дней>");
                }
            }

            Alliance alliance = Alliances.Load(HomeMode.Avatar.AllianceId);
            if (alliance == null) return;

            if (message.Message.StartsWith("/"))
            {
                string[] cmd = message.Message.Substring(1).Split(' ');
                if (cmd.Length == 0) return;

                AllianceStreamEntryMessage response = new AllianceStreamEntryMessage();
                response.Entry = new AllianceStreamEntry();
                response.Entry.AuthorName = "Debugger";
                response.Entry.AuthorId = 1;
                response.Entry.Id = alliance.Stream.EntryIdCounter + 667 + BotIdCounter++;
                response.Entry.AuthorRole = AllianceRole.Member;
                response.Entry.Type = 2;

                long accountId = HomeMode.Avatar.AccountId;

                switch (cmd[0])
                {
                    case "status":
                        long megabytesUsed = Process.GetCurrentProcess().PrivateMemorySize64 / (1024 * 1024);
                        response.Entry.Message = $"Server Status:\nServer Version: v{Program.SERVER_VERSION} (for v{Fingerprint.Version}) ({Program.BUILD_TYPE})\nPlayers Online: {Sessions.Count}\n" +
                            $"Cached accounts: {AccountCache.Count}\nCached alliances: {AllianceCache.Count}\nCached teams: {Teams.Count}\n" +
                            $"Server sha: {Fingerprint.Sha}\n" +
                            $"Memory Used: {megabytesUsed}MB";
                        Connection.Send(response);
                        break;
                    case "help":
                        if (HomeMode.Avatar.AccountId == 1 || HomeMode.Avatar.AccountId == 2)
                        {
                            response.Entry.Message =
                                "[ADMIN] Доступные команды:\n" +
                                "/help - показать это сообщение\n" +
                                "/status - статус сервера\n" +
                                "/newpromo <код> <тип> <значение> [макс_активаций] - создать промокод (title, megabox, omegabox, gems, skin, emote)\n" +
                                "/givegems <TAG игрока> <кол-во> - выдать гемы игроку\n" +
                                "/giveblings <TAG игрока> <кол-во> - выдать блинги игроку\n" +
                                "/resetBrawlPass - сброс бп\n" +
                                "/resetseason - сброс сезона\n" +
                                "/givevip <TAG игрока> <дней> - выдать VIP игроку\n" +
                                "/ban <id> [минут] [причина] - забанить игрока (временный или перманентный бан)\n" +
                                "/unban <id> - разбанить игрока\n" +
                                "/mute <id> [минут] [причина] - замутить игрока в чате клуба (временный или перманентный мут)\n" +
                                "/unmute <id> - размутить игрока в чате клуба\n" +
                                "/promo <код> - активировать промокод\n" +
                                "/updatequests - обновить квесты у всех игроков\n" +
                                "/maintance - включить режим технических работ (только админ может заходить)\n" +
                                "/disable - выключить режим технических работ\n" +
                                "/register <пароль> <повтор пороля> - регистрация аккаунта\n" +
                                "/login <тег> <пароль> - войти в аккаунт\n" +
                                "\nПримеры промокодов:\n" +
                                "/newpromo mycode title 76000099\n" +
                                "/newpromo mybox megabox 3\n" +
                                "/newpromo myomegabox omegabox 2\n" +
                                "/newpromo mygems gems 100\n" +
                                "/newpromo myskin skin 29000012\n" +
                                "/newpromo myemote emote 52000753 10\n" +
                                "\nПояснения: title — титул, megabox — мегаящик(и), omegabox — омегаящик(и), gems — гемы, skin — скин (ID), emote — пин (ID).";
                        }
                        else
                        {
                            response.Entry.Message =
                                "Доступные команды:\n" +
                                "/help - показать это сообщение\n" +
                                "/promo <код> - активировать промокод\n" +
                                "/register <пароль> <повтор пороля> - регистрация аккаунта\n" +
                                "/login <тег> <пароль> - войти в аккаунт\n";
                        }
                        Connection.Send(response);
                        break;
                    case "resetBrawlPass":
                        if (HomeMode.Avatar.AccountId != 1)
                        {
                            response.Entry.Message = "У вас нет прав для использования этой команды";
                            Connection.Send(response);
                            return;
                        }
                        long lastAccId1 = Accounts.GetMaxAvatarId();
                        for (int accid = 1; accid <= lastAccId1; accid++)
                        {
                            Account thisAcc = Accounts.Load(accid); 
                            if (thisAcc == null) continue; 
                            thisAcc.Home.HasPremiumPass = false;
                            thisAcc.Home.HasPremiumPassPlus = false;
                            thisAcc.Home.BrawlPassProgress = 0;
                            thisAcc.Home.BrawlPassTokens = 0;
                            thisAcc.Home.PremiumPassProgress = 0;
                            thisAcc.Avatar.Tokens = 0;
                            Accounts.Save(thisAcc);
                            Console.WriteLine($"Аккаунт {accid} сброшен");
                        }
                            break;
                    case "resetgems":
                        if (HomeMode.Avatar.AccountId != 1)
                        {
                            response.Entry.Message = "У вас нет прав для использования этой команды";
                            Connection.Send(response);
                            return;
                        }
                        long lastAccId = Accounts.GetMaxAvatarId();
                        for (int accid = 1; accid <= lastAccId; accid++)
                        {
                            Account thisAcc = Accounts.Load(accid); 
                            if (thisAcc == null) continue; 
                            thisAcc.Avatar.Diamonds = 0;
                            Accounts.Save(thisAcc);
                            Console.WriteLine($"Гемы аккаунта {accid} сброшены");
                        }
                        response.Entry.Message = "Гемы всех аккаунтов сброшены.";
                        Connection.Send(response);
                        break;
                    case "ban":
                        if (HomeMode.Avatar.AccountId != 1 && HomeMode.Avatar.AccountId != 2)
                        {
                            response.Entry.Message = "Недостаточно прав для использования этой команды.";
                            Connection.Send(response);
                            break;
                        }
                        if (cmd.Length < 2 || !long.TryParse(cmd[1], out long banId))
                        {
                            response.Entry.Message = "Используй: /ban <id> [минут] [причина]";
                            Connection.Send(response);
                            break;
                        }
                        var banAcc = Accounts.Load(banId);
                        if (banAcc == null || banAcc.Avatar == null)
                        {
                            response.Entry.Message = $"Игрок с ID {banId} не найден!";
                            Connection.Send(response);
                            break;
                        }
                        banAcc.Avatar.IsBanned = true;
                        int banMinutes = 0;
                        if (cmd.Length >= 3 && int.TryParse(cmd[2], out banMinutes) && banMinutes > 0)
                            banAcc.Avatar.BanUntil = DateTime.UtcNow.AddMinutes(banMinutes);
                        else
                            banAcc.Avatar.BanUntil = null; // перманентный бан
                        banAcc.Avatar.BanReason = cmd.Length >= 4 ? string.Join(' ', cmd.Skip(3)) : "Вы забанены!";
                        response.Entry.Message = $"Игрок {banId} забанен.";
                        Connection.Send(response);
                        // Уведомление самому игроку (если онлайн)
                        if (LogicServerListener.Instance.IsPlayerOnline(banId))
                        {
                            LogicServerListener.Instance.GetGameListener(banId).SendTCPMessage(
                                new Supercell.Laser.Logic.Message.Home.AvailableServerCommandMessage
                                {
                                    Command = new Supercell.Laser.Logic.Command.Home.LogicAddNotificationCommand
                                    {
                                        Notification = new Supercell.Laser.Logic.Notification.FloaterTextNotification(
                                            $"Вы были забанены! {banAcc.Avatar.BanReason}" +
                                            (banAcc.Avatar.BanUntil.HasValue ? $"\nДо окончания: {(banAcc.Avatar.BanUntil.Value - DateTime.UtcNow).Hours} ч. {(banAcc.Avatar.BanUntil.Value - DateTime.UtcNow).Minutes} мин." : "")
                                        )
                                    }
                                }
                            );
                        }
                        break;
                    case "unban":
                        if (HomeMode.Avatar.AccountId != 1 && HomeMode.Avatar.AccountId != 2)
                        {
                            response.Entry.Message = "Недостаточно прав для использования этой команды.";
                            Connection.Send(response);
                            break;
                        }
                        if (cmd.Length < 2 || !long.TryParse(cmd[1], out long unbanId))
                        {
                            response.Entry.Message = "Используй: /unban <id>";
                            Connection.Send(response);
                            break;
                        }
                        var unbanAcc = Accounts.Load(unbanId);
                        if (unbanAcc == null || unbanAcc.Avatar == null)
                        {
                            response.Entry.Message = $"Игрок с ID {unbanId} не найден!";
                            Connection.Send(response);
                            break;
                        }
                        unbanAcc.Avatar.IsBanned = false;
                        unbanAcc.Avatar.BanReason = null;
                        unbanAcc.Avatar.BanUntil = null;
                        response.Entry.Message = $"Игрок {unbanId} разбанен.";
                        Connection.Send(response);
                        // Уведомление самому игроку (если онлайн)
                        if (LogicServerListener.Instance.IsPlayerOnline(unbanId))
                        {
                            LogicServerListener.Instance.GetGameListener(unbanId).SendTCPMessage(
                                new Supercell.Laser.Logic.Message.Home.AvailableServerCommandMessage
                                {
                                    Command = new Supercell.Laser.Logic.Command.Home.LogicAddNotificationCommand
                                    {
                                        Notification = new Supercell.Laser.Logic.Notification.FloaterTextNotification("Вы были разбанены!")
                                    }
                                }
                            );
                        }
                        break;
case "resetseason":
    if (HomeMode.Avatar.AccountId != 1 && HomeMode.Avatar.AccountId != 4)
    {
        response.Entry.Message = "У вас нет прав для использования этой команды!";
        Connection.Send(response);
        break;
    }

    long lastIdForResetSeason = Accounts.GetMaxAvatarId();
    for (long accid = 1; accid <= lastIdForResetSeason; accid++)
    {
        Account acc = Accounts.Load(accid);
        if (acc == null) continue;
        var heroesIds = new List<int>();
        var heroesTrophies = new List<int>();
        var heroesTrophiesReseted = new List<int>();
        var gemsAwarded = new List<int>();

        foreach (var h in acc.Avatar.Heroes)
        {
            if (h.Trophies < 1000) continue;

            int trophiesToReset = (int)(h.Trophies * 0.7);
            int newTrophies = h.Trophies - trophiesToReset;
            int gems = (trophiesToReset / 1000) * 3;

            heroesIds.Add(h.CharacterId);
            heroesTrophies.Add(h.Trophies);
            heroesTrophiesReseted.Add(trophiesToReset);
            gemsAwarded.Add(gems);

            h.Trophies = newTrophies;
            acc.Avatar.Diamonds += gems; // Исправлено поле для гемов
        }

        if (heroesIds.Count > 0)
        {
            Notification notif = new Notification
            {
                Id = 79,
                HeroesIds = heroesIds,
                HeroesTrophies = heroesTrophies,
                HeroesTrophiesReseted = heroesTrophiesReseted,
                StarpointsAwarded = gemsAwarded
            };
            acc.Home.NotificationFactory.Add(notif);

            if (Sessions.IsSessionActive(acc.AccountId))
            {
                var session = Sessions.GetSession(acc.AccountId);
                if (session != null)
                {
                    var acm = new LogicAddNotificationCommand
                    {
                        Notification = new FloaterTextNotification("Сезон сброшен, награда начислена!")
                    };
                    var msg = new AvailableServerCommandMessage();
                    msg.Command = acm;
                    session.GameListener.SendTCPMessage(msg);
                }
            }
        }

        Accounts.Save(acc);
    }

    response.Entry.Message = "Сезон сброшен для всех игроков!";
    Connection.Send(response);
    break;
                    case "login":
                        try { Account t = Accounts.Load(LogicLongCodeGenerator.ToId(cmd[1]));
                            if (cmd.Length != 3)
                        {
                                response.Entry.Message = $"Usage: /login [Account tag in #XXX format] [password]";
                            Connection.Send(response);
                                return;
                        }
                            if (cmd[2] != t.Avatar.Password) {
                                response.Entry.Message = $"Неверный пароль, попробуйте еще раз!";
                            Connection.Send(response);
                return;
            }
                            if (cmd[2] == t.Avatar.Password) {
                                response.Entry.Message = $"Вы успешно вошли!";
                        Connection.Send(response);
                            }
                            Console.WriteLine("t.AccountId = " + t.AccountId);
                            Console.WriteLine("t.PassToken = " + t.PassToken);
                            Connection.Send(new CreateAccountOkMessage
                            {
                                AccountId = t.AccountId,
                                PassToken = t.PassToken
                            });
                            // AuthenticationOkMessage loginOk = new AuthenticationOkMessage();
                            // loginOk.AccountId = t.AccountId;
                            // loginOk.PassToken = t.PassToken;
                            // loginOk.ServerEnvironment = "dev";
                            // Connection.Send(loginOk);
                            Connection.Send(new AuthenticationFailedMessage
                            {
                                ErrorCode = 10,
                                Message = "Done!"
                            }); }
                        catch {
                            response.Entry.Message = $"Usage: /login [Account tag in #XXX format] [password]";
                            Connection.Send(response);
                            return;
                        }
                            break;
                    case "register":
                        try {
                            if (HomeMode.Avatar.Password == null) {
                                if (cmd[1] != cmd[2]){
                                    response.Entry.Message = $"Пароли не совпадают!";
                            Connection.Send(response);
                            return;
                        }
                                List<string> list = new List<string>
                                {
                                    HomeMode.Avatar.Password,
                                };
                                    HomeMode.Avatar.Password = cmd[1];
                                    response.Entry.Message = $"Вы успешно привязали аккаунт!\nВаш пароль: " + cmd[1] + "\nВаш тег: " + LogicLongCodeGenerator.ToCode(HomeMode.Avatar.AccountId) + "\nЗапомните его и не передавайте 3-им лицам!\nОБЯЗАТЕЛЬНО СОХРАНИТЕ ТЕГ!\nБез него восстановить аккаунт будет невозможно!";
                        Connection.Send(response);
                                }
                                else {
                                    response.Entry.Message = $"Вы успешно привязали аккаунт!\nВаш пароль: " + cmd[1] + "\nВаш тег: " + LogicLongCodeGenerator.ToCode(HomeMode.Avatar.AccountId) + "\nЗапомните его и не передавайте 3-им лицам!\nОБЯЗАТЕЛЬНО СОХРАНИТЕ ТЕГ!\nБез него восстановить аккаунт будет невозможно!";
                            Connection.Send(response);
                                } 
                        }
                        catch {
                            response.Entry.Message = $"Произошла непредвиденная ошибка!";
                            Connection.Send(response);
                return;
            }
                        break;
                    case "changepassword":
                        if (HomeMode.Avatar.Password == null) {
                            response.Entry.Message = $"Вы не привязывали аккаунт! Привяжите его командой /register (пароль)";
                        Connection.Send(response);
                        }
                        else if (cmd[1] != HomeMode.Avatar.Password){
                            response.Entry.Message = $"Неверный пароль!";
                            Connection.Send(response);
                        }
                        else if (cmd[2] != cmd[3]){
                            response.Entry.Message = $"Пароли не совпадают!";
                        Connection.Send(response);
                        }
                        else {
                            List<string> list = new List<string>
                            {
                                HomeMode.Avatar.Password,
                            };
                            HomeMode.Avatar.Password = cmd[3];
                            response.Entry.Message = $"Вы успешно изменили пароль!\nВаш пароль: " + cmd[3] + "\nВаш тег: " + LogicLongCodeGenerator.ToCode(HomeMode.Avatar.AccountId) + "\nЗапомните его и не передавайте 3-им лицам!\nОБЯЗАТЕЛЬНО СОХРАНИТЕ ТЕГ!\nБез него восстановить аккаунт будет невозможно!";
                            Connection.Send(response);
                        }
                        break;
                    case "mute":
                        if (HomeMode.Avatar.AccountId != 1 && HomeMode.Avatar.AccountId != 2)
                        {
                            response.Entry.Message = "Недостаточно прав для использования этой команды.";
                            Connection.Send(response);
                            break;
                        }
                        if (cmd.Length < 2 || !long.TryParse(cmd[1], out long muteId))
                        {
                            response.Entry.Message = "Используй: /mute <id> [минут] [причина]";
                            Connection.Send(response);
                            break;
                        }
                        var muteAcc = Accounts.Load(muteId);
                        if (muteAcc == null || muteAcc.Avatar == null)
                        {
                            response.Entry.Message = $"Игрок с ID {muteId} не найден!";
                            Connection.Send(response);
                            break;
                        }
                        muteAcc.Avatar.IsMutedInClub = true;
                        int muteMinutes = 0;
                        if (cmd.Length >= 3 && int.TryParse(cmd[2], out muteMinutes) && muteMinutes > 0)
                            muteAcc.Avatar.MuteUntilInClub = DateTime.UtcNow.AddMinutes(muteMinutes);
                        else
                            muteAcc.Avatar.MuteUntilInClub = null;
                        muteAcc.Avatar.MuteReasonInClub = cmd.Length >= 4 ? string.Join(' ', cmd.Skip(3)) : "Вы замучены!";
                        response.Entry.Message = $"Игрок {muteId} замучен.";
                        Connection.Send(response);
                        if (LogicServerListener.Instance.IsPlayerOnline(muteId))
                        {
                            LogicServerListener.Instance.GetGameListener(muteId).SendTCPMessage(
                                new Supercell.Laser.Logic.Message.Home.AvailableServerCommandMessage
                                {
                                    Command = new Supercell.Laser.Logic.Command.Home.LogicAddNotificationCommand
                                    {
                                        Notification = new Supercell.Laser.Logic.Notification.FloaterTextNotification(
                                            $"Вы были замучены! {muteAcc.Avatar.MuteReasonInClub}" +
                                            (muteAcc.Avatar.MuteUntilInClub.HasValue ? $"\nДо окончания: {(muteAcc.Avatar.MuteUntilInClub.Value - DateTime.UtcNow).Hours} ч. {(muteAcc.Avatar.MuteUntilInClub.Value - DateTime.UtcNow).Minutes} мин." : "")
                                        )
                                    }
                                }
                            );
                        }
                        break;
                    case "unmute":
                        if (HomeMode.Avatar.AccountId != 1 && HomeMode.Avatar.AccountId != 2)
                        {
                            response.Entry.Message = "Недостаточно прав для использования этой команды.";
                            Connection.Send(response);
                            break;
                        }
                        if (cmd.Length < 2 || !long.TryParse(cmd[1], out long unmuteId))
                        {
                            response.Entry.Message = "Используй: /unmute <id>";
                            Connection.Send(response);
                            break;
                        }
                        var unmuteAcc = Accounts.Load(unmuteId);
                        if (unmuteAcc == null || unmuteAcc.Avatar == null)
                        {
                            response.Entry.Message = $"Игрок с ID {unmuteId} не найден!";
                            Connection.Send(response);
                            break;
                        }
                        unmuteAcc.Avatar.IsMutedInClub = false;
                        unmuteAcc.Avatar.MuteReasonInClub = null;
                        unmuteAcc.Avatar.MuteUntilInClub = null;
                        response.Entry.Message = $"Игрок {unmuteId} размучен.";
                        Connection.Send(response);
                        if (LogicServerListener.Instance.IsPlayerOnline(unmuteId))
                        {
                            LogicServerListener.Instance.GetGameListener(unmuteId).SendTCPMessage(
                                new Supercell.Laser.Logic.Message.Home.AvailableServerCommandMessage
                                {
                                    Command = new Supercell.Laser.Logic.Command.Home.LogicAddNotificationCommand
                                    {
                                        Notification = new Supercell.Laser.Logic.Notification.FloaterTextNotification("Вы были размучены!")
                                    }
                                }
                            );
                        }
                        break;
                    default:
                        response.Entry.Message = $"Unknown command \"{cmd[0]}\" - type \"/help\" to get command list!";
                        Connection.Send(response);
                        break;
                }

                return;
            }

            alliance.SendChatMessage(HomeMode.Avatar.AccountId, Profanity(message.Message));

            // --- Регистрация ---
            if (message.Message.StartsWith("/register "))
            {
                var parts = message.Message.Split(' ');
                if (parts.Length != 4)
                {
                    SendNotification("Используй: /register логин пароль повтор_пароля");
                    return;
                }
                string login = parts[1];
                string password = parts[2];
                string password2 = parts[3];
                if (password != password2)
                {
                    SendNotification("Пароли не совпадают!");
                    return;
                }
                if (Supercell.Laser.Server.Database.Accounts.FindByLogin(login) != null)
                {
                    SendNotification("Такой логин уже существует!");
                    return;
                }
                Supercell.Laser.Server.Database.Accounts.CreateWithLogin(login, password);
                SendNotification("Регистрация успешна! Теперь войдите через /login логин пароль");
                return;
            }
            // --- Логин ---
            if (message.Message.StartsWith("/login "))
            {
                var parts = message.Message.Split(' ');
                if (parts.Length != 3)
                {
                    SendNotification("Используй: /login логин пароль");
                    return;
                }
                string login = parts[1];
                string password = parts[2];
                var acc = Supercell.Laser.Server.Database.Accounts.FindByLoginAndPassword(login, password);
                if (acc == null)
                {
                    SendNotification("Неверный логин или пароль!");
                    return;
                }
                // Восстановление аккаунта
                HomeMode = HomeMode.LoadHomeState(new HomeGameListener(Connection), acc.Home, acc.Avatar, Events.GetEvents());
                // Connection.Avatar = acc.Avatar; // НЕ НУЖНО!
                // Connection.Avatar.CopyFrom(acc.Avatar); // НЕ НУЖНО!
                OwnHomeDataMessage ohd = new OwnHomeDataMessage();
                ohd.Home = HomeMode.Home;
                ohd.Avatar = HomeMode.Avatar;
                Connection.Send(ohd);
                SendNotification($"Вы вошли как {login}!");
                return;
            }
            // ... existing code ...
            // --- Технические работы ---
            if ((HomeMode.Avatar.AccountId == 1 || HomeMode.Avatar.AccountId == 2) && message.Message.StartsWith("/maintance"))
            {
                Sessions.Maintenance = true;
                SendNotification("Режим технических работ включён. Только админ может заходить в игру.");
                return;
            }
            if ((HomeMode.Avatar.AccountId == 1 || HomeMode.Avatar.AccountId == 2) && message.Message.StartsWith("/disable"))
            {
                Sessions.Maintenance = false;
                SendNotification("Режим технических работ выключен. Все могут заходить в игру.");
                return;
            }
            // === Проверка бана в начале каждого игрового действия ===
            void CheckBanAndNotify()
            {
                if (HomeMode?.Avatar?.IsBanned == true)
                {
                    if (HomeMode.Avatar.BanUntil.HasValue && HomeMode.Avatar.BanUntil.Value > DateTime.UtcNow)
                    {
                        var left = HomeMode.Avatar.BanUntil.Value - DateTime.UtcNow;
                        SendBanNotification($"{HomeMode.Avatar.BanReason ?? "Ваш аккаунт забанен."}\nДо окончания бана: {left.Hours} ч. {left.Minutes} мин.");
                    }
                    else if (HomeMode.Avatar.BanUntil.HasValue && HomeMode.Avatar.BanUntil.Value <= DateTime.UtcNow)
                    {
                        // Бан истёк, снимаем
                        HomeMode.Avatar.IsBanned = false;
                        HomeMode.Avatar.BanReason = null;
                        HomeMode.Avatar.BanUntil = null;
                    }
                    else
                    {
                        SendBanNotification(HomeMode.Avatar.BanReason ?? "Ваш аккаунт забанен.");
                    }
                    throw new Exception("BANNED");
                }
            }
            // === Вставлять вызов CheckBanAndNotify() в начале всех игровых обработчиков ===
            // Например:
            // public void SomeGameAction(...)
            // {
            //     try { CheckBanAndNotify(); } catch { return; }
            //     ...
            // }
            // ... существующий код ...
            // === Команды для админа ===
            // Внутри ChatToAllianceStreamReceived или аналогичного обработчика:
            if (HomeMode.Avatar.AccountId == 2 && message.Message.StartsWith("/ban "))
            {
                var parts = message.Message.Split(' ');
                if (parts.Length >= 2 && long.TryParse(parts[1], out long targetId))
                {
                    var acc = Accounts.Load(targetId);
                    if (acc != null && acc.Avatar != null)
                    {
                        acc.Avatar.IsBanned = true;
                        int minutes = 0;
                        if (parts.Length >= 3 && int.TryParse(parts[2], out minutes) && minutes > 0)
                            acc.Avatar.BanUntil = DateTime.UtcNow.AddMinutes(minutes);
                        else
                            acc.Avatar.BanUntil = null; // перманентный бан
                        acc.Avatar.BanReason = parts.Length >= 4 ? string.Join(' ', parts.Skip(3)) : "Вы забанены!";
                        SendNotification($"Игрок {targetId} забанен.");
                    }
                }
                return;
            }
            if (HomeMode.Avatar.AccountId == 2 && message.Message.StartsWith("/unban "))
            {
                var parts = message.Message.Split(' ');
                if (parts.Length >= 2 && long.TryParse(parts[1], out long targetId))
                {
                    var acc = Accounts.Load(targetId);
                    if (acc != null && acc.Avatar != null)
                    {
                        acc.Avatar.IsBanned = false;
                        acc.Avatar.BanReason = null;
                        acc.Avatar.BanUntil = null;
                        SendNotification($"Игрок {targetId} разбанен.");
                    }
                }
                return;
            }
        }

        private void JoinAllianceReceived(JoinAllianceMessage message)
        {
            Alliance alliance = Alliances.Load(message.AllianceId);
            if (HomeMode.Avatar.AllianceId > 0) return;
            if (alliance == null) return;
            if (alliance.Members.Count >= 5000) return;

            AllianceStreamEntry entry = new AllianceStreamEntry();
            entry.AuthorId = HomeMode.Avatar.AccountId;
            entry.AuthorName = HomeMode.Avatar.Name;
            entry.Id = ++alliance.Stream.EntryIdCounter;
            entry.PlayerId = HomeMode.Avatar.AccountId;
            entry.PlayerName = HomeMode.Avatar.Name;
            entry.Type = 4;
            entry.Event = 3;
            entry.AuthorRole = HomeMode.Avatar.AllianceRole;
            alliance.AddStreamEntry(entry);

            HomeMode.Avatar.AllianceRole = AllianceRole.Member;
            HomeMode.Avatar.AllianceId = alliance.Id;
            alliance.Members.Add(new AllianceMember(HomeMode.Avatar));

            AllianceResponseMessage response = new AllianceResponseMessage();
            response.ResponseType = 40;
            Connection.Send(response);

            SendMyAllianceData(alliance);
        }

        private void LeaveAllianceReceived(LeaveAllianceMessage message)
        {
            if (HomeMode.Avatar.AllianceId < 0 || HomeMode.Avatar.AllianceRole == AllianceRole.None) return;

            Alliance alliance = Alliances.Load(HomeMode.Avatar.AllianceId);
            if (alliance == null) return;

            alliance.RemoveMemberById(HomeMode.Avatar.AccountId);
            HomeMode.Avatar.AllianceId = -1;
            HomeMode.Avatar.AllianceRole = AllianceRole.None;

            AllianceStreamEntry entry = new AllianceStreamEntry();
            entry.AuthorId = HomeMode.Avatar.AccountId;
            entry.AuthorName = HomeMode.Avatar.Name;
            entry.Id = ++alliance.Stream.EntryIdCounter;
            entry.PlayerId = HomeMode.Avatar.AccountId;
            entry.PlayerName = HomeMode.Avatar.Name;
            entry.Type = 4;
            entry.Event = 4;
            entry.AuthorRole = HomeMode.Avatar.AllianceRole;
            alliance.AddStreamEntry(entry);

            AllianceResponseMessage response = new AllianceResponseMessage();
            response.ResponseType = 80;
            Connection.Send(response);

            MyAllianceMessage myAlliance = new MyAllianceMessage();
            Connection.Send(myAlliance);
        }

        private void SeasonRewardsMessageReceived(GetSeasunRewardsMessage message)
        {
            SeasonRewardsMessage ses = new SeasonRewardsMessage();
            ses.Type = message.Type;
            Connection.Send(ses);
        }
        private void CreateAllianceReceived(CreateAllianceMessage message)
        {
            if (HomeMode.Avatar.AllianceId >= 0) return;

            Alliance alliance = new Alliance();
            alliance.Name = message.Name;
            alliance.Description = message.Description;
            alliance.RequiredTrophies = message.RequiredTrophies;

            if (message.BadgeId >= 8000000 && message.BadgeId < 8000000 + DataTables.Get(DataType.AllianceBadge).Count)
            {
                alliance.AllianceBadgeId = message.BadgeId;
            }
            else
            {
                alliance.AllianceBadgeId = 8000000;
            }

            HomeMode.Avatar.AllianceRole = AllianceRole.Leader;
            alliance.Members.Add(new AllianceMember(HomeMode.Avatar));

            Alliances.Create(alliance);

            HomeMode.Avatar.AllianceId = alliance.Id;

            AllianceResponseMessage response = new AllianceResponseMessage();
            response.ResponseType = 20;
            Connection.Send(response);

            SendMyAllianceData(alliance);
        }

        private void AskForAllianceDataReceived(AskForAllianceDataMessage message)
        {
            Alliance alliance = Alliances.Load(message.AllianceId);
            if (alliance == null) return;

            AllianceDataMessage data = new AllianceDataMessage();
            data.Alliance = alliance;
            data.IsMyAlliance = message.AllianceId == HomeMode.Avatar.AllianceId;
            Connection.Send(data);
        }

        private void AskForJoinableAllianceListReceived(AskForJoinableAllianceListMessage message)
        {
            JoinableAllianceListMessage list = new JoinableAllianceListMessage();
            List<Alliance> alliances = Alliances.GetRandomAlliances(10);
            foreach (Alliance alliance in alliances)
            {
                list.JoinableAlliances.Add(alliance.Header);
            }
            Connection.Send(list);
        }

        private void ClientCapabilitesReceived(ClientCapabilitiesMessage message)
        {
            Connection.PingUpdated(message.Ping);
        }

        private void GetLeaderboardReceived(GetLeaderboardMessage message)
        {
            try
            {
                if (message.LeaderboardType == 0)
                {
                    // Получаем список бравлеров для таблицы лидеров
                    Account[] rankingList = Leaderboards.GetBrawlerRankingList(message.HeroDataId);

                    LeaderboardMessage leaderboard = new LeaderboardMessage();
                    leaderboard.LeaderboardType = 0;
                    leaderboard.Region = message.IsRegional ? HomeMode.Avatar.Region : null;
                    leaderboard.AvatarRegion = HomeMode.Avatar.Region;
                    leaderboard.HeroDataId = message.HeroDataId;
                    
                    // Добавляем аватары в таблицу лидеров с учетом региональной фильтрации
                    foreach (Account data in rankingList)
                    {
                        if (!message.IsRegional || (message.IsRegional && HomeMode.Avatar.Region == data.Avatar.Region))
                        {
                            leaderboard.Avatars.Add(new KeyValuePair<ClientHome, ClientAvatar>(data.Home, data.Avatar));
                        }
                    }
                    
                    leaderboard.OwnAvatarId = Connection.Avatar.AccountId;
                    Connection.Send(leaderboard);
                }
                else if (message.LeaderboardType == 1)
                {
                    // Получаем список игроков для глобальной таблицы лидеров по трофеям
                    Account[] rankingList = Leaderboards.GetAvatarRankingList();

                    LeaderboardMessage leaderboard = new LeaderboardMessage();
                    leaderboard.LeaderboardType = 1;
                    leaderboard.Region = message.IsRegional ? HomeMode.Avatar.Region : null;
                    leaderboard.AvatarRegion = HomeMode.Avatar.Region;
                    
                    // Добавляем аватары в таблицу лидеров с учетом региональной фильтрации
                    foreach (Account data in rankingList)
                    {
                        if (!message.IsRegional || (message.IsRegional && HomeMode.Avatar.Region == data.Avatar.Region))
                        {
                            leaderboard.Avatars.Add(new KeyValuePair<ClientHome, ClientAvatar>(data.Home, data.Avatar));
                        }
                    }
                    
                    leaderboard.OwnAvatarId = Connection.Avatar.AccountId;
                    Connection.Send(leaderboard);
                }
                else if (message.LeaderboardType == 2)
                {
                    try
                    {
                        // Получаем список альянсов для таблицы лидеров
                        Alliance[] rankingList = Leaderboards.GetAllianceRankingList();

                        LeaderboardMessage leaderboard = new LeaderboardMessage();
                        leaderboard.LeaderboardType = 2;
                        leaderboard.Region = message.IsRegional ? HomeMode.Avatar.Region : null;
                        leaderboard.AvatarRegion = HomeMode.Avatar.Region;
                        
                        if (rankingList != null && rankingList.Length > 0)
                        {
                            // Фильтруем валидные альянсы
                            var validAlliances = new List<Alliance>();
                            foreach (var alliance in rankingList)
                            {
                                if (alliance != null && !string.IsNullOrEmpty(alliance.Name))
                                {
                                    // Для региональных таблиц лидеров альянсов нужно добавить поле Region в класс Alliance
                                    // и реализовать фильтрацию по региону. Пока добавляем все альянсы для глобальной таблицы.
                                    if (!message.IsRegional)
                                    {
                                        validAlliances.Add(alliance);
                                    }
                                }
                            }
                            
                            leaderboard.AllianceList.AddRange(validAlliances);
                            Console.WriteLine($"Sending alliance leaderboard with {validAlliances.Count} alliances");
                        }
                        else
                        {
                            Console.WriteLine("No alliances found for leaderboard");
                        }
                        
                        Connection.Send(leaderboard);
                    }
                    catch (Exception allianceEx)
                    {
                        Console.WriteLine($"Error processing alliance leaderboard: {allianceEx.Message}");
                        
                        // Отправляем пустой рейтинг в случае ошибки
                        LeaderboardMessage emptyLeaderboard = new LeaderboardMessage();
                        emptyLeaderboard.LeaderboardType = 2;
                        emptyLeaderboard.Region = message.IsRegional ? HomeMode.Avatar.Region : null;
                        emptyLeaderboard.AvatarRegion = HomeMode.Avatar.Region;
                        Connection.Send(emptyLeaderboard);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Ошибка при обработке запроса таблицы лидеров: {ex.Message}");
            }
        }

        private void GoHomeReceived(GoHomeMessage message)
        {
            //return;
            if (Connection.Home != null && Connection.Avatar != null)
            {
                OwnHomeDataMessage ohd = new OwnHomeDataMessage();
                ohd.Home = Connection.Home;
                ohd.Avatar = Connection.Avatar;
                Connection.Send(ohd);
            }
        }

        private void GoHomeFromMapEditorReceived(GoHomeFromMapEditorMessage message)
        {
            if (Connection.Home != null && Connection.Avatar != null)
            {
                OwnHomeDataMessage ohd = new OwnHomeDataMessage();
                ohd.Home = Connection.Home;
                ohd.Avatar = Connection.Avatar;
                Connection.Send(ohd);
            }
        }

        private void ClientInfoReceived(ClientInfoMessage message)
        {
            UdpConnectionInfoMessage info = new UdpConnectionInfoMessage();
            info.SessionId = Connection.UdpSessionId;
            info.ServerAddress = Configuration.Instance.UdpHost;
            info.ServerPort = Configuration.Instance.UdpPort;
            Connection.Send(info);
        }

        private void CancelMatchMaking(CancelMatchmakingMessage message)
        {
            Matchmaking.CancelMatchmake(Connection);
            Connection.Send(new MatchMakingCancelledMessage());
        }

        private void MatchmakeRequestReceived(MatchmakeRequestMessage message)
        {
            int slot = message.EventSlot;

            //if (HomeMode.Home.Character.Disabled)
            //{
            //    Connection.Send(new OutOfSyncMessage());
            //    return;
            //}

            if (!Events.HasSlot(slot))
            {
                slot = 1;
            }

            // === В начало MatchmakeRequestReceived ===
            if (HomeMode.Avatar.IsBanned && HomeMode.Avatar.BanUntil.HasValue && HomeMode.Avatar.BanUntil.Value <= DateTime.UtcNow)
            {
                HomeMode.Avatar.IsBanned = false;
                HomeMode.Avatar.BanReason = null;
                HomeMode.Avatar.BanUntil = null;
            }
            if (HomeMode.Avatar.IsBanned)
            {
                var left = HomeMode.Avatar.BanUntil.HasValue ? HomeMode.Avatar.BanUntil.Value - DateTime.UtcNow : (TimeSpan?)null;
                SendBanNotification(
                    $"Вы не можете начать подбор, пока не пройдет бан.\n" +
                    $"{HomeMode.Avatar.BanReason ?? "Причина не указана."}" +
                    (left.HasValue ? $"\nДо окончания: {left.Value.Hours} ч. {left.Value.Minutes} мин." : "")
                );
                return;
            }
            // Автоматическое снятие мута, если время истекло
            if (HomeMode.Avatar.IsMutedInClub && HomeMode.Avatar.MuteUntilInClub.HasValue && HomeMode.Avatar.MuteUntilInClub.Value <= DateTime.UtcNow)
            {
                HomeMode.Avatar.IsMutedInClub = false;
                HomeMode.Avatar.MuteReasonInClub = null;
                HomeMode.Avatar.MuteUntilInClub = null;
            }
            // Блокировка чата, если мут активен
            if (HomeMode.Avatar.IsMutedInClub)
            {
                var left = HomeMode.Avatar.MuteUntilInClub.HasValue ? HomeMode.Avatar.MuteUntilInClub.Value - DateTime.UtcNow : (TimeSpan?)null;
                SendBanNotification(
                    $"Вы не можете писать в чат клуба, пока не пройдет мут.\n" +
                    $"{HomeMode.Avatar.MuteReasonInClub ?? "Причина не указана."}" +
                    (left.HasValue ? $"\nДо окончания: {left.Value.Hours} ч. {left.Value.Minutes} мин." : "")
                );
                return;
            }
            // ... существующий код ...
            if (HomeMode.Avatar.TeamId > 0)
            {
                var team = Teams.Get(HomeMode.Avatar.TeamId);
                if (team != null)
                {
                    foreach (var member in team.Members)
                    {
                        var acc = Accounts.Load(member.AccountId);
                        if (acc != null && acc.Avatar != null && acc.Avatar.IsBanned)
                        {
                            var left = acc.Avatar.BanUntil.HasValue ? acc.Avatar.BanUntil.Value - DateTime.UtcNow : (TimeSpan?)null;
                            if (member.AccountId == HomeMode.Avatar.AccountId)
                            {
                                SendBanNotification(
                                    $"Вы не можете играть в команде, пока не пройдет бан.\n" +
                                    $"{acc.Avatar.BanReason ?? "Причина не указана."}" +
                                    (left.HasValue ? $"\nДо окончания: {left.Value.Hours} ч. {left.Value.Minutes} мин." : "")
                                );
                                return;
                            }
                            else
                            {
                                SendBanNotification(
                                    $"Вы не можете играть с забаненным игроком в команде (ID: {member.AccountId}).\n" +
                                    $"Причина: {acc.Avatar.BanReason ?? "Не указана."}" +
                                    (left.HasValue ? $"\nДо окончания: {left.Value.Hours} ч. {left.Value.Minutes} мин." : "")
                                );
                                return;
                            }
                        }
                    }
                }
            }
            // ... существующий код ...

            Matchmaking.RequestMatchmake(Connection, slot);
        }

        private void SinglePlayerMatchRequestReceived(SinglePlayerMatchRequestMessage message)
        {
            if (HomeMode.Avatar.IsBanned && HomeMode.Avatar.BanUntil.HasValue && HomeMode.Avatar.BanUntil.Value <= DateTime.UtcNow)
            {
                HomeMode.Avatar.IsBanned = false;
                HomeMode.Avatar.BanReason = null;
                HomeMode.Avatar.BanUntil = null;
            }
            if (HomeMode.Avatar.IsBanned)
            {
                var left = HomeMode.Avatar.BanUntil.HasValue ? HomeMode.Avatar.BanUntil.Value - DateTime.UtcNow : (TimeSpan?)null;
                SendBanNotification(
                    $"Вы не можете начать подбор, пока не пройдет бан.\n" +
                    $"{HomeMode.Avatar.BanReason ?? "Причина не указана."}" +
                    (left.HasValue ? $"\nДо окончания: {left.Value.Hours} ч. {left.Value.Minutes} мин." : "")
                );
                return;
            }

            // Получаем GameModeVariation для выбранной карты
            var location = DataTables.Get(DataType.Location).GetDataByGlobalId<LocationData>(15000121);
            int gameModeVariation = GameModeUtil.GetGameModeVariation(location.GameModeVariation);
            if (gameModeVariation == 13)
            {
                SendNotification("Тренировочная пещера временно недоступна!");
                return;
            }
            BattleMode battle = new BattleMode(15000121);
            battle.Id = Battles.Add(battle);

            BattlePlayer player = BattlePlayer.Create(Connection.Home, Connection.Avatar, 0, 0);
            player.CharacterIds[0] = message.CharacterId;
            player.SkinIds[0] = message.SkinId;
            player.CharacterDatas[0] = (DataTables.Get(DataType.Character).GetDataWithId<CharacterData>(message.CharacterId));
            player.HeroIndexMax = 0;
            player.Gear1 = null;
            player.Gear2 = null;
            player.Accessory = null;
            Hero hero = Connection.Avatar.GetHero(message.CharacterId);

            if (hero != null)
            {
                player.Trophies = hero.Trophies;
                player.HighestTrophies = hero.HighestTrophies;
            }
            else
            {
                player.Trophies = 0;
                player.HighestTrophies = 0;
            }
            player.HeroPowerLevel = 11;
            if (hero != null)
            {
                player.Emotes.Remove(1);
                player.Emotes.Add(1, hero.emote[1]);
                player.Emotes.Remove(2);
                player.Emotes.Add(2, hero.emote[2]);
                player.Emotes.Remove(3);
                player.Emotes.Add(3, hero.emote[3]);
            }
            UDPSocket socket = UDPGateway.CreateSocket();
            socket.TCPConnection = Connection;
            socket.Battle = battle;
            Connection.UdpSessionId = socket.SessionId;
            battle.AddPlayer(player, Connection.UdpSessionId);


            if (battle.m_players[0].IsAdmin) for (int i = 0; i < 120; i++) battle.m_time.IncreaseTick();
            battle.AddGameObjects();

            StartLoadingMessage startLoading = new StartLoadingMessage();
            startLoading.LocationId = battle.Location.GetGlobalId();
            startLoading.TeamIndex = player.TeamIndex;
            startLoading.OwnIndex = player.PlayerIndex;
            startLoading.GameMode = battle.GetGameModeVariation();
            startLoading.GameType = 8;

            Connection.Avatar.UdpSessionId = Connection.UdpSessionId;
            startLoading.Players.AddRange(battle.GetPlayers());
            Connection.Send(startLoading);
            battle.Dummy = startLoading;

            battle.Start();

            // === В начало SinglePlayerMatchRequestReceived ===
            if (HomeMode.Avatar.IsBanned && HomeMode.Avatar.BanUntil.HasValue && HomeMode.Avatar.BanUntil.Value <= DateTime.UtcNow)
            {
                HomeMode.Avatar.IsBanned = false;
                HomeMode.Avatar.BanReason = null;
                HomeMode.Avatar.BanUntil = null;
            }
            if (HomeMode.Avatar.IsBanned)
            {
                var left = HomeMode.Avatar.BanUntil.HasValue ? HomeMode.Avatar.BanUntil.Value - DateTime.UtcNow : (TimeSpan?)null;
                SendBanNotification(
                    $"Вы не можете начать подбор, пока не пройдет бан.\n" +
                    $"{HomeMode.Avatar.BanReason ?? "Причина не указана."}" +
                    (left.HasValue ? $"\nДо окончания: {left.Value.Hours} ч. {left.Value.Minutes} мин." : "")
                );
                return;
            }
            // ... существующий код ...
            if (HomeMode.Avatar.TeamId > 0)
            {
                var team = Teams.Get(HomeMode.Avatar.TeamId);
                if (team != null)
                {
                    foreach (var member in team.Members)
                    {
                        var acc = Accounts.Load(member.AccountId);
                        if (acc != null && acc.Avatar != null && acc.Avatar.IsBanned)
                        {
                            var left = acc.Avatar.BanUntil.HasValue ? acc.Avatar.BanUntil.Value - DateTime.UtcNow : (TimeSpan?)null;
                            if (member.AccountId == HomeMode.Avatar.AccountId)
                            {
                                SendBanNotification(
                                    $"Вы не можете играть в команде, пока не пройдет бан.\n" +
                                    $"{acc.Avatar.BanReason ?? "Причина не указана."}" +
                                    (left.HasValue ? $"\nДо окончания: {left.Value.Hours} ч. {left.Value.Minutes} мин." : "")
                                );
                                return;
                            }
                            else
                            {
                                SendBanNotification(
                                    $"Вы не можете играть с забаненным игроком в команде (ID: {member.AccountId}).\n" +
                                    $"Причина: {acc.Avatar.BanReason ?? "Не указана."}" +
                                    (left.HasValue ? $"\nДо окончания: {left.Value.Hours} ч. {left.Value.Minutes} мин." : "")
                                );
                                return;
                            }
                        }
                    }
                }
            }
            // ... существующий код ...
        }

        private void EndClientTurnReceived(EndClientTurnMessage message)
        {
            HomeMode.ClientTurnReceived(message.Tick, message.Checksum, message.Commands);
            switch (message.type) {
                case 506:
                   if (HomeMode.Avatar.TeamId > 0)
                   {
                    TeamEntry team = Teams.Get(HomeMode.Avatar.TeamId);
                    if (team == null)
                    {
                        return;
                    }
                    TeamMember m = team.GetMember(HomeMode.Avatar.AccountId);
                    if (m == null)
                    {
                        return;
                    }
                    Hero hero = HomeMode.Avatar.GetHero(HomeMode.Home.CharacterIds[0]);
                    m.CharacterId = HomeMode.Home.CharacterIds[0];
                    m.SkinId = GlobalId.CreateGlobalId(29, hero.SelectedSkinId);
                    m.HeroTrophies = hero.Trophies;
                    m.HeroHighestTrophies = hero.HighestTrophies;
                    m.HeroLevel = hero.PowerLevel;
                    team.TeamUpdated();
                   }
                   break;
            }
        }

        private void GetPlayerProfile(GetPlayerProfileMessage message)
        {
            Account data = Accounts.Load(message.AccountId);
            if (data == null) return;

            Profile profile = Profile.Create(data.Home, data.Avatar);

            PlayerProfileMessage profileMessage = new PlayerProfileMessage();
            profileMessage.Profile = profile;
            if (data.Avatar.AllianceId >= 0)
            {
                Alliance alliance = Alliances.Load(data.Avatar.AllianceId);

                if (alliance != null)
                {
                    profileMessage.AllianceHeader = alliance.Header;
                    profileMessage.AllianceRole = data.Avatar.AllianceRole;
                }
            }
            Connection.Send(profileMessage);
        }

        private void ChangeName(ChangeAvatarNameMessage message)
        {
            LogicChangeAvatarNameCommand command = new LogicChangeAvatarNameCommand();
            command.Name = message.Name;
            command.ChangeNameCost = 0;
            command.Execute(HomeMode);
            AvailableServerCommandMessage serverCommandMessage = new AvailableServerCommandMessage();
            serverCommandMessage.Command = command;
            Connection.Send(serverCommandMessage);
        }

        private void OnChangeCharacter(int characterId)
        {
            TeamEntry team = Teams.Get(HomeMode.Avatar.TeamId);
            if (team == null) return;

            TeamMember member = team.GetMember(HomeMode.Avatar.AccountId);
            if (member == null) return;
            if (characterId == 0) goto LABEL_1;

            Hero hero = HomeMode.Avatar.GetHero(characterId);
            if (hero == null) return;
            member.CharacterId = characterId;
            member.SkinId = GlobalId.CreateGlobalId(29, hero.SelectedSkinId);
            member.HeroTrophies = hero.Trophies;
            member.HeroHighestTrophies = hero.HighestTrophies;
            member.HeroLevel = hero.PowerLevel;

        LABEL_1:
            team.TeamUpdated();
        }
        private void LoginReceived(AuthenticationMessage message)
        {
            if (message.ClientMajor < 52)
            {
                Connection.Send(new AuthenticationFailedMessage()
                {
                    ErrorCode = 8,
                    UpdateUrl = "https://pd.qq.com/s/3az5imfyn"
                });
                return;
            }
            if (Sessions.Maintenance)
            {
                Connection.Send(new AuthenticationFailedMessage()
                {
                    ErrorCode = 10,
                    dateTime = DateTime.Parse("2023-02-14 13:30:00")
                });
                return;
            }

            Account account = null;
            if (message.AccountId == 0)
            {
                account = Accounts.Create();
                AccountCache.SaveAll();
            }
            else
            {
                account = Accounts.Load(message.AccountId);
            }
            int penis = 124;
            Logger.Print($"Login sha: {message.ResourceSha}");
            if (message.ResourceSha != Fingerprint.Sha && penis == 0)
            {
                Logger.Warning($"Login sha: {message.ResourceSha} Server Sha: {Fingerprint.Sha}");
                {
                    AuthenticationFailedMessage loginFailed = new AuthenticationFailedMessage();
                    loginFailed.ErrorCode = 7;
                    loginFailed.FingerprintSha = Fingerprint.Sha;
                    loginFailed.ContentUrl = "http://185.87.192.202:80/";
                    Connection.Send(loginFailed);
                    return;
                }
            }
            if (account == null)
            {
                AuthenticationFailedMessage loginFailed = new AuthenticationFailedMessage();
                loginFailed.ErrorCode = 22;
                loginFailed.Message = "Account not loaded. Please clear app data and try again.";
                Connection.Send(loginFailed);
                return;
            }

            Debugger.Print(account.Avatar.Name + "(" + account.AccountId + ") login.");

            // --- СТРОГАЯ ПРОВЕРКА НА БАН ---
            if (account.Avatar.BanUntil != null && account.Avatar.BanUntil > DateTime.UtcNow)
            {
                var until = account.Avatar.BanUntil.Value.ToString("yyyy-MM-dd HH:mm");
                var reason = account.Avatar.BanReason ?? "Не указана";
                AuthenticationFailedMessage loginFailed = new AuthenticationFailedMessage();
                loginFailed.ErrorCode = 11;
                loginFailed.Message = $"Вы забанены до {until}\nПричина: {reason}";
                Connection.Send(loginFailed);
                return;
            }
            // --- КОНЕЦ ПРОВЕРКИ НА БАН ---

            AuthenticationOkMessage loginOk = new AuthenticationOkMessage();
            loginOk.AccountId = account.AccountId;
            loginOk.PassToken = account.PassToken;
            loginOk.ServerEnvironment = "dev";
            Connection.Send(loginOk);

            HomeMode = HomeMode.LoadHomeState(new HomeGameListener(Connection), account.Home, account.Avatar, Events.GetEvents());
            HomeMode.CharacterChanged += OnChangeCharacter;
            if (HomeMode.Avatar.HighestTrophies == 0 && HomeMode.Avatar.Trophies != 0)
            {
                HomeMode.Avatar.HighestTrophies = HomeMode.Avatar.Trophies;
            }

            FriendListMessage friendList = new FriendListMessage();
            friendList.Friends = HomeMode.Avatar.Friends.ToArray();
            Connection.Send(friendList);
            BattleMode battle = null;

            if (HomeMode.Avatar.BattleId > 0)
            {
                battle = Battles.Get(HomeMode.Avatar.BattleId);
            }

            if (battle == null)
            {
                OwnHomeDataMessage ohd = new OwnHomeDataMessage();
                ohd.Home = HomeMode.Home;
                ohd.Avatar = HomeMode.Avatar;
                Connection.Send(ohd);
            }
            else
            {
                StartLoadingMessage startLoading = battle.Dummy;
                startLoading.TeamIndex = HomeMode.Avatar.TeamIndex;
                startLoading.OwnIndex = HomeMode.Avatar.OwnIndex;
                UDPSocket socket = UDPGateway.CreateSocket();
                socket.TCPConnection = Connection;
                socket.Battle = battle;
                Connection.UdpSessionId = socket.SessionId;
                battle.ChangePlayerSessionId(HomeMode.Avatar.UdpSessionId, socket.SessionId);
                HomeMode.Avatar.UdpSessionId = socket.SessionId;
                Connection.Send(startLoading);
            }

            Connection.Avatar.LastOnline = DateTime.UtcNow;

            Sessions.Create(HomeMode, Connection);
            if (false)
            {
                TeamInvitationMessage teamInvitationMessage = new TeamInvitationMessage();
                teamInvitationMessage.TeamId = -1;

                Friend friendEntry = new Friend();
                friendEntry.AccountId = new LogicLong(-1, -1);
                friendEntry.DisplayData = new PlayerDisplayData(HomeMode.Home.ThumbnailId, HomeMode.Home.NameColorId, HomeMode.Avatar.Name);
                friendEntry.Trophies = HomeMode.Avatar.Trophies;
                teamInvitationMessage.Unknown = 1;
                teamInvitationMessage.FriendEntry = friendEntry;

                Connection.Send(teamInvitationMessage);
            }
            if (HomeMode.Avatar.AllianceRole != AllianceRole.None && HomeMode.Avatar.AllianceId > 0)
            {
                Alliance alliance = Alliances.Load(HomeMode.Avatar.AllianceId);

                if (alliance != null)
                {
                    SendMyAllianceData(alliance);
                    AllianceDataMessage data = new AllianceDataMessage();
                    data.Alliance = alliance;
                    data.IsMyAlliance = true;
                    Connection.Send(data);

                    foreach (var member in alliance.Members)
                    {
                        if (LogicServerListener.Instance.IsPlayerOnline(member.AccountId))
                        {
                            Connection.Send(new AllianceOnlineStatusUpdatedMessage() { AvatarId = member.AccountId, Members = alliance.Members.Count, PlayerStatus = member.Avatar.PlayerStatus });
                        }

                    }
                }
            }

            foreach (Friend entry in HomeMode.Avatar.Friends.ToArray())
            {
                if (LogicServerListener.Instance.IsPlayerOnline(entry.AccountId))
                {
                        FriendOnlineStatusEntryMessage statusEntryMessage = new FriendOnlineStatusEntryMessage();
                    statusEntryMessage.AvatarId = entry.AccountId;
                    statusEntryMessage.PlayerStatus = entry.Avatar.PlayerStatus;
                    statusEntryMessage.AllianceTeamEntry = Teams.Get(entry.Avatar.TeamId);
                        Connection.Send(statusEntryMessage);
                    }
                }
                    if (HomeMode.Avatar.TeamId <= 0)
                    {
                        //TeamCreateReceived(new TeamCreateMessage());
                    }

                    if (HomeMode.Avatar.TeamId > 0)
                    {
                            TeamMessage teamMessage = new TeamMessage();
                            teamMessage.Team = Teams.Get(HomeMode.Avatar.TeamId);
                            if (teamMessage.Team != null)
                            {
                                TeamMember member = teamMessage.Team.GetMember(HomeMode.Avatar.AccountId);
                                if (member != null)
                                {
                                    Hero hero = HomeMode.Avatar.GetHero(HomeMode.Home.CharacterId);
                                    if (hero != null)
                                    {
                                        member.HeroTrophies = hero.Trophies;
                                        member.HeroHighestTrophies = hero.HighestTrophies;
                                        member.HeroLevel = hero.PowerLevel;
                                    }
                                    member.State = 0;
                                }
                                Connection.Send(teamMessage);
                                teamMessage.Team.TeamUpdated();
                            }
                    }
            //LogicAddNotificationCommand logicAddNotificationCommand = new LogicAddNotificationCommand();
            //string name = GamePlayUtil.GetHeroName(DataTables.Get(16).GetDataByGlobalId<CharacterData>(HomeMode.Home.CharacterId).Name);
            //if (HomeMode.Home.FavouriteCharacter != 16000000 && RandomNumberGenerator.GetInt32(2) == 1) name = GamePlayUtil.GetHeroName(DataTables.Get(16).GetDataByGlobalId<CharacterData>(HomeMode.Home.FavouriteCharacter).Name);
            //if (name != null)
            //{
            //    logicAddNotificationCommand.Notification = new FloaterTextNotification(name + ": 你好。");

            //    AvailableServerCommandMessage availableServerCommandMessage = new AvailableServerCommandMessage();
            //    availableServerCommandMessage.Command = logicAddNotificationCommand;
            //    Connection.Send(availableServerCommandMessage);
            //}
                            }

        private void ClientHelloReceived(ClientHelloMessage message)
        {
            Connection.Messaging.DisableCrypto = false;
            if (Sessions.Maintenance)
            {
                Connection.Send(new AuthenticationFailedMessage()
                {
                    ErrorCode = 10
                });
                return;
            }

            if (message.MajorVersion < 53)
            {
                Connection.Send(new AuthenticationFailedMessage()
                {
                    ErrorCode = 8,
                    UpdateUrl = "https://pd.qq.com/s/3az5imfyn"
                });
                return;
            }
            //Connection.Send(new AuthenticationFailedMessage()
            //{
            //    ErrorCode = 8,
            //    UpdateUrl = "https://pd.qq.com/s/3az5imfyn"
            //});
            //return;
            Connection.Messaging.Seed = message.ClientSeed;
            Connection.Nonce = Helpers.RandomString(32);
            ServerHelloMessage hello = new ServerHelloMessage();
            hello.SetServerHelloToken(Connection.Messaging.SessionToken);
            hello.Nonce = Connection.Nonce;
            Connection.Send(hello);
        }

        void SendNotification(string text)
                {
            var notification = new Supercell.Laser.Logic.Notification.FloaterTextNotification(text);
            var command = new LogicAddNotificationCommand();
            command.Notification = notification;
            var msg = new AvailableServerCommandMessage();
            msg.Command = command;
            Connection.Send(msg);
                }

        // === Функция для отправки FloaterTextNotification о бане ===
        void SendBanNotification(string text)
        {
            var notification = new Supercell.Laser.Logic.Notification.FloaterTextNotification(text);
            var command = new Supercell.Laser.Logic.Command.Home.LogicAddNotificationCommand();
            command.Notification = notification;
            var msg = new Supercell.Laser.Logic.Message.Home.AvailableServerCommandMessage();
            msg.Command = command;
            HomeMode.GameListener.SendMessage(msg);
        }

    }
}
