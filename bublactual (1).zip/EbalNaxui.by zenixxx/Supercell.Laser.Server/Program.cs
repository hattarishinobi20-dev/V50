﻿namespace Supercell.Laser.Server
{
    using Masuda.Net;
    using Masuda.Net.HelpMessage;
    using Masuda.Net.Models;
    using Supercell.Laser.Server.Database.Models;
    using Supercell.Laser.Server.Database;
    using Supercell.Laser.Server.Handler;
    using Supercell.Laser.Server.Settings;
    using Supercell.Laser.Titan.Debug;
    using System.Drawing;
    using Supercell.Laser.Server.Networking.Session;
    using Supercell.Laser.Server.Fingerprint;
    using Supercell.Laser.Logic.Avatar;


    static class Program
    {
        public const string SERVER_VERSION = "1.0";
        public const string BUILD_TYPE = "Alpha";

        private static void Main(string[] args)
        {

            Console.Title = "Supercell.Laser";
            Directory.SetCurrentDirectory(AppContext.BaseDirectory);
            RefreshFingerprint.Main();

            Colorful.Console.WriteWithGradient(
                @"
▀█ █▀█ █▀█ █░█ █ ▀▄▀ █▀▄ █▀▀ █░█
█▄ █▄█ █▀▄ ▀▄▀ █ █░█ █▄▀ ██▄ ▀▄▀" + "\n\n\n", Color.Green, Color.GreenYellow, 10);

            Logger.Print("Server is now starting...");

            Logger.Init();
            Configuration.Instance = Configuration.LoadFromFile("config.json");

            Resources.InitDatabase();
            Resources.InitLogic();
            Resources.InitNetwork();

            Logger.Print("Server started!");

                string botToken = "8226204329:AAHyJ4CkaJB_lEXtxJM_aWzIHc2Mud0gCH0";

            // Создаем экземпляр класса Bot
            var bot = new Bot(botToken);

            // Запускаем бота
            CancellationTokenSource cts = new CancellationTokenSource();
            //bot.StartBotAsync(cts.Token);

            Console.WriteLine("Бот запущен. Нажмите Enter для выхода...");
            Console.ReadLine();

            // Останавливаем бота
            cts.Cancel();
            ExitHandler.Init();
            CmdHandler.Start();
            
   

        }
    }
}