﻿using Supercell.Laser.Logic.Avatar.Structures;
using Supercell.Laser.Logic.Helper;
using Supercell.Laser.Logic.Home;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Supercell.Laser.Logic.Message.Club
{
    public class BattleLogMessage : GameMessage
    {


        public HomeMode homeMode;

        public BattleLogMessage() : base()
        {
            ;
        }
        public override void Encode()
        {
            Stream.WriteBoolean(true); // enabled
            if (homeMode != null) homeMode.Home.BattleLogs.Encode(Stream);
            else
            {
                Console.WriteLine("[BATTLELOGMESSAGE] HOMEMODE IS NULL!");
                Stream.WriteBoolean(false);
            }

        }

        public override int GetMessageType()
        {
            return 23458;
        }

        public override int GetServiceNodeType()
        {
            return 11;
        }
    }
}