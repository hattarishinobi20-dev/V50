﻿namespace Supercell.Laser.Logic.Message.Battle
{
    using Supercell.Laser.Logic.Battle.Structures;
    using Supercell.Laser.Logic.Helper;
    using Supercell.Laser.Titan.Util;

    public class StartBrawlTVMessage : GameMessage
    {
        public override void Encode()
        {
            Stream.WriteString(null);
        }

        public override int GetMessageType()
        {
            return 14700;
        }

        public override int GetServiceNodeType()
        {
            return 4;
        }
    }
}
