﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supercell.Laser.Logic.Message.Battle
{
    class StartBattleTV
    {
    }
}
