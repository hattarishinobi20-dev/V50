namespace Supercell.Laser.Logic.Message.Battle
{
    using System.Numerics;
    using Supercell.Laser.Logic.Battle.Structures;
    using Supercell.Laser.Logic.Helper;
    using Supercell.Laser.Logic.Home.Quest;
    using Supercell.Laser.Logic.Home.Structures;

    public class BattleEndMessage : GameMessage
    {
        public BattleEndMessage() : base()
        {
            ProgressiveQuests = new List<Quest>();
        }

        public int Result;
        public int TokensReward;
        public int TrophiesReward;
        public List<BattlePlayer> Players;
        public List<Quest> ProgressiveQuests;
        public BattlePlayer OwnPlayer;
        public bool StarToken;

        public int GameMode;

        public bool BattleWithoutTrophies;
        public bool IsPvP;

        public int Winstreak;
        public int WinstreakTrophies;
        public int MasteryGained;
        public int WinStreakBonus { get; set; }
        public int WinStreakDelta { get; set; }

        public int ChampionshipLevel;

        // public int Underdog { get; set; } // Бонус для VIP или другие дополнительные награды - временно отключено для теста вылетов

        public bool CanPlayAgain { get; set; }

        public override void Encode()
        {
            try
            {
                Console.WriteLine("Encoding BattleEndMessage started for player: " + (OwnPlayer?.AccountId ?? 0));
                Stream.WriteLong(OwnPlayer?.AccountId ?? 0);
                Stream.WriteLong(OwnPlayer?.AccountId ?? 0);

                Stream.WriteVInt(GameMode); // game mode
                Stream.WriteVInt(Result);
                Stream.WriteVInt(TokensReward); // tokens reward
                Stream.WriteVInt(TrophiesReward); // trophies reward
                Stream.WriteVInt(0);//Power Play Points Gained (Pro League Points)
                Stream.WriteVInt(0);//Doubled Tokens (Double Keys)
                Stream.WriteVInt(0);//Double Token Event (Double Event Keys)
                Stream.WriteVInt(0);//Token Doubler Remaining (Double Keys Remaining)
                Stream.WriteVInt(0);//game Lenght In Seconds
                Stream.WriteVInt(0);//Epic Win Power Play Points Gained (op Win Points)
                Stream.WriteVInt(1);//Championship Level Reached (CC Wins)

                Stream.WriteBoolean(false);//gen offer

                Stream.WriteVInt(0);
                Stream.WriteVInt(0);

                Stream.WriteBoolean(false);//164
                Stream.WriteBoolean(false);//165

                Stream.WriteVInt(0); // lavina manetok
                Stream.WriteVInt(0); // chromalavina
                Stream.WriteVInt(0); // underdog - вернуть к значению по умолчанию
                int actualWinstreakTrophies = BattleWithoutTrophies ? 0 : Math.Max(0, Math.Min(WinstreakTrophies, 5));
                Stream.WriteVInt(actualWinstreakTrophies); // WINSTREAK ++
                Stream.WriteVInt(Math.Max(0, Winstreak)); // WINSTREAK
                Stream.WriteVInt(0); // 
                Stream.WriteVInt(0);// trophies +
                Stream.WriteVInt(0);//v53

                Stream.WriteBoolean(false);
                Stream.WriteBoolean(false); // no experience
                Stream.WriteBoolean(false); // no tokens left
                Stream.WriteBoolean(BattleWithoutTrophies); // Result type
                Stream.WriteBoolean(IsPvP); // isPvp
                Stream.WriteBoolean(false);
                Stream.WriteBoolean(false); // powerplay
                Stream.WriteBoolean(false);

                Stream.WriteVInt(-1);//ChallengeType
                Stream.WriteBoolean(false);

                Stream.WriteVInt(Players?.Count ?? 0);
                if (Players != null)
                {
                    int playerIndex = 0;
                    foreach (BattlePlayer player in Players)
                    {
                        try
                        {
                            Console.WriteLine($"Encoding player {playerIndex}, AccountId: {player?.AccountId ?? 0}");
                            Stream.WriteBoolean(player?.AccountId == OwnPlayer?.AccountId); // is own player
                            Stream.WriteBoolean(player?.TeamIndex != OwnPlayer?.TeamIndex); // is enemy
                            Stream.WriteBoolean(false); // Star player
                            Stream.WriteVInt(1);
                            {
                                ByteStreamHelper.WriteDataReference(Stream, player?.CharacterId ?? 0);
                            }
                            Stream.WriteVInt(1);
                            {
                                ByteStreamHelper.WriteDataReference(Stream, player?.SkinId ?? 0);//skin
                            }
                            Stream.WriteVInt(1);
                            {
                                Stream.WriteVInt(player?.Trophies ?? 0);
                            }
                            Stream.WriteVInt(1);
                            {
                                Stream.WriteVInt(player?.HeroPowerLevel ?? 0);
                            }
                            Stream.WriteVInt(1);
                            {
                                Stream.WriteVInt(0);
                            }

                            Stream.WriteVInt(0);
                            Stream.WriteVInt(0);
                            if (Stream.WriteBoolean(player?.IsBot() == 0))
                            {
                                Stream.WriteLong(player?.AccountId ?? 0);
                            }
                            if (player?.DisplayData != null)
                            {
                                player.DisplayData.Encode(Stream);
                            }
                            else
                            {
                                Console.WriteLine($"Warning: DisplayData is null for player {playerIndex}");
                                Stream.WriteBoolean(false); // Placeholder to avoid crash
                            }
                            Stream.WriteBoolean(false);

                            Hero hero = null;
                            if (player != null && player.IsBot() < 1)
                            {
                                hero = player.Avatar?.GetHero(player.CharacterId) ?? null;
                            }
                            if (hero != null)
                            {
                                Stream.WriteVInt(1);
                                Stream.WriteVInt(hero.MasteryPoints); // mastery points 
                                Stream.WriteVInt(1);
                                Stream.WriteVInt(MasteryGained); // mastery points gained
                            }
                            else
                            {
                                Stream.WriteVInt(0);
                                Stream.WriteVInt(0);
                            }

                            Stream.WriteInt16((short)(player?.Kills ?? 0)); // kills
                            Stream.WriteInt16((short)(player?.Deaths ?? 0)); // deaths
                            Stream.WriteInt(player?.Damage ?? 0); // uron
                            Stream.WriteInt(player?.Heals ?? 0); // heal
                            Stream.WriteDataReference(0);
                            playerIndex++;
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"Error encoding player data at index {playerIndex}: {ex.Message}");
                        }
                    }
                }

                Stream.WriteVInt(0);//xp
                Stream.WriteVInt(0);//dataref

                Stream.WriteVInt(2);
                {
                    Stream.WriteVInt(1);
                    Stream.WriteVInt(OwnPlayer?.Trophies ?? 0); // Trophies
                    Stream.WriteVInt(OwnPlayer?.HighestTrophies ?? 0); // Highest Trophies

                    Stream.WriteVInt(5);
                    Stream.WriteVInt(100);
                    Stream.WriteVInt(100);
                }

                if (OwnPlayer?.Home?.Thumbnail != null)
                {
                    ByteStreamHelper.WriteDataReference(Stream, OwnPlayer.Home.Thumbnail);
                }
                else
                {
                    ByteStreamHelper.WriteDataReference(Stream, 0); // Fallback if Thumbnail is null
                }

                if (Stream.WriteBoolean(CanPlayAgain))//play again
                {
                    Stream.WriteInt(0);
                    Stream.WriteVInt(0);
                    Stream.WriteVInt(0);
                    Stream.WriteInt(0);
                    Stream.WriteInt(0);
                }
                if (Stream.WriteBoolean(false)) //quests
                {
                    Stream.WriteVInt(-1);

                    Stream.WriteVInt(0);
                    Stream.WriteVInt(0);
                    Stream.WriteVInt(0);
                }
                Stream.WriteBoolean(false);
                Stream.WriteBoolean(false);//v53
                Stream.WriteVInt(0);
                Stream.WriteVInt(0);
                Stream.WriteVInt(0);//v53
                Stream.WriteBoolean(false);//ranked match state
                Stream.WriteVInt(-1);
                Stream.WriteBoolean(false);//chronosTextEntry
                Stream.WriteVInt(0);

                Stream.WriteBoolean(false);
                Stream.WriteBoolean(false);
                Stream.WriteVInt(0);
                Stream.WriteVInt(0);//v53
                Stream.WriteBoolean(false);
                Stream.WriteBoolean(false);//v53
                Stream.WriteBoolean(false);//v53
                Console.WriteLine("Encoding BattleEndMessage completed.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Critical Error in BattleEndMessage.Encode: {ex.Message}, StackTrace: {ex.StackTrace}");
            }
        }

        public override int GetMessageType()
        {
            return 23456;
        }

        public override int GetServiceNodeType()
        {
            return 27;
        }
    }
}
