﻿namespace Supercell.Laser.Logic.Message.Home
{
    public class GetSeasunRewardsMessage : GameMessage
    {
        public int Type;
        public override void Decode()
        {
            Type = Stream.ReadVInt();
        }
        public override int GetMessageType()
        {
            return 12938;
        }

        public override int GetServiceNodeType()
        {
            return 9;
        }
    }
}
