using System.Diagnostics;
using Supercell.Laser.Titan.Debug;

namespace Supercell.Laser.Logic.Message.Home
{
    public class LobbyInfoMessage : GameMessage
    {
        public long AccountId;

        public int playercount;

        public LobbyInfoMessage(long accountId)
        {
            this.AccountId = accountId;
        }

        public LobbyInfoMessage() {}


        public override void Encode()
        {
            long megabytesUsed = Process.GetCurrentProcess().PrivateMemorySize64 / (1024 * 1024);

   
            Stream.WriteVInt(playercount);

            Stream.WriteString("TG: @BublBrawl");

            Stream.WriteVInt(0);
        }

        public override int GetMessageType()
        {
            return 23457;
        }

        public override int GetServiceNodeType()
        {
            return 9;
        }
    }
}
