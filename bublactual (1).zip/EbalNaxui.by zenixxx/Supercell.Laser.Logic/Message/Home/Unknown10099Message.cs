using Supercell.Laser.Logic.Message;

namespace Supercell.Laser.Logic.Message.Home
{
    public class Unknown10099Message : GameMessage
    {
        public Unknown10099Message()
        {
            Console.WriteLine("[Unknown10099Message] Конструктор вызван");
        }

        public override int GetMessageType() => 10099;

        public override int GetServiceNodeType() => 1;

        public override void Decode()
        {
            Console.WriteLine("[Unknown10099Message] Decode вызван");
        }

        public override void Encode() { }

        // Просто обычный метод, НЕ override
        public void Process()
        {
            Console.WriteLine("[Unknown10099Message] Process вызван — сообщение игнорируется");
        }
    }
}