using System.Collections.Concurrent;

namespace Supercell.Laser.Logic.Battle.Structures
{
    public static class BattlePlayerManager
    {
        private static ConcurrentDictionary<long, BattlePlayer> _players = new ConcurrentDictionary<long, BattlePlayer>();

        public static void Register(BattlePlayer player)
        {
            if (player != null)
                _players[player.AccountId] = player;
        }

        public static void Unregister(long accountId)
        {
            _players.TryRemove(accountId, out _);
        }

        public static BattlePlayer Get(long accountId)
        {
            _players.TryGetValue(accountId, out var player);
            return player;
        }
    }
}
