namespace Supercell.Laser.Logic.Home.Quest
{
    using Newtonsoft.Json;
    using Supercell.Laser.Logic.Home.Structures;
    using Supercell.Laser.Titan.DataStream;

    public class Quests
    {
        private static readonly int[] ALLOWED_MODES = { 0, 2, 3, 5, 6, 7, 11 }; // Gem Grab, Heist, Bounty, Brawl Ball, Showdown, Big Game, Siege
        private static readonly int[] GOAL_TABLE = { 40000, 50000, 60000, 80000, 100000 };

        [JsonProperty("quest_list")]
        public List<Quest> QuestList;

        public Quests()
        {
            QuestList = new List<Quest>();
        }

        public void AddRandomQuests(List<Hero> unlockedHeroes, int count)
{
    List<int> characters = unlockedHeroes.Select(x => x.CharacterId).ToList();
    Random rand = new Random();
    // Режимы: Solo SHD (6), Heist (2), Gem Grab (0), Bounty (3), Cleanse (12), Big Game (7)
    int[] modeIds = { 6, 2, 0, 3, 25, 7 };
    int[] deathmatchOnly = { 25 };
    int questsPerMode = 10;
    for (int m = 0; m < modeIds.Length; m++)
    {
        int mode = modeIds[m];
        int qCount = (mode == 25) ? 10 : questsPerMode;
        for (int q = 0; q < qCount; q++)
        {
            Quest quest = new Quest();
            quest.GameModeVariation = mode;
            // Разнообразие типов квестов
            int questType = (q % 5) + 1; // 1-сыграть матчи, 2-убить врагов, 3-урон, 4-боец, 5-победы
            if (mode == 7 && (q % 2 == 0)) questType = 6; // для Big Game часть квестов особые
            quest.MissionType = questType;
            switch (questType)
            {
                        case 1:
                            quest.QuestGoal = rand.Next(5, 16);
                            quest.Reward = rand.Next(280, 801); // случайная награда от 280 до 800100 + (quest.QuestGoal * 10);
                            quest.QuestDescription = $"Сыграй {quest.QuestGoal} матчей в режиме {GetModeName(mode)}";
                            break;
                        case 2:
                            quest.QuestGoal = rand.Next(20, 61);
                            quest.Reward = rand.Next(280, 801); // случайная награда от 280 до 800150 + (quest.QuestGoal * 5);
                            quest.QuestDescription = $"Убей {quest.QuestGoal} врагов в режиме {GetModeName(mode)}";
                            break;
                        case 3:
                            quest.QuestGoal = rand.Next(30000, 120001);
                            quest.Reward = rand.Next(280, 801); // случайная награда от 280 до 800200 + (quest.QuestGoal / 500);
                            quest.QuestDescription = $"Нанеси {quest.QuestGoal} урона в режиме {GetModeName(mode)}";
                            break;
                        case 4:
                            quest.CharacterId = characters[rand.Next(characters.Count)];
                            quest.QuestGoal = rand.Next(5, 13);
                            quest.Reward = rand.Next(280, 801); // случайная награда от 280 до 800250 + (quest.QuestGoal * 10);
                            quest.QuestDescription = $"Сыграй {quest.QuestGoal} матчей за бойца {quest.CharacterId} в режиме {GetModeName(mode)}";
                            break;
                        case 5:
                            quest.QuestGoal = rand.Next(3, 11);
                            quest.Reward = rand.Next(280, 801); // случайная награда от 280 до 800200 + (quest.QuestGoal * 15);
                            quest.QuestDescription = $"Победи в {quest.QuestGoal} матчах в режиме {GetModeName(mode)}";
                            break;
                        case 6: // Big Game special
                            if (rand.Next(2) == 0)
                            {
                                quest.MissionType = 3; // урон за босса
                                quest.QuestGoal = rand.Next(80000, 200001);
                                quest.Reward = rand.Next(280, 801); // случайная награда от 280 до 800400 + (quest.QuestGoal / 1000);
                                quest.QuestDescription = $"Нанеси {quest.QuestGoal} урона за босса в Большой игре";
                            }
                            else
                            {
                                quest.MissionType = 5; // победы за охотников
                                quest.QuestGoal = rand.Next(1, 6);
                                quest.Reward = rand.Next(280, 801); // случайная награда от 280 до 800300 + (quest.QuestGoal * 40);
                                quest.QuestDescription = $"Победи босса {quest.QuestGoal} раз в Большой игре";
                            }
                            break;
                    }
                    // Ограничение награды
                    if (quest.Reward > 500) quest.Reward = rand.Next(280, 801); // случайная награда от 280 до 800500;
                    if (quest.Reward < 100) quest.Reward = rand.Next(280, 801); // случайная награда от 280 до 800100;
                    QuestList.Add(quest);
                }
            }
        }

        private string GetModeName(int mode)
        {
            switch (mode)
            {
                case 6: return "Соло ШД";
                case 2: return "Ограбление";
                case 0: return "Захват кристаллов";
                case 3: return "Награда за поимку";
                case 25: return "Deathmatch";
                case 7: return "Большая игра";
                default: return "Режим";
            }
        }

        public List<Quest> UpdateQuestsProgress(ClientHome home, int gameModeVariation, int characterId, int kills, int damage, int heals, int winCount, bool isBigGameBoss, int bossDamage)
        {
            List<Quest> progressive = new List<Quest>();
            List<Quest> completed = new List<Quest>();

            // Проверяем только разрешенные режимы
            if (!ALLOWED_MODES.Contains(gameModeVariation))
            {
                return progressive;
            }

            foreach (Quest quest in QuestList.ToArray())
            {
                if (quest.GameModeVariation == gameModeVariation
                    && (quest.CharacterId == characterId || quest.CharacterId == 0))
                {
                    if (quest.MissionType == 1) // Сыграть матчи
                    {
                        var progress = quest.Clone();
                        progress.Progress = 1;
                        quest.CurrentGoal += 1;
                        if (quest.CurrentGoal >= quest.QuestGoal)
                        {
                            completed.Add(quest);
                        }
                        progressive.Add(progress);
                    }
                    else if (quest.MissionType == 2) // Убить врагов
                    {
                        var progress = quest.Clone();
                        progress.Progress = kills;
                        quest.CurrentGoal += kills;
                        if (quest.CurrentGoal >= quest.QuestGoal)
                        {
                            completed.Add(quest);
                        }
                        progressive.Add(progress);
                    }
                    else if (quest.MissionType == 3) // Нанести урон
                    {
                        var progress = quest.Clone();
                        progress.Progress = damage;
                        quest.CurrentGoal += damage;
                        if (quest.CurrentGoal >= quest.QuestGoal)
                        {
                            completed.Add(quest);
                        }
                        progressive.Add(progress);
                    }
                    else if (quest.MissionType == 4) // Лечение (или другой тип, связанный с бойцом)
                    {
                        var progress = quest.Clone();
                        progress.Progress = heals;
                        if (progress.CurrentGoal + progress.Progress > progress.QuestGoal)
                        {
                            progress.Progress = progress.QuestGoal - progress.CurrentGoal;
                        }
                        quest.CurrentGoal += heals;
                        if (quest.CurrentGoal >= quest.QuestGoal)
                        {
                            completed.Add(quest);
                        }
                        progressive.Add(progress);
                    }
                    else if (quest.MissionType == 5 && winCount > 0) // Победы
                    {
                        var progress = quest.Clone();
                        progress.Progress = winCount;
                        quest.CurrentGoal += winCount;
                        if (quest.CurrentGoal >= quest.QuestGoal)
                        {
                            completed.Add(quest);
                        }
                        progressive.Add(progress);
                    }
                    else if (quest.MissionType == 6 && gameModeVariation == 7) // Big Game special
                    {
                        var progress = quest.Clone();
                        if (isBigGameBoss)
                        {
                            progress.Progress = bossDamage;
                            quest.CurrentGoal += bossDamage;
                        }
                        else
                        {
                            progress.Progress = damage;
                            quest.CurrentGoal += damage;
                        }
                        if (quest.CurrentGoal >= quest.QuestGoal)
                        {
                            completed.Add(quest);
                        }
                        progressive.Add(progress);
                    }
                }
            }

            foreach (Quest quest in completed)
            {
                QuestList.Remove(quest);
                home.TokenReward += quest.Reward;
                home.BrawlPassTokens += quest.Reward;
            }

            return progressive;
        }

        public void Encode(ChecksumEncoder encoder)
        {
            encoder.WriteVInt(QuestList.Count);
            foreach (Quest quest in QuestList.ToArray())
            {
                quest.EncodeHome(encoder);
            }
        }
    }
}
