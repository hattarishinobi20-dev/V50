﻿using Supercell.Laser.Logic.Home;
using System;
using System.Collections.Generic;
using System.Linq;
using Supercell.Laser.Titan.DataStream;
using Newtonsoft.Json;
using System.Reflection.Metadata.Ecma335;
using System.Data;
using Supercell.Laser.Logic.Data;
using Supercell.Laser.Logic.Home.Gatcha;
using Supercell.Laser.Logic.Message.Home;
using System.Net.NetworkInformation;
using System.Runtime.CompilerServices;
using System.Reflection;
using Supercell.Laser.Logic.Home.Items;
using Supercell.Laser.Logic.Helper;

namespace BattleLogEntry;

public class BattleLogStructure
{
    public DateTime BattleLogCreateTimer;
    public int BattleLogType;
    public int TrophiesResult;
    public int BattleTime;
    public bool IsFriendly;
    public int MapId;
    public int Result;

    public int Index;
    public void Encode(ByteStream Stream)
    {
        Stream.WriteVInt(0);
        Stream.WriteVInt(0); // log create timer
        Stream.WriteVInt((int)BattleLogCreateTimer.Second);    // Time When Battle Log Entry Was Created
        Stream.WriteVInt(BattleLogType);    // Battle Log Type (1 = Normal, 2 = Crash, 3 = Survived for <time>,4 = BigGame, 7 = Duels); 
        Stream.WriteVInt(TrophiesResult);    // Trophies Result
        Stream.WriteVInt(BattleTime);  // Battle Time
        Stream.WriteBoolean(IsFriendly);   // Friendly
        Stream.WriteDataReference(MapId); // Map SCID
        Stream.WriteVInt(Result); // Victory/Defeat/Draw
        Stream.WriteVInt(0);
        Stream.WriteVInt(0);

        Stream.WriteInt(1);
        Stream.WriteInt(0);

        Stream.WriteVInt(1);
        Stream.WriteBoolean(true);
        Stream.WriteVInt(0);
        Stream.WriteVInt(-1); // Players Array

        for (int sex = 0; sex < 10; sex++)
        {
            Stream.WriteVInt(sex + 1);  // index
            Stream.WriteLong(0);  // accountID
            Stream.WriteVInt(0);
            Stream.WriteBoolean(false);  // star player
            ByteStreamHelper.WriteDataReference(Stream, 16000000 + 0); // BrawlerID
            Stream.WriteVInt(1);  // Trophies
            Stream.WriteVInt(1);  // lvl
            Stream.WriteVInt(1);  // idk
            Stream.WriteString("шлюх");
            Stream.WriteVInt(5000);
            Stream.WriteVInt(0);
            Stream.WriteVInt(0);
            Stream.WriteVInt(-1);



        }


        Stream.WriteVInt(0);
        Stream.WriteBoolean(false);
        Stream.WriteVInt(0);
        Stream.WriteBoolean(false);
        Stream.WriteVInt(0);
        Stream.WriteBoolean(false);
        Stream.WriteBoolean(false);
        Stream.WriteVInt(0);
        Stream.WriteVInt(Index);
        Stream.WriteBoolean(false);
        Stream.WriteVInt(0); // Challenge Variation
        Stream.WriteVInt(0);
        Stream.WriteVInt(0);
        Stream.WriteVInt(0);
        Stream.WriteVInt(0);
    }
}

public class BattleLog
{
    [JsonProperty("battlelogs_list")]
    public List<BattleLogStructure> BattleLogsList;

    public BattleLog()
    {
        BattleLogsList = new List<BattleLogStructure>();
    }

    public void Add(BattleLogStructure log, int BattleLogType,int TrophiesResult, int BattleTime, bool IsFriendly, int MapId, int Result)
    {
        log.Index = GetIndex();
        log.BattleLogCreateTimer = DateTime.UtcNow;
        log.BattleLogType = BattleLogType;
        log.TrophiesResult = TrophiesResult;
        log.BattleTime = BattleTime;
        log.IsFriendly = IsFriendly;
        log.MapId = MapId;
        log.Result = Result;
        BattleLogsList.Add(log);
    }

    public int GetIndex()
    {
        return BattleLogsList.Count;
    }

    public void Encode(ByteStream stream)
    {
        if (BattleLogsList.Count < 26) stream.WriteVInt(BattleLogsList.Count);
        else stream.WriteVInt(25);
            foreach (BattleLogStructure log in BattleLogsList)
            {
                log.Encode(stream);
            }
        Console.WriteLine(BattleLogsList.Count);

    }
}
