﻿namespace Supercell.Laser.Logic.Home.Items
{
    class ReleaseEntry
    {
        public static int[] LogicReleaaseEntry = new int[]
        {
                74, (int)(DateTime.Parse("2025-10-19 14:30:00") - DateTime.Now).TotalSeconds,
                75, (int)(DateTime.Parse("2025-10-19 14:30:00") - DateTime.Now).TotalSeconds,
                76, (int)(DateTime.Parse("2025-11-19 14:30:00") - DateTime.Now).TotalSeconds,
                77, (int)(DateTime.Parse("2025-11-19 14:30:00") - DateTime.Now).TotalSeconds,
        };

    }
}
