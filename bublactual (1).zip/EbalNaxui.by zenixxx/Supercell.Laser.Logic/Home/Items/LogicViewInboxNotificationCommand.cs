namespace Supercell.Laser.Logic.Command.Home
{
    using Supercell.Laser.Logic.Data;
    using Supercell.Laser.Logic.Home;
    using Supercell.Laser.Logic.Home.Items;
    using Supercell.Laser.Logic.Home.Gatcha;
    using Supercell.Laser.Logic.Message.Home;
    using Supercell.Laser.Titan.DataStream;

    public class LogicViewInboxNotificationCommand : Command
    {
        public int NotificationIndex;
        public override void Decode(ByteStream stream)
        {
            base.Decode(stream);
            NotificationIndex = stream.ReadVInt();
        }

        public override int Execute(HomeMode homeMode)
        {
            if (NotificationIndex < 0) return 1;
            if (NotificationIndex > homeMode.Home.NotificationFactory.GetIndex()) return 2;
            if (homeMode.Home.NotificationFactory.NotificationList[NotificationIndex].IsViewed) return 3;
            if (homeMode.Home.NotificationFactory.NotificationList[NotificationIndex].Id == 79)
            {
                foreach (int a in homeMode.Home.NotificationFactory.NotificationList[NotificationIndex].StarpointsAwarded)
                {
                    homeMode.Avatar.Blings += a;
                }
            }
            if (homeMode.Home.NotificationFactory.NotificationList[NotificationIndex].Id == 89)
            {
                LogicGiveDeliveryItemsCommand delivery = new LogicGiveDeliveryItemsCommand();
                DeliveryUnit unit = new DeliveryUnit(100);
                GatchaDrop reward = new GatchaDrop(8);
                reward.Count = homeMode.Home.NotificationFactory.NotificationList[NotificationIndex].DonationCount;
                unit.AddDrop(reward);
                delivery.DeliveryUnits.Add(unit);
                delivery.Execute(homeMode);

                AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                message.Command = delivery;
                homeMode.GameListener.SendMessage(message);
            }
            if (homeMode.Home.NotificationFactory.NotificationList[NotificationIndex].Id == 93)
            {
                LogicGiveDeliveryItemsCommand delivery = new LogicGiveDeliveryItemsCommand();
                DeliveryUnit unit = new DeliveryUnit(100);
                GatchaDrop reward = new GatchaDrop(1);
                reward.Count = homeMode.Home.NotificationFactory.NotificationList[NotificationIndex].BrawlerLVL;
                reward.DataGlobalId = homeMode.Home.NotificationFactory.NotificationList[NotificationIndex].BrawlerID;
                unit.AddDrop(reward);
                delivery.DeliveryUnits.Add(unit);
                delivery.Execute(homeMode);

                AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                message.Command = delivery;
                homeMode.GameListener.SendMessage(message);
            }
            if (homeMode.Home.NotificationFactory.NotificationList[NotificationIndex].Id == 94)
            {
                LogicGiveDeliveryItemsCommand delivery = new LogicGiveDeliveryItemsCommand();
                DeliveryUnit unit = new DeliveryUnit(100);

                GatchaDrop reward1 = new GatchaDrop(1);
                SkinData skinData = DataTables.Get(DataType.Skin).GetDataByGlobalId<SkinData>(homeMode.Home.NotificationFactory.NotificationList[NotificationIndex].SkinID);
                SkinConfData sk = DataTables.Get(DataType.SkinConf).GetData<SkinConfData>(skinData.Conf);
                CharacterData c = DataTables.Get(DataType.Character).GetData<CharacterData>(sk.Character);
                if (homeMode.Avatar.HasHero(c.GetGlobalId()) == false) { reward1.Count = 0; reward1.DataGlobalId = c.GetGlobalId(); unit.AddDrop(reward1); }

                GatchaDrop reward = new GatchaDrop(9);
                reward.Count = 0;
                reward.SkinGlobalId = homeMode.Home.NotificationFactory.NotificationList[NotificationIndex].SkinID;
                unit.AddDrop(reward);

                delivery.DeliveryUnits.Add(unit);
                delivery.Execute(homeMode);

                AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                message.Command = delivery;
                homeMode.GameListener.SendMessage(message);
            }
            homeMode.Home.NotificationFactory.NotificationList[NotificationIndex].IsViewed = true;
            return 0;
        }

        public override int GetCommandType()
        {
            return 528;
        }
    }
}
