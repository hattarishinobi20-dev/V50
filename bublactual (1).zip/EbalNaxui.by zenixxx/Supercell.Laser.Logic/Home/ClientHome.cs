using System.Linq;

namespace Supercell.Laser.Logic.Home
{
    using System;
    using System.Security.Cryptography;
    using Newtonsoft.Json;
    using System.Numerics;
    using Supercell.Laser.Logic.Command.Home;
    using Supercell.Laser.Logic.Data;
    using Supercell.Laser.Logic.Data.Helper;
    using Supercell.Laser.Logic.Helper;
    using Supercell.Laser.Logic.Home.Gatcha;
    using Supercell.Laser.Logic.Home.Items;
    using Supercell.Laser.Logic.Home.Quest;
    using Supercell.Laser.Logic.Home.Structures;
    using Supercell.Laser.Logic.Message.Account.Auth;
    using Supercell.Laser.Logic.Message.Home;
    using Supercell.Laser.Titan.DataStream;
    using Supercell.Laser.Titan.Debug;
    using System.Text;
    using Supercell.Laser.Logic.Time;
    using Supercell.Laser.Logic.Command;
    using System.Xml.Linq;
    using Supercell.Laser.Logic.Notification;
    using Supercell.Laser.Logic.Avatar;

    [JsonObject(MemberSerialization.OptIn)]
    public partial class ClientHome
    {
        public const int DAILYOFFERS_COUNT = 6;

        public static readonly int[] GoldPacksPrice = new int[]
        {
            20, 50, 140, 280
        };

        public static readonly int[] GoldPacksAmount = new int[]
        {
            150, 400, 1200, 2600
        };

        [JsonProperty] public long HomeId;
        [JsonProperty] public int ThumbnailId;
        [JsonProperty] public int NameColorId;
        [JsonProperty] public int[] CharacterIds;
        [JsonProperty] public int FavouriteCharacter;
        public int CharacterId => CharacterIds[0];
        [JsonProperty] public int TrophiesReward;
        [JsonProperty] public int TokenReward;
        [JsonProperty] public int StarTokenReward;
        [JsonProperty] public BigInteger BrawlPassProgress;
        [JsonProperty] public BigInteger PremiumPassProgress;
        [JsonProperty] public int[] UnlockStarRoad;
        [JsonProperty] public BigInteger BrawlPassPlusProgress;
        [JsonProperty] public int BrawlPassTokens;
        [JsonProperty] public bool HasPremiumPass = false;
        [JsonProperty] public bool HasPremiumPassPlus = false;
        [JsonProperty] public List<int> UnlockedEmotes;
        [JsonProperty] public List<int> UnlockedThumbnails;
        [JsonProperty] public List<int> UnlockedTituls;
        [JsonProperty] public NotificationFactory NotificationFactory;
        [JsonProperty] public List<int> UnlockedSkins;
        [JsonProperty] public int TrophyRoadProgress;
        [JsonProperty] public int EventId;
        [JsonProperty] public List<PlayerMap> PlayerMaps = new List<PlayerMap>();
        [JsonProperty] public BattleCard DefaultBattleCard;
        [JsonProperty] public int PreferredThemeId;
        [JsonProperty] public int RewardType;
        [JsonProperty] public int RewardCount;
        [JsonProperty] public int StarrDropRarity;
        [JsonProperty] public int TokenDoublers;
        [JsonProperty] public List<string> PaidOffers;
        [JsonProperty] public List<string> CreatorCodes;
        [JsonProperty] public string CreatorCode;

        // ignore SerializeObject lore
        [JsonIgnore] public StarrDrop.StarrDrop StarrDrop;
        [JsonIgnore] public EventData[] Events;
        [JsonIgnore] public List<OfferBundle> OfferBundles;
        [JsonIgnore] public Quests Quests;
        [JsonIgnore] public BattleLogEntry.BattleLog BattleLogs;
        [JsonProperty] public Dictionary<int, int> PlayerSelectedEmotes = new Dictionary<int, int>(); // почему тут проперти
        public PlayerThumbnailData Thumbnail => DataTables.Get(DataType.PlayerThumbnail).GetDataByGlobalId<PlayerThumbnailData>(ThumbnailId);
        public NameColorData NameColor => DataTables.Get(DataType.NameColor).GetDataByGlobalId<NameColorData>(NameColorId);

        public HomeMode HomeMode;

        [JsonProperty] public DateTime LastVisitHomeTime;
        [JsonProperty] public List<string> OffersClaimed;

        [JsonProperty] public bool IsVIP { get; set; }
        [JsonProperty] public DateTime VIPExpire { get; set; }

        public ClientHome()
        {
            NotificationFactory = new NotificationFactory();
            ThumbnailId = GlobalId.CreateGlobalId(28, 0);
            NameColorId = GlobalId.CreateGlobalId(43, 0);
            CharacterIds = new int[] { GlobalId.CreateGlobalId(16, 0), GlobalId.CreateGlobalId(16, 1), GlobalId.CreateGlobalId(16, 2) };
            FavouriteCharacter = GlobalId.CreateGlobalId(16, 0);
            PlayerSelectedEmotes.Add(1, 28);
            PlayerSelectedEmotes.Add(2, 28);
            PlayerSelectedEmotes.Add(3, 28);
            PlayerSelectedEmotes.Add(4, 28);
            PlayerSelectedEmotes.Add(5, 85 - 3);

            OfferBundles = new List<OfferBundle>();
            UnlockedSkins = new List<int>();
            PaidOffers = new List<string>();
            CreatorCodes = new List<string>();

            UnlockedEmotes = new List<int>();
            UnlockedTituls = new List<int>();
            UnlockedThumbnails = new List<int>();
            UnlockStarRoad = new int[] { 16000008, 16000010, 16000007, 16000013, 16000034, 16000003, 16000006, 16000014, 16000030, 16000001, 16000009, 16000027, 16000029, 16000002, 16000022, 16000025, 16000020, 16000045, 16000011, 16000017, 16000021, 16000024, 16000018, 16000016, 16000032, 16000023, 16000012, 16000005, 16000019, 16000050, 16000042, 16000004, 16000043, 16000028, 16000015, 16000026, 16000061, 16000031, 16000047, 16000048, 16000040, 16000052, 16000036, 16000063,16000058, 16000037, 16000069, 16000064, 16000038, 16000035, 16000067, 16000070, 16000039, 16000071, 16000046, 16000041, 16000051, 16000044, 16000053, 16000049, 16000060, 16000054, 16000065, 16000056, 16000068, 16000057, 16000059, 16000062, 16000066 };
            LastVisitHomeTime = DateTime.UnixEpoch;
            OffersClaimed = new List<string>();
            TrophyRoadProgress = 1;
            TokenDoublers = 0;
            BrawlPassProgress = 1;
            PremiumPassProgress = 1;
            EventId = 1;
            UnlockedEmotes = new List<int>();
            DefaultBattleCard = new BattleCard();
            StarrDrop = new StarrDrop.StarrDrop(HomeMode);
            PreferredThemeId = -1;
            BattleLogs = new BattleLogEntry.BattleLog();
        }

        public void HomeVisited()
        {
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
79, 999, 0, ShopItem.Gems,
0, 0, 0,
"hell", "ДОБРО ПОЖАЛОВАТЬ!", "offer_bgr_mecha_edgar",
0, 0, false,
false, false, 0,
0, 69, 11, 70, 0,1,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
2800, 999, 0, ShopItem.Bling,
0, 0, 0,
"hell1", "ДОБРО ПОЖАЛОВАТЬ!", "offer_bgr_university",
0, 0, false,
false, false, 0,
0, 69, 11, 0, 0,2,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
3000, 999, 0, ShopItem.Coin,
0, 0, 0,
"hell2", "ДОБРО ПОЖАЛОВАТЬ!", "offer_bgr_mf2023",
0, 0, false,
false, false, 0,
0, 69, 11, 0, 0,3,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
3000, 999, 0, ShopItem.PowerPoint,
0, 0, 0,
"hell3", "ДОБРО ПОЖАЛОВАТЬ!", "offer_bgr_wasteland",
0, 0, false,
false, false, 0,
0, 69, 11, 0, 0,4,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
3, 4, 4, ShopItem.RarityStarrDrop,
0, 0, 0,
"hell4", "ДОБРО ПОЖАЛОВАТЬ!\n3 МЕГАЯЩИКА", "offer_bgr_legendary_dark",
0, 0, false,
false, false, 0,
0, 69, 11, 0, 0,5,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
1, 999, 147, ShopItem.OverchargeStarrDrop,
0, 0, 0,
"hell5", "ДОБРО ПОЖАЛОВАТЬ!\nТитул: Король BublBrawl", "offer_bgr_wf2023",
0, 0, false,
false, false, 0,
0, 69, 11, 0, 0,6,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
379, 999, 0, ShopItem.RecruitToken,
0, 0, 0,
"hell6", "ДОБРО ПОЖАЛОВАТЬ!", "offer_bgr_circus",
0, 0, false,
false, false, 0,
0, 69, 11, 0, 0,7,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
1, 999, 723, ShopItem.Skin,
0, 0, 0,
"hell7", "ДОБРО ПОЖАЛОВАТЬ!", "offer_bgr_retro2023",
0, 0, false,
false, false, 0,
0, 69, 11, 70, 0,8,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
1, 52, 0, ShopItem.GuaranteedHero,
0, 0, 0,
"hell9", "ДОБРО ПОЖАЛОВАТЬ!", "offer_bgr_brawloween2023",
0, 0, false,
false, false, 0,
0, 69, 11, 70, 0,9,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
1, 76, 0, ShopItem.GuaranteedHero,
999, 2999, 1000,
"offer_kitone", "РАННИЙ ДОСТУП | 299 РУБ", "offer_bgr_claship",
0, 0, false,
false, false, 0,
0, 69, 9, 70, 0,1,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
180, 999, 0, ShopItem.Gems,
0, 0, 0,
"kitone2", "РАННИЙ ДОСТУП", "offer_bgr_punk",
0, 0, false,
false, false, 0,
0, 69, 9, 0, 0,2,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
5000, 999, 0, ShopItem.Bling,
0, 0, 0,
"kitone3", "РАННИЙ ДОСТУП", "offer_bgr_blue",
0, 0, false,
false, false, 0,
0, 69, 9, 0, 0,3,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
1, 999, 756, ShopItem.Skin,
0, 0, 0,
"kitne4", "РАННИЙ ДОСТУП", "offer_bgr_bt21",
0, 0, false,
false, false, 0,
0, 69, 9, 70, 0,4,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
1, 999, 765, ShopItem.Skin,
0, 0, 0,
"kitone5", "РАННИЙ ДОСТУП", "offer_bgr_masks",
0, 0, false,
false, false, 0,
0, 69, 9, 70, 0,5,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
0, 999, 766, ShopItem.Skin,
0, 0, 0,
"kitone6", "РАННИЙ ДОСТУП", "offer_bgr_hub",
0, 0, false,
false, false, 0,
0, 69, 9, 70, 0,6,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
1, 77, 0, ShopItem.GuaranteedHero,
0, 0, 0,
"kitone7", "РАННИЙ ДОСТУП", "offer_bgr_hindu",
0, 0, false,
false, false, 0,
0, 69, 9, 70, 0,7,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
3500, 999, 0, ShopItem.PowerPoint,
0, 0, 0,
"kitone8", "РАННИЙ ДОСТУП", "offer_bgr_make",
0, 0, false,
false, false, 0,
0, 69, 9, 0, 0,8,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
1500, 999, 0, ShopItem.RecruitToken,
0, 0, 0,
"kitone9", "РАННИЙ ДОСТУП", "offer_bgr_mecha",
0, 0, false,
false, false, 0,
0, 69, 9, 0, 0,9,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
10000, 999, 0, ShopItem.Coin,
0, 0, 0,
"kitone10", "РАННИЙ ДОСТУП", "offer_bgr_boxes",
0, 0, false,
false, false, 0,
0, 69, 9, 0, 0,10,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
0, 4, 160, ShopItem.OverchargeStarrDrop,
0, 0, 0,
"kitone11", "РАННИЙ ДОСТУП\nНагибатор", "offer_bgr_xmas",
0, 0, false,
false, false, 0,
0, 69, 9, 0, 0,11,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
0, 999, 740, ShopItem.Skin,
0, 0, 0,
"kitone12", "РАННИЙ ДОСТУП", "offer_bgr_lny",
0, 0, false,
false, false, 0,
0, 69, 9, 70, 0,12,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
10, 4, 4, ShopItem.RarityStarrDrop,
0, 0, 0,
"kitone13", "РАННИЙ ДОСТУП\n10 MegaBox", "offer_bgr_mf",
0, 0, false,
false, false, 0,
0, 69, 9, 0, 0,13,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
1, 74, 0, ShopItem.GuaranteedHero,
999, 2999, 1000,
"offer_bublpassone", "BublPass Pro | 249 РУБ", "offer_bgr_stuntshow",
0, 0, false,
false, false, 0,
0, 69, 10, 70, 0,1,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
60, 999, 0, ShopItem.Gems,
0, 0, 0,
"bublpassone2", "BublPass Pro", "offer_bgr_villains",
0, 0, false,
false, false, 0,
0, 69, 10, 0, 0,2,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
3000, 999, 0, ShopItem.Bling,
0, 0, 0,
"bublpassone3", "BublPass Pro", "offer_bgr_deepsea",
0, 0, false,
false, false, 0,
0, 69, 10, 0, 0,3,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
120, 999, 0, ShopItem.Gems,
0, 0, 0,
"bublpassone4", "BublPass Pro", "offer_bgr_moonfestival22",
0, 0, false,
false, false, 0,
0, 69, 10, 0, 0,4,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
1, 999, 728, ShopItem.Skin,
0, 0, 0,
"bublpassone5", "BublPass Pro", "offer_bgr_robotfactory",
0, 0, false,
false, false, 0,
0, 69, 10, 0, 0,5,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
0, 4, 189, ShopItem.OverchargeStarrDrop,
0, 0, 0,
"bublpassone6", "BublPass Pro\nMinecraft", "offer_bgr_brawloween22",
0, 0, false,
false, false, 0,
0, 69, 10, 0, 0,6,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
1, 75, 0, ShopItem.GuaranteedHero,
0, 0, 0,
"bublpassone7", "BublPass Pro", "offer_bgr_action",
0, 0, false,
false, false, 0,
0, 69, 10, 0, 0,7,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
1, 999, 0, ShopItem.Gems,
0, 0, 0,
"bublpassone8", "BublPass Pro", "offer_bgr_lastbox",
0, 0, false,
false, false, 0,
0, 69, 10, 0, 0,8,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
2399, 999, 0, ShopItem.Bling,
0, 0, 0,
"bublpassone9", "BublPass Pro", "offer_bgr_4thanniversary",
0, 0, false,
false, false, 0,
0, 69, 10, 0, 0,9,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
1, 4, 1360-4, ShopItem.Emote,
0, 0, 0,
"bublpassone10", "BublPass Pro", "offer_bgr_lny23red",
0, 0, false,
false, false, 0,
0, 69, 10, 0, 0,10,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
1, 999, 746, ShopItem.Skin,
0, 0, 0,
"bublpassone11", "BublPass Pro", "offer_bgr_lny23green",
0, 0, false,
false, false, 0,
0, 69, 10, 0, 0,11,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
0, 4, 193, ShopItem.OverchargeStarrDrop,
0, 0, 0,
"bublpassone12", "BublPass Pro\nПсихология", "offer_bgr_candyland",
0, 0, false,
false, false, 0,
0, 69, 10, 0, 0,12,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
0, 999, 134, ShopItem.Skin,
0, 0, 0,
"bublpassone13", "BublPass Pro", "offer_bgr_darkmas",
0, 0, false,
false, false, 0,
0, 69, 10, 0, 0,13,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
10, 4, 4, ShopItem.RarityStarrDrop,
0, 0, 0,
"bublpassone14", "BublPass Pro\n10 MegaBox", "offer_bgr_brawlentines23",
0, 0, false,
false, false, 0,
0, 69, 10, 0, 0,14,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
10000, 999, 0, ShopItem.Coin,
0, 0, 0,
"bublpassone15", "BublPass Pro", "offer_bgr_ramadan2023",
0, 0, false,
false, false, 0,
0, 69, 10, 0, 0,15,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
1500, 999, 0, ShopItem.RecruitToken,
0, 0, 0,
"bublpassone16", "BublPass Pro", "offer_bgr_easter2023",
0, 0, false,
false, false, 0,
0, 69, 10, 0, 0,16,false, DateTime.MinValue
);
            GenerateOffer3(
       DateTime.UtcNow,
            DateTime.UtcNow.AddDays(60),
3500, 999, 0, ShopItem.PowerPoint,
0, 0, 0,
"bublpassone17", "BublPass Pro", "offer_bgr_action",
0, 0, false,
false, false, 0,
0, 69, 10, 0, 0,17,false, DateTime.MinValue
);
            GenerateOffer2(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2028, 5, 10, 11, 0, 0),
100, 999, 0, ShopItem.RecruitToken,
0, 0, 0,
"Offerdayl", "Daylu", "offer_bgr_deepsea",
0, 1, false,
false, false, 0,
0, 0, 0, 0, 0, 3
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 9, 15, 15, 28, 0),
1, 999, 654, ShopItem.Emote,
999999, 0, 0,
"bogaj", "Богачи", "offer_bgr_villains",
0, 0, false,
false, false, 1,
2, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 9, 15, 15, 28, 0),
3, 999, 0, ShopItem.RarityStarrDrop,
0, 0, 0,
"sgsgsdsdg", "1.5K подписчиков", "offer_bgr_villains",
0, 0, false,
false, false, 1,
2, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 9, 15, 15, 28, 0),
49, 999, 0, ShopItem.Gems,
0, 0, 0,
"sgsgs2dsdg", "1.5K подписчиков", "offer_bgr_villains",
0, 0, false,
false, false, 1,
2, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2025, 9, 30, 15, 28, 0),
1, 999, 603, ShopItem.Skin,
69, 0, 0,
"creditoffer6111", "SKIN", "offer_bgr_villains",
0, 0, false,
false, false, 1,
2, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2025, 9, 30, 15, 28, 0),
1, 999, 597, ShopItem.Skin,
119, 0, 0,
"creditoffer61111", "SKIN", "offer_bgr_villains",
0, 0, false,
false, false, 1,
2, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2025, 9, 30, 15, 28, 0),
1, 999, 605, ShopItem.Skin,
119, 0, 0,
"creditof1fer61111", "SKIN", "offer_bgr_villains",
0, 0, false,
false, false, 1,
2, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 9, 15, 15, 28, 0),
3000, 999, 0, ShopItem.RecruitToken,
372, 744, 0,
"creditoffer6", "OFFER", "offer_bgr_villains",
0, 0, false,
false, false, 1,
2, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 9, 11, 12, 28, 0),
3000, 999, 0, ShopItem.RecruitToken,
596, 1192, 0,
"creditoffer7", "OFFER", "offer_bgr_deepsea",
0, 0, false,
false, false, 1,
2, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 8, 15, 15, 28, 0),
4000, 999, 0, ShopItem.RecruitToken,
744, 1488, 0,
"creditoffer8", "OFFER", "offer_bgr_moonfestival22",
0, 0, false,
false, false, 1,
2, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 8, 15, 15, 28, 0),
5000, 999, 0, ShopItem.RecruitToken,
892, 1784, 0,
"creditoffer9", "OFFER", "offer_bgr_robotfactory",
0, 0, false,
false, false, 1,
2, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 8, 15, 15, 28, 0),
10000, 999, 0, ShopItem.RecruitToken,
1800, 3600, 0,
"creditoffer10", "OFFER", "offer_bgr_brawloween22",
0, 0, false,
false, false, 1,
2, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 8, 15, 15, 28, 0),
0, 4, 112, ShopItem.OverchargeStarrDrop,
0, 80, 0,
"freetitleoda", "Титул\nВики шоу", "offer_bgr_generic",
0, 0, false,
false, false, 1,
2, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 8, 20, 11, 0, 0),
0, 4, 101, ShopItem.OverchargeStarrDrop,
400, 1200, 0,
"buytitle66", "Титул\nГубка боб", "offer_bgr_special",
0, 0, false,
false, false, 1,
3, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 8, 20, 11, 0, 0),
0, 4, 108, ShopItem.OverchargeStarrDrop,
400, 1200, 0,
"buytitle661", "Титул\nГектор", "offer_bgr_finals",
0, 0, false,
false, false, 1,
3, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 8, 20, 11, 0, 0),
0, 4, 116, ShopItem.OverchargeStarrDrop,
400, 1200, 0,
"buytitle662", "Титул\nГей", "offer_bgr_chromatic",
0, 0, false,
false, false, 1,
3, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 8, 20, 11, 0, 0),
0, 4, 118, ShopItem.OverchargeStarrDrop,
400, 1200, 0,
"buytitle663", "Титул\nБалабол", "offer_bgr_archive",
0, 0, false,
false, false, 1,
3, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 8, 20, 11, 0, 0),
0, 4, 124, ShopItem.OverchargeStarrDrop,
400, 1200, 0,
"buytitle664", "Титул\nЗадрот", "offer_bgr_random",
0, 0, false,
false, false, 1,
3, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 8, 20, 11, 0, 0),
0, 4, 125, ShopItem.OverchargeStarrDrop,
400, 1200, 0,
"buytitle665", "Титул\nВип Хуйня", "offer_bgr_velocirapids",
0, 0, false,
false, false, 1,
3, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 8, 20, 11, 0, 0),
0, 4, 84, ShopItem.OverchargeStarrDrop,
400, 1200, 0,
"buytitle", "Титул\nОлд", "offer_bgr_onceupon",
0, 0, false,
false, false, 1,
3, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 8, 20, 11, 0, 0),
0, 4, 91, ShopItem.OverchargeStarrDrop,
400, 1200, 0,
"buytitle1", "Титул\nТитан трофеев", "offer_bgr_retrto",
0, 0, false,
false, false, 1,
3, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 8, 20, 11, 0, 0),
0, 4, 92, ShopItem.OverchargeStarrDrop,
400, 1200, 0,
"buytitle2", "Титул\nГерой", "offer_bgr_brawloween",
0, 0, false,
false, false, 1,
3, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 8, 20, 11, 0, 0),
0, 4, 94, ShopItem.OverchargeStarrDrop,
400, 1200, 0,
"buytitle3", "Титул\nBublBrawl", "offer_bgr_brawlywood",
0, 0, false,
false, false, 1,
3, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 8, 20, 11, 0, 0),
0, 4, 94, ShopItem.OverchargeStarrDrop,
400, 1200, 0,
"buytitle4", "Титул\nНа часах нули", "offer_bgr_blackfriday",
0, 0, false,
false, false, 1,
3, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 8, 20, 11, 0, 0),
0, 4, 100, ShopItem.OverchargeStarrDrop,
400, 1200, 0,
"buytitle5", "Титул\nКвадратные штаны", "offer_bgr_singlesday",
0, 0, false,
false, false, 1,
3, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 8, 20, 11, 0, 0),
1, 4, 4, ShopItem.RarityStarrDrop,
35, 80, 0,
"ac1", "OFFER", "offer_bgr_brawlidays",
0, 0, false,
false, false, 0,
2, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 8, 20, 11, 0, 0),
5, 4, 4, ShopItem.RarityStarrDrop,
175, 0, 0,
"ac2", "OFFER\n5 MegaBox", "offer_bgr_biodome",
0, 0, false,
false, false, 0,
3, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 8, 20, 11, 0, 0),
10, 4, 4, ShopItem.RarityStarrDrop,
350, 0, 0,
"ac3", "OFFER\n10 MegaBox", "offer_bgr_easter22",
0, 0, false,
false, false, 0,
3, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 8, 20, 11, 0, 0),
15, 4, 4, ShopItem.RarityStarrDrop,
525, 0, 0,
"ac4", "OFFER\n15 MegaBox", "offer_bgr_esports22",
0, 0, false,
false, false, 0,
3, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 8, 20, 11, 0, 0),
20, 4, 4, ShopItem.RarityStarrDrop,
700, 0, 0,
"ac5", "OFFER\n20 MegaBox", "offer_bgr_ramadan22",
0, 0, false,
false, false, 0,
3, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 8, 20, 11, 0, 0),
25, 4, 4, ShopItem.RarityStarrDrop,
875, 0, 0,
"ac6", "OFFER\n25 MegaBox", "offer_bgr_gw2022",
0, 0, false,
false, false, 0,
3, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2026, 8, 20, 11, 0, 0),
30, 4, 4, ShopItem.RarityStarrDrop,
1000, 0, 0,
"ac7", "OFFER\n30 MegaBox", "offer_bgr_starter",
0, 0, false,
false, false, 0,
3, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2027, 7, 27, 11, 0, 0),
3000, 999, 0, ShopItem.Bling,
90, 799, 0,
"four111", "OFFER", "offer_bgr_retro2023",
0, 0, false,
false, false, 0,
3, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2027, 7, 27, 11, 0, 0),
5000, 999, 0, ShopItem.Bling,
120, 799, 0,
"four1111", "OFFER", "offer_bgr_mrbeast",
0, 0, false,
false, false, 0,
3, 0, 0, 0, 0
);
            GenerateOffer(
new DateTime(2024, 5, 9, 12, 0, 0), new DateTime(2027, 7, 27, 11, 0, 0),
10000, 999, 0, ShopItem.Bling,
240, 799, 0,
"four11111", "OFFER", "offer_bgr_moonfestival22",
0, 0, false,
false, false, 0,
3, 0, 0, 0, 0
);

            RotateShopContent(DateTime.UtcNow, OfferBundles.Count == 0);
            LastVisitHomeTime = DateTime.UtcNow;

            if (Quests == null && TrophyRoadProgress >= 11)
            {
                Quests = new Quests();
                Quests.AddRandomQuests(HomeMode.Avatar.Heroes, 8);
            }
            else if (Quests != null)
            {
                if (Quests.QuestList.Count < 8) // New quests adds at 07:00 AM UTC
                {
                    Quests.AddRandomQuests(HomeMode.Avatar.Heroes, 8 - Quests.QuestList.Count);
                }
            }
        }

        public void Tick()
        {
            LastVisitHomeTime = DateTime.UtcNow;
            TokenReward = 0;
            TrophiesReward = 0;
            StarTokenReward = 0;
        }

        public void PurchaseOfferWithCatalog(int DataGlobalId, int Currency)
        {
            LogicGiveDeliveryItemsCommand command = new LogicGiveDeliveryItemsCommand();
            if (DataGlobalId > 29000000 && DataGlobalId < 30000000)
            {
                SkinData skinData = DataTables.Get(DataType.Skin).GetDataWithId<SkinData>(DataGlobalId);
                int blingsNeeded = skinData.PriceBling;
                int gemsNeeded = skinData.PriceGems;

                int playerBlings = HomeMode.Avatar.Blings;
                int playerGems = HomeMode.Avatar.Diamonds;

                bool enoughBlings = playerBlings >= blingsNeeded;
                bool enoughGems = playerGems >= gemsNeeded;

                // Комбинированная оплата: если не хватает блингов, остаток списывается гемами
                if (Currency == 2 || Currency == 3) // Покупка за блинги с возможностью докупить за гемы
                {
                    if (playerBlings >= blingsNeeded)
                    {
                        if (!HomeMode.Avatar.UseBlings(blingsNeeded)) 
                        {
                            Console.WriteLine($"Failed to use blings for skin purchase. PlayerId: {HomeId}, SkinId: {DataGlobalId}");
                            return;
                        }
                    }
                    else
                    {
                        int blingsUsed = playerBlings;
                        int blingsShortage = blingsNeeded - blingsUsed;
                        int gemsForShortage = (int)Math.Ceiling((double)blingsShortage / (blingsNeeded / (double)gemsNeeded));

                        if (blingsUsed > 0)
                        {
                            if (!HomeMode.Avatar.UseBlings(blingsUsed)) 
                            {
                                Console.WriteLine($"Failed to use partial blings for skin purchase. PlayerId: {HomeId}, SkinId: {DataGlobalId}");
                                return;
                            }
                        }
                        if (playerGems < gemsForShortage) 
                        {
                            Console.WriteLine($"Not enough gems to cover shortage. PlayerId: {HomeId}, SkinId: {DataGlobalId}, Needed: {gemsForShortage}, Available: {playerGems}");
                            return;
                        }
                        if (!HomeMode.Avatar.UseDiamonds(gemsForShortage)) 
                        {
                            Console.WriteLine($"Failed to use gems for skin purchase. PlayerId: {HomeId}, SkinId: {DataGlobalId}");
                            return;
                        }
                    }
                }
                else if (Currency == 1) // Покупка только за гемы
                {
                    if (!HomeMode.Avatar.UseDiamonds(gemsNeeded)) 
                    {
                        Console.WriteLine($"Failed to use diamonds for skin purchase. PlayerId: {HomeId}, SkinId: {DataGlobalId}");
                        return;
                    }
                }
                else
                {
                    // Неизвестная валюта — отменяем покупку
                    Console.WriteLine($"Unknown currency type for skin purchase. PlayerId: {HomeId}, Currency: {Currency}");
                    return;
                }

                // Подтверждение успешного списания валют
                Console.WriteLine($"Skin purchase successful. PlayerId: {HomeId}, SkinId: {DataGlobalId}, BlingsUsed: {(Currency == 2 || Currency == 3 ? (enoughBlings ? blingsNeeded : playerBlings) : 0)}, GemsUsed: {(Currency == 1 ? gemsNeeded : (enoughBlings ? 0 : (int)Math.Ceiling((double)(blingsNeeded - playerBlings) / (blingsNeeded / (double)gemsNeeded))))}");

                DeliveryUnit unit = new DeliveryUnit(100);
                GatchaDrop reward = new GatchaDrop(9);
                reward.SkinGlobalId = DataGlobalId;
                reward.Count = 1;
                unit.AddDrop(reward);

                command.DeliveryUnits.Add(unit);
                command.Execute(HomeMode);
                AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                message.Command = command;
                HomeMode.GameListener.SendMessage(message);
                NewCommand(skinData);
            }
            else if (DataGlobalId > 52000000 && DataGlobalId < 53000000)
            {
                EmoteData emoteData = DataTables.Get(DataType.Emote).GetDataWithId<EmoteData>(DataGlobalId);
                int blingsNeeded = emoteData.PriceBling;
                int gemsNeeded = emoteData.PriceGems;

                int playerBlings = HomeMode.Avatar.Blings;
                int playerGems = HomeMode.Avatar.Diamonds;

                bool enoughBlings = playerBlings >= blingsNeeded;
                bool enoughGems = playerGems >= gemsNeeded;

                // Комбинированная оплата: если не хватает блингов, остаток списывается гемами
                if (Currency == 2 || Currency == 3) // Покупка за блинги с возможностью докупить за гемы
                {
                    if (playerBlings >= blingsNeeded)
                    {
                        if (!HomeMode.Avatar.UseBlings(blingsNeeded)) 
                        {
                            Console.WriteLine($"Failed to use blings for pin purchase. PlayerId: {HomeId}, PinId: {DataGlobalId}");
                            return;
                        }
                    }
                    else
                    {
                        int blingsUsed = playerBlings;
                        int blingsShortage = blingsNeeded - blingsUsed;
                        int gemsForShortage = (int)Math.Ceiling((double)blingsShortage / (blingsNeeded / (double)gemsNeeded));

                        if (blingsUsed > 0)
                        {
                            if (!HomeMode.Avatar.UseBlings(blingsUsed)) 
                            {
                                Console.WriteLine($"Failed to use partial blings for pin purchase. PlayerId: {HomeId}, PinId: {DataGlobalId}");
                                return;
                            }
                        }
                        if (playerGems < gemsForShortage) 
                        {
                            Console.WriteLine($"Not enough gems to cover shortage. PlayerId: {HomeId}, PinId: {DataGlobalId}, Needed: {gemsForShortage}, Available: {playerGems}");
                            return;
                        }
                        if (!HomeMode.Avatar.UseDiamonds(gemsForShortage)) 
                        {
                            Console.WriteLine($"Failed to use gems for pin purchase. PlayerId: {HomeId}, PinId: {DataGlobalId}");
                            return;
                        }
                    }
                }
                else if (Currency == 1) // Покупка только за гемы
                {
                    if (!HomeMode.Avatar.UseDiamonds(gemsNeeded)) 
                    {
                        Console.WriteLine($"Failed to use diamonds for pin purchase. PlayerId: {HomeId}, PinId: {DataGlobalId}");
                        return;
                    }
                }
                else
                {
                    // Неизвестная валюта — отменяем покупку
                    Console.WriteLine($"Unknown currency type for pin purchase. PlayerId: {HomeId}, Currency: {Currency}");
                    return;
                }

                // Подтверждение успешного списания валют
                Console.WriteLine($"Pin purchase successful. PlayerId: {HomeId}, PinId: {DataGlobalId}, BlingsUsed: {(Currency == 2 || Currency == 3 ? (enoughBlings ? blingsNeeded : playerBlings) : 0)}, GemsUsed: {(Currency == 1 ? gemsNeeded : (enoughBlings ? 0 : (int)Math.Ceiling((double)(blingsNeeded - playerBlings) / (blingsNeeded / (double)gemsNeeded))))}");

                DeliveryUnit unit = new DeliveryUnit(100);
                GatchaDrop reward = new GatchaDrop(11);
                reward.DataGlobalId = DataGlobalId;
                reward.Count = 1;
                unit.AddDrop(reward);
                command.DeliveryUnits.Add(unit);
                command.Execute(HomeMode);
                AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                message.Command = command;
                HomeMode.GameListener.SendMessage(message);
            }
            else if (DataGlobalId > 28000000 && DataGlobalId < 29000000)
            {
                PlayerThumbnailData skinData = DataTables.Get(DataType.PlayerThumbnail).GetDataWithId<PlayerThumbnailData>(DataGlobalId);
                if (Currency == 1) // Gems
                {
                    if (!HomeMode.Avatar.UseDiamonds(skinData.PriceGems)) return;
                }
                if (Currency == 2) // Blings
                {
                    if (!HomeMode.Avatar.UseBlings(skinData.PriceBling)) return;
                }

                DeliveryUnit unit = new DeliveryUnit(100);
                GatchaDrop reward = new GatchaDrop(11);
                reward.DataGlobalId = DataGlobalId;
                reward.Count = 1;
                unit.AddDrop(reward);



                command.DeliveryUnits.Add(unit);
                command.Execute(HomeMode);
                AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                message.Command = command;
                HomeMode.GameListener.SendMessage(message);

            }

            void NewCommand(SkinData skinData)
            {
                Quests = new Quests();
                Quests.AddRandomQuests(HomeMode.Avatar.Heroes, 8);

                LogicHeroWinQuestsChangedCommand cmd = new LogicHeroWinQuestsChangedCommand();
                cmd.Quests = Quests;

                AvailableServerCommandMessage message12 = new AvailableServerCommandMessage();
                message12.Command = cmd;
                HomeMode.GameListener.SendMessage(message12);

                DeliveryUnit unit = new DeliveryUnit(100);
                GatchaDrop reward = new GatchaDrop(9);
                foreach (EmoteData emoteData in DataTables.Get(DataType.Emote).GetDatas())
                {

                    if (emoteData.Skin == skinData.Name)
                    {
                        GatchaDrop reward1 = new GatchaDrop(11);
                        reward1.DataGlobalId = DataTables.Get(DataType.Emote).GetData<EmoteData>(emoteData.Name).GetGlobalId();
                        reward1.Count = 1;
                        unit.AddDrop(reward1);
                    }

                }
                foreach (PlayerThumbnailData playerThumbnailData in DataTables.Get(DataType.PlayerThumbnail).GetDatas())
                {
                    if (playerThumbnailData.CatalogPreRequirementSkin == skinData.Name)
                    {
                        GatchaDrop reward1 = new GatchaDrop(11);
                        reward1.DataGlobalId = DataTables.Get(DataType.PlayerThumbnail).GetData<PlayerThumbnailData>(playerThumbnailData.Name).GetGlobalId();
                        reward1.Count = 1;
                        unit.AddDrop(reward1);
                    }

                }
                command.DeliveryUnits.Add(unit);
                command.Execute(HomeMode);

                AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                message.Command = command;
                HomeMode.GameListener.SendMessage(message);

            }
        }

        public async void GenerateOffers()
        {

        }

        public async void PurchaseOffer(int index)
        {
            if (index < 0 || index >= OfferBundles.Count) return;

            OfferBundle bundle = OfferBundles[index];
            if (bundle.Purchased) return;

            if (bundle.Currency == 0)
            {
                HomeMode.Avatar.UseDiamonds(bundle.Cost);
            }
            else if (bundle.Currency == 1)
            {
                HomeMode.Avatar.UseGold(bundle.Cost);
            }
            else if (bundle.Currency == 6)
            {
                HomeMode.Avatar.UseBlings(bundle.Cost);
            }

            bundle.Purchased = true;

            if (bundle.Claim == "debug")
            {
                ;
            }
            else
            {
                OffersClaimed.Add(bundle.Claim);
            }

            Random rand = new Random();
            foreach (Offer offer in bundle.Items)
            {
                if (offer.Type == ShopItem.RarityStarrDrop)
                {
                    var command = new LogicGiveDeliveryItemsCommand();
                    for (int i = 0; i < offer.Count; i++)
                    {
                        DeliveryUnit unit = new DeliveryUnit(11); // 11 — MegaBox
                        HomeMode.SimulateGatcha(unit);
                        command.DeliveryUnits.Add(unit);
                    }
                    command.Execute(HomeMode);
                    AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                    message.Command = command;
                    HomeMode.GameListener.SendMessage(message);
                    return;
                }
                else if (offer.Type == ShopItem.Coin)
                {
                    LogicGiveDeliveryItemsCommand command = new LogicGiveDeliveryItemsCommand();
                    DeliveryUnit unit = new DeliveryUnit(100);
                    GatchaDrop reward = new GatchaDrop(7);
                    reward.Count = offer.Count;
                    unit.AddDrop(reward);
                    command.DeliveryUnits.Add(unit);
                    command.Execute(HomeMode);
                    AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                    message.Command = command;
                    HomeMode.GameListener.SendMessage(message);
                }
                else if (offer.Type == ShopItem.Gems)
                {
                    LogicGiveDeliveryItemsCommand command = new LogicGiveDeliveryItemsCommand();
                    DeliveryUnit unit = new DeliveryUnit(100);
                    GatchaDrop reward = new GatchaDrop(8);
                    reward.Count = offer.Count;
                    unit.AddDrop(reward);
                    command.DeliveryUnits.Add(unit);
                    command.Execute(HomeMode);
                    AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                    message.Command = command;
                    HomeMode.GameListener.SendMessage(message);
                }
                else if (offer.Type == ShopItem.Bling)
                {
                    LogicGiveDeliveryItemsCommand command = new LogicGiveDeliveryItemsCommand();
                    DeliveryUnit unit = new DeliveryUnit(100);
                    GatchaDrop reward = new GatchaDrop(25);
                    reward.Count = offer.Count;
                    unit.AddDrop(reward);
                    command.DeliveryUnits.Add(unit);
                    command.Execute(HomeMode);
                    AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                    message.Command = command;
                    HomeMode.GameListener.SendMessage(message);
                }
                else if (offer.Type == ShopItem.PowerPoint)
                {
                    LogicGiveDeliveryItemsCommand command = new LogicGiveDeliveryItemsCommand();
                    DeliveryUnit unit = new DeliveryUnit(100);
                    GatchaDrop reward = new GatchaDrop(24);
                    reward.Count = offer.Count;
                    unit.AddDrop(reward);
                    command.DeliveryUnits.Add(unit);
                    command.Execute(HomeMode);
                    AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                    message.Command = command;
                    HomeMode.GameListener.SendMessage(message);
                }
                else if (offer.Type == ShopItem.GuaranteedHero)
                {
                    LogicGiveDeliveryItemsCommand command = new LogicGiveDeliveryItemsCommand();
                    DeliveryUnit unit = new DeliveryUnit(100);
                    GatchaDrop reward = new GatchaDrop(1);
                    reward.DataGlobalId = offer.ItemDataId;
                    reward.Count = 1;
                    unit.AddDrop(reward);
                    command.DeliveryUnits.Add(unit);
                    command.Execute(HomeMode);
                    AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                    message.Command = command;
                    HomeMode.GameListener.SendMessage(message);
                }
                else if (offer.Type == ShopItem.PlayerThumbnail)
                {
                    LogicGiveDeliveryItemsCommand command = new LogicGiveDeliveryItemsCommand();
                    DeliveryUnit unit = new DeliveryUnit(100);
                    GatchaDrop reward = new GatchaDrop(11);
                    reward.DataGlobalId = GlobalId.CreateGlobalId(28, offer.SkinDataId);
                    reward.Count = offer.Count;
                    unit.AddDrop(reward);
                    command.DeliveryUnits.Add(unit);
                    command.Execute(HomeMode);
                    AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                    message.Command = command;
                    HomeMode.GameListener.SendMessage(message);
                }
                else if (offer.Type == ShopItem.Skin)
                {
                    LogicGiveDeliveryItemsCommand command = new LogicGiveDeliveryItemsCommand();
                    DeliveryUnit unit = new DeliveryUnit(100);
                    GatchaDrop reward = new GatchaDrop(9);
                    reward.SkinGlobalId = GlobalId.CreateGlobalId(29, offer.SkinDataId);
                    reward.Count = 1;
                    unit.AddDrop(reward);
                    command.DeliveryUnits.Add(unit);
                    command.Execute(HomeMode);
                    AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                    message.Command = command;
                    HomeMode.GameListener.SendMessage(message);
                    NewCommand(DataTables.Get(DataType.Skin).GetDataByGlobalId<SkinData>(offer.SkinDataId), command);
                }
                else if (offer.Type == ShopItem.OverchargeStarrDrop)
                {
                    LogicGiveDeliveryItemsCommand command23 = new LogicGiveDeliveryItemsCommand();
                    DeliveryUnit unit23 = new DeliveryUnit(100);
                    GatchaDrop reward23 = new GatchaDrop(11);
                    reward23.DataGlobalId = GlobalId.CreateGlobalId(76, offer.SkinDataId);
                    reward23.Count = 1;
                    unit23.AddDrop(reward23);
                    command23.DeliveryUnits.Add(unit23);
                    command23.Execute(HomeMode);
                    AvailableServerCommandMessage message2 = new AvailableServerCommandMessage();
                    message2.Command = command23;
                    HomeMode.GameListener.SendMessage(message2);
                }
                else if (offer.Type == ShopItem.Emote)
                {
                    LogicGiveDeliveryItemsCommand command = new LogicGiveDeliveryItemsCommand();
                    DeliveryUnit unit = new DeliveryUnit(100);
                    GatchaDrop reward = new GatchaDrop(11);
                    reward.DataGlobalId = GlobalId.CreateGlobalId(52, offer.SkinDataId);
                    reward.Count = 1;
                    unit.AddDrop(reward);
                    command.DeliveryUnits.Add(unit);
                    command.Execute(HomeMode);
                    AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                    message.Command = command;
                    HomeMode.GameListener.SendMessage(message);
                }
                else if (offer.Type == ShopItem.RecruitToken)
                {
                    LogicGiveDeliveryItemsCommand command = new LogicGiveDeliveryItemsCommand();
                    DeliveryUnit unit = new DeliveryUnit(100);
                    GatchaDrop reward = new GatchaDrop(22);
                    reward.Count = offer.Count;
                    unit.AddDrop(reward);
                    command.DeliveryUnits.Add(unit);
                    command.Execute(HomeMode);
                    AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                    message.Command = command;
                    HomeMode.GameListener.SendMessage(message);
                }
                else if (offer.Type == ShopItem.OmegaBox)
                {
                    LogicGiveDeliveryItemsCommand command = new LogicGiveDeliveryItemsCommand();
                    DeliveryUnit unit = new DeliveryUnit(100);
                    GatchaDrop reward = new GatchaDrop(13); // 51 для OmegaBox
                    reward.Count = offer.Count;
                    unit.AddDrop(reward);
                    command.DeliveryUnits.Add(unit);
                    command.Execute(HomeMode);
                    AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                    message.Command = command;
                    HomeMode.GameListener.SendMessage(message);
                }
                else
                {
                    LogicAddNotificationCommand logicAddNotificationCommand = new LogicAddNotificationCommand();
                    logicAddNotificationCommand.Notification = new FloaterTextNotification("ShopItem not initialized\nPlease contact the developers with this problem.");
                    AvailableServerCommandMessage availableServerCommandMessage = new AvailableServerCommandMessage();
                    availableServerCommandMessage.Command = logicAddNotificationCommand;
                    HomeMode.GameListener.SendMessage(availableServerCommandMessage);

                    LogicGiveDeliveryItemsCommand command = new LogicGiveDeliveryItemsCommand();

                    DeliveryUnit unit = new DeliveryUnit(100);

                    command.DeliveryUnits.Add(unit);
                    command.Execute(HomeMode);
                    AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                    message.Command = command;
                    HomeMode.GameListener.SendMessage(message);

                }
            }

            void NewCommand(SkinData skinData, LogicGiveDeliveryItemsCommand command)
            {
                if (skinData == null) return;
                DeliveryUnit unit = new DeliveryUnit(100);
                GatchaDrop reward = new GatchaDrop(9);
                foreach (EmoteData emoteData in DataTables.Get(DataType.Emote).GetDatas())
                {

                    if (emoteData.Skin == skinData.Name)
                    {
                        GatchaDrop reward1 = new GatchaDrop(11);
                        reward1.DataGlobalId = DataTables.Get(DataType.Emote).GetData<EmoteData>(emoteData.Name).GetGlobalId();
                        reward1.Count = 1;
                        unit.AddDrop(reward1);
                    }

                }
                foreach (PlayerThumbnailData playerThumbnailData in DataTables.Get(DataType.PlayerThumbnail).GetDatas())
                {
                    if (playerThumbnailData.CatalogPreRequirementSkin == skinData.Name)
                    {
                        GatchaDrop reward1 = new GatchaDrop(11);
                        reward1.DataGlobalId = DataTables.Get(DataType.PlayerThumbnail).GetData<PlayerThumbnailData>(playerThumbnailData.Name).GetGlobalId();
                        reward1.Count = 1;
                        unit.AddDrop(reward1);
                    }

                }
                command.DeliveryUnits.Add(unit);
                command.Execute(HomeMode);

                AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                message.Command = command;
                HomeMode.GameListener.SendMessage(message);

            }
        } 



private void RotateShopContent(DateTime time, bool isNewAcc)
        {
            //OfferBundles.RemoveAll(bundle => true);
            //if (OfferBundles.Select(bundle => bundle.IsDailyDeals).ToArray().Length > 6)
            //{
            //    OfferBundles.RemoveAll(bundle => bundle.IsDailyDeals);
            //}
            //OfferBundles.RemoveAll(offer => offer.EndTime <= time);

            //if (isNewAcc || DateTime.UtcNow >= DateTime.UtcNow.Date.AddHours(8)) // Daily deals refresh at 08:00 AM UTC
            //{
            //    if (LastVisitHomeTime < DateTime.UtcNow.Date.AddHours(8)||true)
            //    {
            //        UpdateDailyOfferBundles();
            //    }
            //}
            if (true || isNewAcc)
            {
                OfferBundle uab = new OfferBundle();
                uab.Title = "👴要全英雄";
                uab.EndTime = DateTime.UtcNow.Date.AddDays(18141); // tomorrow at 8:00 utc (11:00 MSK)
                uab.Cost = 0;
                Offer offer = new Offer(ShopItem.BrawlBox, 1);
                uab.Items.Add(offer);
                //OfferBundles.Add(uab);
            }

        }


        public void GenerateOffer(
    DateTime OfferStart,
    DateTime OfferEnd,
    int Count,
    int BrawlerID,
    int Extra,
    ShopItem Item,
    int Cost,
    int OldCost,
    int Currency,
    string Claim,
    string Title,
    string BGR,
    int IsTID,
    int DailyOfferType,
    bool OneTimeOffer,
    bool LoadOnStartup,
    bool Processed,
    int TypeBenefit,
    int Benefit,

    int panelClass,
    int panelType,

    int styleClass,
    int styleType

    )
        {

            OfferBundle bundle = new OfferBundle();
            bundle.IsDailyDeals = false;
            bundle.IsTrue = true;
            bundle.EndTime = OfferEnd;
            bundle.Cost = Cost;
            bundle.OldCost = OldCost;
            bundle.Currency = Currency;
            bundle.Claim = Claim;
            bundle.Title = Title;
            bundle.BackgroundExportName = BGR;
            bundle.IsTID = IsTID;
            bundle.OfferType = DailyOfferType;
            bundle.OneTimeOffer = OneTimeOffer;
            bundle.LoadOnStartup = LoadOnStartup;
            bundle.Processed = Processed;
            bundle.TypeBenefit = TypeBenefit;
            bundle.Benefit = Benefit;
            bundle.ShopPanelLayoutClass = panelClass;
            bundle.ShopPanelLayoutType = panelType;
            bundle.ShopStyleSetClass = styleClass;
            bundle.ShopStyleSetType = styleType;




              
              if (TimerMath(OfferStart, OfferEnd) == -1)
              {
                 bundle.Purchased = true;
              }
              if (bundle.Currency == 1000 && PaidOffers.Contains(bundle.Claim))
            {
                bundle.Currency = 0;
                bundle.Cost = 0;
                bundle.Title = "ЗАБРАТЬ АКЦИЮ";
                bundle.Purchased = false;
            }
            if (OffersClaimed.Contains(bundle.Claim))
            {
                 bundle.Purchased = true;
            }
            if (HomeMode.Avatar.HasHero((16000000 + BrawlerID)) && Item == ShopItem.GuaranteedHero)
              {
                 bundle.Purchased = true;
              }
            if (bundle.Purchased)
                return;
            // Не добавлять дубликаты по Claim
            if (OfferBundles.Any(b => b.Claim == bundle.Claim))
                return;

            Offer offer = new Offer(Item, Count, (16000000 + BrawlerID), Extra);
            bundle.Items.Add(offer);

            OfferBundles.Add(bundle);
        }

        public void GenerateOffer2(
    DateTime OfferStart,
    DateTime OfferEnd,
    int Count,
    int BrawlerID,
    int Extra,
    ShopItem Item,
    int Cost,
    int OldCost,
    int Currency,
    string Claim,
    string Title,
    string BGR,
    int IsTID,
    int DailyOfferType,
    bool OneTimeOffer,
    bool LoadOnStartup,
    bool Processed,
    int TypeBenefit,
    int Benefit,

    int panelClass,
    int panelType,

    int styleClass,
    int styleType,
int rasstanovka
    )
        {

            OfferBundle bundle = new OfferBundle();
            bundle.IsDailyDeals = false;
            bundle.IsTrue = true;
            bundle.EndTime = OfferEnd;
            bundle.Cost = Cost;
            bundle.OldCost = OldCost;
            bundle.Currency = Currency;
            bundle.Claim = Claim;
            bundle.Title = Title;
            bundle.BackgroundExportName = BGR;
            bundle.IsTID = IsTID;
            bundle.OfferType = DailyOfferType;
            bundle.OneTimeOffer = OneTimeOffer;
            bundle.LoadOnStartup = LoadOnStartup;
            bundle.Processed = Processed;
            bundle.TypeBenefit = TypeBenefit;
            bundle.Benefit = Benefit;
            bundle.ShopPanelLayoutClass = panelClass;
            bundle.ShopPanelLayoutType = panelType;
            bundle.ShopStyleSetClass = styleClass;
            bundle.ShopStyleSetType = styleType;
            bundle.rasstanovka = rasstanovka;
            



              
              if (TimerMath(OfferStart, OfferEnd) == -1)
              {
                 bundle.Purchased = true;
              }
              if (bundle.Currency == 1000 && PaidOffers.Contains(bundle.Claim))
            {
                bundle.Currency = 0;
                bundle.Cost = 0;
                bundle.Title = "ЗАБРАТЬ АКЦИЮ";
                bundle.Purchased = false;
            }
            if (OffersClaimed.Contains(bundle.Claim))
            {
                bundle.Purchased = true;
            }
            if (HomeMode.Avatar.HasHero((16000000 + BrawlerID)) && Item == ShopItem.GuaranteedHero)
              {
                 bundle.Purchased = true;
              }
            if (bundle.Purchased)
                return;
            // Не добавлять дубликаты по Claim
            if (OfferBundles.Any(b => b.Claim == bundle.Claim))
                return;

            Offer offer = new Offer(Item, Count, (16000000 + BrawlerID), Extra);
            bundle.Items.Add(offer);

            OfferBundles.Add(bundle);
        }

        public void GenerateOffer3(
    DateTime OfferStart,
    DateTime OfferEnd,
    int Count,
    int BrawlerID,
    int Extra,
    ShopItem Item,
    int Cost,
    int OldCost,
    int Currency,
    string Claim,
    string Title,
    string BGR,
    int IsTID,
    int DailyOfferType,
    bool OneTimeOffer,
    bool LoadOnStartup,
    bool Processed,
    int TypeBenefit,
    int Benefit,

    int panelClass,
    int panelType,

    int styleClass,
    int styleType,
int rasstanovka,
bool cl,
DateTime al
    )
        {

            OfferBundle bundle = new OfferBundle();
            bundle.IsDailyDeals = false;
            bundle.IsTrue = true;
            bundle.EndTime = OfferEnd;
            bundle.Cost = Cost;
            bundle.OldCost = OldCost;
            bundle.Currency = Currency;
            bundle.Claim = Claim;
            bundle.Title = Title;
            bundle.BackgroundExportName = BGR;
            bundle.IsTID = IsTID;
            bundle.OfferType = DailyOfferType;
            bundle.OneTimeOffer = OneTimeOffer;
            bundle.LoadOnStartup = LoadOnStartup;
            if (al > DateTime.MinValue)
            {
                bundle.Processed = true;
            }
            else
            {
              bundle.Processed = Processed;
            }
           
            bundle.TypeBenefit = TypeBenefit;
            bundle.Benefit = Benefit;
            bundle.ShopPanelLayoutClass = panelClass;
            bundle.ShopPanelLayoutType = panelType;
            bundle.ShopStyleSetClass = styleClass;
            bundle.ShopStyleSetType = styleType;
            bundle.rasstanovka = rasstanovka;
            bundle.cl = cl;
            bundle.aLLAH = al;


              
              if (TimerMath(OfferStart, OfferEnd) == -1)
              {
                 bundle.Purchased = true;
              }
              if (bundle.Currency == 1000 && PaidOffers.Contains(bundle.Claim))
            {
                bundle.Currency = 0;
                bundle.Cost = 0;
                bundle.Title = "ЗАБРАТЬ АКЦИЮ";
                bundle.Purchased = false;
            }
            if (OffersClaimed.Contains(bundle.Claim))
            {
                bundle.Purchased = true;
            }
            if (HomeMode.Avatar.HasHero((16000000 + BrawlerID)) && Item == ShopItem.GuaranteedHero)
              {
                 bundle.Purchased = true;
              }
            if (bundle.Purchased)
                return;
            // Не добавлять дубликаты по Claim
            if (OfferBundles.Any(b => b.Claim == bundle.Claim))
                return;

            Offer offer = new Offer(Item, Count, (16000000 + BrawlerID), Extra);
            bundle.Items.Add(offer);

            OfferBundles.Add(bundle);
        }

        public void Encode(ByteStream stream)
        {//64 VInt 32 Boolean 28 String 16 String 36 Int


            stream.WriteVInt(2000000);
            stream.WriteVInt(0);

            stream.WriteVInt(0);
            stream.WriteVInt(0);
            stream.WriteVInt(HomeMode.Avatar.Trophies); // Trophies
            stream.WriteVInt(HomeMode.Avatar.HighestTrophies); // Highest Trophies
            stream.WriteVInt(HomeMode.Avatar.HighestTrophies);
            stream.WriteVInt(TrophyRoadProgress);
            stream.WriteVInt(50000); // Experience
            ByteStreamHelper.WriteDataReference(stream, ThumbnailId);
            ByteStreamHelper.WriteDataReference(stream, NameColorId);


            stream.WriteVInt(27);//played gamemodes(dont shouw battle hint)
            for (int i = 0; i < 27; i++) stream.WriteVInt(i);
            int skins = 0;
            foreach (Hero hero in HomeMode.Avatar.Heroes)
            {
                if (hero.SelectedSkinId != 0) skins++;
            }
            stream.WriteVInt(skins); // Selected Skins
            foreach (Hero hero in HomeMode.Avatar.Heroes)
            {
                if (hero.SelectedSkinId != 0) ByteStreamHelper.WriteDataReference(stream, GlobalId.CreateGlobalId(29, hero.SelectedSkinId));
            }
            stream.WriteVInt(0); // Randomizer Skin Selected

            stream.WriteVInt(0); // Current Random Skin

            stream.WriteVInt(UnlockedSkins.Count); // Played game modes
            foreach (int s in UnlockedSkins)
            {
                ByteStreamHelper.WriteDataReference(stream, s);
            }

            stream.WriteVInt(0); // Unlocked Skin Purchase Option

            stream.WriteVInt(0); // New Item State

            stream.WriteVInt(0);
            stream.WriteVInt(0);//highest trophies
            stream.WriteVInt(0);
            stream.WriteVInt(2);//control mode
            stream.WriteBoolean(false);//battle hints
            stream.WriteVInt(0);//token doubler
            stream.WriteVInt(0);//maybe starr drop timer ? #v50 --risporce(bsds)
            stream.WriteVInt((int)(DateTime.Parse("2025-10-31 12:30:00") - DateTime.Now).TotalSeconds);//trophy league timer --risporce(bsds)
            stream.WriteVInt(0);//power play timer --risporce(bsds)
            stream.WriteVInt((int)(DateTime.Parse("2025-10-31 12:30:00") - DateTime.Now).TotalSeconds);//Brawl pass season time --risporce(bsds)

            stream.WriteVInt(0);
            stream.WriteVInt(0);
            stream.WriteVInt(0);

            stream.WriteBoolean(true); // Token Doubler Enabled
            stream.WriteVInt(2);  // Token Doubler New Tag State
            stream.WriteVInt(2);  // Event Tickets New Tag State
            stream.WriteVInt(2);  // Coin Packs New Tag State
            stream.WriteVInt(0);  // Change Name Cost
            stream.WriteVInt(0);  // Timer For the Next Name Change

            stream.WriteVInt(OfferBundles.Count); // Shop offers at 0x78e0c4
            foreach (OfferBundle offerBundle in OfferBundles)
            {
                offerBundle.Encode(stream);        // ес че эта хуйня крашит
            }
            ;

            //v51
            //stream.WriteBoolean(false);
            //stream.WriteBoolean(false);
            //stream.WriteVInt(0);
            //stream.WriteVInt(0);
            //stream.WriteBoolean(false);

            stream.WriteVInt(200);
            stream.WriteVInt(-1);

            stream.WriteVInt(0);

            stream.WriteVInt(1);
            stream.WriteVInt(30);

            stream.WriteByte(1);
            ByteStreamHelper.WriteDataReference(stream, CharacterIds[0]);
            //ByteStreamHelper.WriteDataReference(stream, CharacterIds[1]);
            //ByteStreamHelper.WriteDataReference(stream, CharacterIds[2]);

            stream.WriteString(HomeMode.Avatar.Region);
            stream.WriteString(CreatorCode);

            stream.WriteVInt(6);
            stream.WriteVInt(2147483647); stream.WriteVInt(28);  // Have already watched starrdrop stupid animation
            stream.WriteVInt(TokenReward); stream.WriteVInt(3);
            stream.WriteVInt(TrophiesReward); stream.WriteVInt(4);
            stream.WriteLogicLong(HomeMode.Avatar.WinStreak, 37);
            stream.WriteLogicLong(HomeMode.Avatar.DoNotDisturb, 7); // invite block
            stream.WriteLogicLong(1, 17); // chat block
            //stream.WriteLong(2, 1);  // Unknown
            //stream.WriteLong(3, 0);  // Tokens Gained
            //stream.WriteLong(4, 0);  // Trophies Gained
            //stream.WriteLong(6, 0);  // Demo Account
            //stream.WriteLong(7, 0);  // Invites Blocked

            //stream.WriteLong(8, 0);  // Star Points Gained
            //stream.WriteLong(9, 1);  // Show Star Points
            //stream.WriteLong(10, 0);  // Power Play Trophies Gained
            //stream.WriteLong(12, 1);  // Unknown
            //stream.WriteLong(14, 0);  // Coins Gained
            //stream.WriteLong(15, 0);  // AgeScreen | 3 = underage (disable social media); | 1 = age popup
            //stream.WriteLong(16, 1);
            //stream.WriteLong(17, 0);  // Team Chat Muted
            //stream.WriteLong(18, 1);  // Esport Button
            //stream.WriteLong(19, 0);  // Champion Ship Lives Buy Popup
            //stream.WriteLong(20, 0);  // Gems Gained
            //stream.WriteLong(21, 0);  // Looking For Team State
            //stream.WriteLong(22, 1);
            //stream.WriteLong(23, 0);  // Club Trophies Gained
            //stream.WriteLong(24, 1);  // Have already watched club league stupid animation
            // 26 - Club League Point
            // 27 - PowerPoints Gained
            // 30 - FUCKING FROGS
            // 32 - blings gained

            TokenReward = 0;
            TrophiesReward = 0;

            stream.WriteVInt(0);

            stream.WriteVInt(1); // count brawl pass seasons
            for (int i = 0; i < 1; i++)
            {
                stream.WriteVInt(21);
                stream.WriteVInt(BrawlPassTokens);
                stream.WriteBoolean(HasPremiumPass);

                stream.WriteVInt(131);
                stream.WriteBoolean(false);

                if (stream.WriteBoolean(true)) // Track 9
                {
                    stream.WriteLongLong128(PremiumPassProgress);
                }
                if (stream.WriteBoolean(true)) // Track 10
                {
                    stream.WriteLongLong128(BrawlPassProgress);
                }
                //v53
                stream.WriteBoolean(HasPremiumPassPlus); // BrawlPassPlus
                if (stream.WriteBoolean(true)) // Track ?
                {
                    stream.WriteLongLong128(BrawlPassPlusProgress);
                }
            }
            stream.WriteVInt(0);


            if (Quests != null)
            {
                stream.WriteBoolean(true); ;
                Quests.Encode(stream); ;
            }
            else
            {
                stream.WriteBoolean(true); ;
                stream.WriteVInt(0); ;
            }






            stream.WriteVInt(1);
            stream.WriteVInt(2);
            stream.WriteVInt(0);

            stream.WriteBoolean(true);
            stream.WriteVInt(UnlockedEmotes.Count + UnlockedTituls.Count + UnlockedThumbnails.Count); // Played game modes
            foreach (int Emote in UnlockedEmotes)
            {
                ByteStreamHelper.WriteDataReference(stream, Emote);
                stream.WriteVInt(1);
                stream.WriteVInt(Emote);
                stream.WriteVInt(4);
            }
            foreach (int Thumbnail in UnlockedThumbnails)
            {
                ByteStreamHelper.WriteDataReference(stream, Thumbnail);
                stream.WriteVInt(0);
            }
            foreach (int Titul in UnlockedTituls)
            {
                ByteStreamHelper.WriteDataReference(stream, Titul);
                stream.WriteVInt(0);
            }
            stream.WriteBoolean(false);

            stream.WriteInt(0);
            stream.WriteVInt(502052);
            ByteStreamHelper.WriteDataReference(stream, FavouriteCharacter);
            stream.WriteBoolean(false);
            stream.WriteVInt(0);
            //v53
            stream.WriteVInt(0);
            stream.WriteVInt(2023189);


            stream.WriteVInt(35); // event slot id
            stream.WriteVInt(1);
            stream.WriteVInt(2);
            stream.WriteVInt(3);
            stream.WriteVInt(4);
            stream.WriteVInt(5);
            stream.WriteVInt(6);
            stream.WriteVInt(7);
            stream.WriteVInt(8);
            stream.WriteVInt(9);
            stream.WriteVInt(10);
            stream.WriteVInt(11);
            stream.WriteVInt(12);
            stream.WriteVInt(13);
            stream.WriteVInt(14);
            stream.WriteVInt(15);
            stream.WriteVInt(16);
            stream.WriteVInt(17);
            stream.WriteVInt(18);
            stream.WriteVInt(19);
            stream.WriteVInt(20);
            stream.WriteVInt(21);
            stream.WriteVInt(22);
            stream.WriteVInt(23);
            stream.WriteVInt(24);
            stream.WriteVInt(25);
            stream.WriteVInt(26);
            stream.WriteVInt(27);
            stream.WriteVInt(28);
            stream.WriteVInt(29);
            stream.WriteVInt(30);
            stream.WriteVInt(31);
            stream.WriteVInt(32);
            stream.WriteVInt(33);
            stream.WriteVInt(34);
            stream.WriteVInt(35);

            stream.WriteVInt(Events.Length + 1);
            foreach (EventData e in Events)
            {
                e.Encode(stream);
            }



            stream.WriteVInt(9);
            stream.WriteVInt(9);
            stream.WriteVInt(9);
            stream.WriteVInt(1213);//v53
            stream.WriteVInt(1123);
            stream.WriteVInt(1123);

            stream.WriteDataReference(15, 0);



            stream.WriteVInt(2); // GameModeVaridation
            stream.WriteVInt(2);

            stream.WriteString(null); // 0xacecac
            stream.WriteVInt(0); // 0xacecc0
            stream.WriteVInt(0); // defeates
            stream.WriteVInt(3); // wins needed

            stream.WriteVInt(0); // modifier

            stream.WriteVInt(1); // wins
            stream.WriteVInt(1); // challenge variation
            //encoder.WriteBoolean(false);
            //encoder.WriteVInt(0); // 0xacee6c

            stream.WriteBoolean(false);

            stream.WriteVInt(1);
            stream.WriteBoolean(false);//LogicRankedSeason
            stream.WriteVInt(1);
            stream.WriteVInt(1);

            stream.WriteBoolean(false); // chromos text entry

            stream.WriteBoolean(false);
            stream.WriteBoolean(false);
            //encoder.WriteBoolean(false);
            stream.WriteBoolean(false);

            stream.WriteVInt(-1);
            stream.WriteBoolean(false);
            stream.WriteBoolean(false);
            stream.WriteVInt(-1);

            stream.WriteVInt(0);//v51
            stream.WriteVInt(0);//v51
            stream.WriteVInt(0);//v51
            stream.WriteBoolean(false);//v53



            stream.WriteVInt(0); // Comming Events


            ByteStreamHelper.WriteIntList(stream, new List<int> { 20, 35, 75, 140, 290, 480, 800, 1250, 1875, 2800 });
            ByteStreamHelper.WriteIntList(stream, new List<int> { 10, 25, 50, 99 });
            ByteStreamHelper.WriteIntList(stream, new List<int> { 150, 400, 1200, 2600 });


            //stream.WriteBoolean(true);  // Show Offers Packs


            stream.WriteVInt(ReleaseEntry.LogicReleaaseEntry.Length / 2);  // IntValueEntry
            for (int i = 0; i < ReleaseEntry.LogicReleaaseEntry.Length / 2; i++)
            {

                stream.WriteDataReference(16, ReleaseEntry.LogicReleaaseEntry[i * 2]);
                stream.WriteInt(ReleaseEntry.LogicReleaaseEntry[i * 2 + 1]);
                stream.WriteInt(0);
                stream.WriteInt(0);
                stream.WriteBoolean(false);
            }

            
            int[] LogicConfData = new int[]
            {
                1,41000000,
                16000007,1,   //������
                16000022,1,   //���
                16000016,1,   //���
                16000019,1,   //�����
                16000061,1,   //���
                16000066,1,   //рт
                16000031,1,   //������ �
                16000040,1,   
                16000047,1, 
                16000056,1,  
                16000059,1,   //����
                10027,0,
                10029,20,
                10018,1,

                29, 21,
                48, 99999,
                79, 99999,
                80, 99999,
                65,2,
                66,0,
                47,41381,
                50,1,
                1100, 500,
                1101, 500,
                1003, 1,
                36,0,
                74,1,
                78,1,
                17,4,
                100046,1,
                87,1,
                63,1,//dont show scid button
                38,699
            };
            LogicConfData[1] = 41000000 + 85;
            stream.WriteVInt(LogicConfData.Length / 2);  // IntValueEntry
            for (int i = 0; i < LogicConfData.Length / 2; i++)
            {
                stream.WriteVInt(LogicConfData[i * 2 + 1]);
                stream.WriteVInt(LogicConfData[i * 2]);
            }

            stream.WriteVInt(3); // Timed Int Value Entry

            stream.WriteVInt(14);
            stream.WriteVInt(1);
            stream.WriteVInt(0);
            stream.WriteVInt(739760);

            stream.WriteVInt(29); // skin theme timer
            stream.WriteVInt(10);
            stream.WriteVInt(79);
            stream.WriteVInt((int)(DateTime.Parse("2025-09-30 12:30:00") - DateTime.Now).TotalSeconds);
            
            stream.WriteVInt(29); // хз чет второе
            stream.WriteVInt(10);
            stream.WriteVInt(0);
            stream.WriteVInt(1330340);

            stream.WriteVInt(0); ; //Custom Event

            stream.WriteVInt(3); // chain offers

            stream.WriteBoolean(true); // ChronosTextEntry
            stream.WriteString("ПОЛУЧИ ПЕРСОВ РАНЬШЕ НА 3 МЕСЯЦА!"); // Subtitle
            stream.WriteVInt(0); // IsTid
            stream.WriteVInt(1);
            stream.WriteDataReference(69, 9); // Attached customize
            stream.WriteVInt(1);
            stream.WriteString("offer_bgr_circus"); // Background
            stream.WriteBoolean(true); // ChronosTextEntry
            stream.WriteString("РАННИЙ ДОСТУП || 299Р"); // Title
            stream.WriteVInt(0); // IsTid
            stream.WriteVInt(1);
            stream.WriteVInt(1);
            stream.WriteVInt(1);
            stream.WriteString(null);
            stream.WriteDataReference(29, 756); // Showed skin (-1 for nothing);

            stream.WriteBoolean(true); // ChronosTextEntry
            stream.WriteString("АКТИВИРУЙ БП РАНЬШЕ НА 2 МЕСЯЦА"); // Subtitle
            stream.WriteVInt(0); // IsTid
            stream.WriteVInt(1);
            stream.WriteDataReference(69, 10); // Attached customize
            stream.WriteVInt(1);
            stream.WriteString("offer_bgr_phoenix"); // Background
            stream.WriteBoolean(true); // ChronosTextEntry
            stream.WriteString("BUBLPASS PRO | 249 РУБ"); // Title
            stream.WriteVInt(0); // IsTid
            stream.WriteVInt(1);
            stream.WriteVInt(1);
            stream.WriteVInt(1);
            stream.WriteString(null);
            stream.WriteDataReference(29, 746); // Showed skin (-1 for nothing);

            stream.WriteBoolean(true); // ChronosTextEntry
            stream.WriteString("BublBrawl лучшая приватка!"); // Subtitle
            stream.WriteVInt(0); // IsTid
            stream.WriteVInt(1);
            stream.WriteDataReference(69, 11); // Attached customize
            stream.WriteVInt(1);
            stream.WriteString("offer_bgr_monsterrobot"); // Background
            stream.WriteBoolean(true); // ChronosTextEntry
            stream.WriteString("ДОБРО ПОЖАЛОВАТЬ!"); // Title
            stream.WriteVInt(0); // IsTid
            stream.WriteVInt(1);
            stream.WriteVInt(1);
            stream.WriteVInt(1);
            stream.WriteString(null);
            stream.WriteDataReference(29, 723); // Showed skin (-1 for nothing);

            stream.WriteVInt(0);

            stream.WriteVInt(2);
            stream.WriteVInt(1);
            stream.WriteVInt(2);
            stream.WriteVInt(2);
            stream.WriteVInt(1);
            stream.WriteVInt(-1);
            stream.WriteVInt(2);
            stream.WriteVInt(1);
            stream.WriteVInt(4);

            stream.WriteVInt(0);
            stream.WriteVInt(0);

            stream.WriteLong(HomeId);  // PlayerID

            stream.WriteVInt(0); // NotificationFactory

            stream.WriteVInt(-1);
            stream.WriteBoolean(false);
            stream.WriteVInt(0);
            stream.WriteVInt(0);//+108
            stream.WriteVInt(0);//+124

            stream.WriteBoolean(false);
            stream.WriteVInt(HomeMode.Avatar.Heroes.Count);//Gears
            foreach (Hero hero in HomeMode.Avatar.Heroes)
            {
                ByteStreamHelper.WriteDataReference(stream, hero.CharacterId);
                List<GearData> gearDatas = new List<GearData>();
                foreach (GearData gearData in DataTables.Get(DataType.Gear).GetDatas())
                {
                    if (gearData.Rarity == "RareGear" || gearData.ExtraHerosAvailableTo.Contains(DataTables.Get(DataType.Character).GetDataByGlobalId<CharacterData>(hero.CharacterId).Name)) gearDatas.Add(gearData);
                }
                stream.WriteVInt(gearDatas.Count);
                for (int i = 0; i < gearDatas.Count; i++)
                {
                    ByteStreamHelper.WriteDataReference(stream, gearDatas[i]);
                }
                stream.WriteVInt(2);
                stream.WriteDataReference(0);
                stream.WriteDataReference(0);

            }
stream.WriteBoolean(true); // StarRoad?
            {
                int UnlockingBrawlers = 0;
                int NextBrawler = 0;
                int creditsCost = 0; 
                int gemsCost = 0;
                List<int> unlockStarRoadList = UnlockStarRoad.ToList();
                for (int BrawlerIndex = unlockStarRoadList.Count - 1; BrawlerIndex >= 0; BrawlerIndex--)
                {
                    if (HomeMode.Avatar.HasHero(unlockStarRoadList[BrawlerIndex]))
                    {
                        unlockStarRoadList.RemoveAt(BrawlerIndex);
                        }
                }
                UnlockStarRoad = unlockStarRoadList.ToArray();

                if (UnlockStarRoad.Length > 0) { UnlockingBrawlers = 1; }
                if (UnlockStarRoad.Length == 0) { NextBrawler = 0; } else { NextBrawler = UnlockStarRoad.Length - 1; }
                stream.WriteVInt(0);
                stream.WriteVInt(0);
                stream.WriteVInt(0);
                stream.WriteVInt(UnlockingBrawlers); // Unlocking Brawler
                if (UnlockingBrawlers == 1)
                {
                    ByteStreamHelper.WriteDataReference(stream, UnlockStarRoad[0]);
                    CharacterData characterData = DataTables.Get(DataType.Character).GetData<CharacterData>(UnlockStarRoad[0] - 16000000);
                    CardData cardData = DataTables.Get(DataType.Card).GetData<CardData>(characterData.Name + "_unlock");
                    if (cardData.Rarity == "rare") { creditsCost = 160; gemsCost = 29; }
                    if (cardData.Rarity == "super_rare") { creditsCost = 430; gemsCost = 79; }
                    if (cardData.Rarity == "epic") { creditsCost = 925; gemsCost = 169; }
                    if (cardData.Rarity == "mega_epic") { creditsCost = 1900; gemsCost = 349; }
                    if (cardData.Rarity == "legendary") { creditsCost = 3800; gemsCost = 699; }
                    stream.WriteVInt(creditsCost);
                    stream.WriteVInt(gemsCost);
                    stream.WriteVInt(-1);
                    stream.WriteVInt(HomeMode.Avatar.RareTokens); // Collected
                    stream.WriteVInt(0); // Index
                    stream.WriteVInt(0);
                }

                stream.WriteVInt(NextBrawler);
                for (int BrawlerIndex = 1; BrawlerIndex < UnlockStarRoad.Length; BrawlerIndex++)
                {
                    ByteStreamHelper.WriteDataReference(stream, UnlockStarRoad[BrawlerIndex]);
                    CharacterData characterData = DataTables.Get(DataType.Character).GetData<CharacterData>(UnlockStarRoad[BrawlerIndex] - 16000000);
                    CardData cardData = DataTables.Get(DataType.Card).GetData<CardData>(characterData.Name + "_unlock");
                    if (cardData.Rarity == "rare") { creditsCost = 160; gemsCost = 29; }
                    if (cardData.Rarity == "super_rare") { creditsCost = 430; gemsCost = 79; }
                    if (cardData.Rarity == "epic") { creditsCost = 925; gemsCost = 169; }
                    if (cardData.Rarity == "mega_epic") { creditsCost = 1900; gemsCost = 349; }
                    if (cardData.Rarity == "legendary") { creditsCost = 3800; gemsCost = 699; }
                    stream.WriteVInt(creditsCost);
                    stream.WriteVInt(gemsCost);
                    stream.WriteVInt(-1);
                    stream.WriteVInt(0); // Collected
                    stream.WriteVInt(BrawlerIndex); // Index
                    stream.WriteVInt(0);
                }

                stream.WriteVInt(0);
                stream.WriteVInt(0);
            }

            stream.WriteVInt(76);
            for (int i = 0; i < 76; i++)
            {
                Hero hero = HomeMode.Avatar.GetHero(GlobalId.CreateGlobalId(16, i));
                int mastery = 0;
                int claimMastery = 0;
                if (hero != null) mastery = hero.MasteryPoints;
                if (hero != null) claimMastery = hero.ClaimedMasteryLVL;

                stream.WriteVInt(mastery);
                stream.WriteVInt(claimMastery);
                stream.WriteDataReference(16, i);
                Console.WriteLine(i);
            }

            DefaultBattleCard.Encode(stream);

            stream.WriteVInt(0); //sub_D5C83C

            StarrDrop.Encode(stream, HomeMode);

            stream.WriteBoolean(false);//v53
        }

        public int TimerMath(DateTime timer_start, DateTime timer_end)
        {
            {
                DateTime timer_now = DateTime.Now;
                if (timer_now > timer_start)
                {
                    if (timer_now < timer_end)
                    {
                        int time_sec = (int)(timer_end - timer_now).TotalSeconds;
                        return time_sec;
                    }
                    else
                    {
                        return -1;
                    }
                }
                else
                {
                    return -1;
                }
            }
        }

        // Логика VIP
        public bool IsVIPActive()
        {
            return IsVIP && VIPExpire > DateTime.UtcNow;
        }

        public void GrantVIP(int days)
        {
            IsVIP = true;
            VIPExpire = DateTime.UtcNow.AddDays(days);
        }

        public void RemoveVIP()
        {
            IsVIP = false;
            VIPExpire = DateTime.MinValue;
        }

        // Форматирование имени с припиской [VIP]
        public static string FormatNameWithVIP(string name, ClientHome home)
        {
            if (home != null && home.IsVIP && home.VIPExpire > DateTime.UtcNow)
                return "[VIP] " + name;
            return name;
        }

        public void SyncVIPStatus(ClientAvatar avatar)
        {
            IsVIP = avatar.IsVIP;
            VIPExpire = avatar.VIPExpire;
            Console.WriteLine($"VIP Status Synced: PlayerId: {avatar.AccountId}, IsVIP: {IsVIP}, VIPExpire: {VIPExpire}");
        }

        public void UpdatePlayerData(ClientAvatar avatar)
        {
            SyncVIPStatus(avatar);
            // Другие обновления данных игрока
            Console.WriteLine($"Player Data Updated: PlayerId: {avatar.AccountId}");
        }
    }
}
