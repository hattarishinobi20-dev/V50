namespace Supercell.Laser.Logic.Command.Home
{
    using Supercell.Laser.Logic.Data;
    using Supercell.Laser.Logic.Helper;
    using Supercell.Laser.Logic.Home;
    using Supercell.Laser.Logic.Home.Gatcha;
    using Supercell.Laser.Logic.Home.Quest;
    using Supercell.Laser.Logic.Message.Home;
    using Supercell.Laser.Titan.DataStream;
    using Supercell.Laser.Titan.Debug;
    using Supercell.Laser.Logic.Util;

    public class LogicPurchaseBrawlerCommand : Command
    {
        public int CharacterInstanceId;
        public override void Decode(ByteStream stream)
        {
            base.Decode(stream);
            stream.ReadVInt();
            CharacterInstanceId = stream.ReadVInt();
        }

        public override int Execute(HomeMode homeMode)
        {
            int globalId = GlobalId.CreateGlobalId(16, CharacterInstanceId);
            if (!homeMode.Avatar.HasHero(globalId))
            {
                int creditsCost = 0;
                int gemsCost = 0;
                
                CharacterData characterData = DataTables.Get(DataType.Character).GetData<CharacterData>(CharacterInstanceId);
                if (characterData == null) return -1;
                CardData cardData = DataTables.Get(DataType.Card).GetData<CardData>(characterData.Name + "_unlock");
                if (cardData == null) return -1;
                if (cardData.Rarity == "rare") { creditsCost = 160; gemsCost = 29; }
                if (cardData.Rarity == "super_rare") { creditsCost = 430; gemsCost = 79; }
                if (cardData.Rarity == "epic") { creditsCost = 925; gemsCost = 169; }
                if (cardData.Rarity == "mega_epic") { creditsCost = 1900; gemsCost = 349; }
                if (cardData.Rarity == "legendary") { creditsCost = 3800; gemsCost = 699; }
                if (!homeMode.Avatar.UseDiamonds(gemsCost)) return -1;

                LogicGiveDeliveryItemsCommand command = new LogicGiveDeliveryItemsCommand();
                DeliveryUnit unit = new DeliveryUnit(100);

                GatchaDrop reward = new GatchaDrop(1);
                reward.DataGlobalId = CharacterInstanceId;
                reward.Count = 1;
                unit.AddDrop(reward);

                command.DeliveryUnits.Add(unit);
                command.Execute(homeMode);
                AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                message.Command = command;
                homeMode.GameListener.SendMessage(message);
                return 0;
            }


            return -1;
        }

        public override int GetCommandType()
        {
            return 560;
        }
    }
}
