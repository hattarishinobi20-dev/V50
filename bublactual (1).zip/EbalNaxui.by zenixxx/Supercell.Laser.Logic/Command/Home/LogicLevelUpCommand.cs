﻿namespace Supercell.Laser.Logic.Command.Home
{
    using Supercell.Laser.Logic.Helper;
    using Supercell.Laser.Logic.Home;
    using Supercell.Laser.Logic.Home.Structures;
    using Supercell.Laser.Titan.DataStream;

    public class LogicLevelUpCommand : Command
    {
        private int CharacterId;
        const double GEMS_PER_COIN = 55.0 / 290;
        public override void Decode(ByteStream stream)
        {
            base.Decode(stream);
            stream.ReadVInt(); // class
            CharacterId = stream.ReadVInt(); // я забыл
        }

        public override int Execute(HomeMode homeMode)
        {
            bool Check(int count)
            {
                if (count > homeMode.Avatar.Gold)
                {
                    int remainingCoins = homeMode.Avatar.Gold;
                    homeMode.Avatar.Gold = 0;
                    int deficit = count - remainingCoins;
                    double totalGemsNeeded = deficit * GEMS_PER_COIN;
                    int roundedGemsNeeded = (int)Math.Ceiling(totalGemsNeeded);

                    if (!homeMode.Avatar.UseDiamonds(roundedGemsNeeded))
                    {
                        return false;
                    }

                    return true;
                }

                homeMode.Avatar.Gold -= count;
                return true;
            }

            Hero hero = homeMode.Avatar.GetHero(GlobalId.CreateGlobalId(16, CharacterId));
            if (hero == null) return -1;
            if (!Check(Hero.UpgradeCostTable[hero.PowerLevel - 1])) return -2;
            

            hero.PowerLevel++;

            return 0;
        }

        public override int GetCommandType()
        {
            return 520;
        }
    }
}
