namespace Supercell.Laser.Logic.Command.Home
{
    using Supercell.Laser.Logic.Home;
    using Supercell.Laser.Logic.Data;
    using Supercell.Laser.Logic.Home.Gatcha;
    using Supercell.Laser.Logic.Message.Home;
    using Supercell.Laser.Titan.DataStream;

    public class LogicClaimStarRoadCommand : Command
    {
        public int BrawlerId;

        public override void Encode(ByteStream stream)
        {
            base.Encode(stream);
            stream.WriteVInt(0); // dummy or reserved
            stream.WriteVInt(BrawlerId);
        }

        public override void Decode(ByteStream stream)
        {
            base.Decode(stream);
            stream.ReadVInt(); // dummy or reserved
            BrawlerId = stream.ReadVInt();
            Console.WriteLine($"[LogicClaimStarRoadCommand] Decode called. BrawlerId: {BrawlerId}");
        }

        public override int Execute(HomeMode homeMode)
        {
            Console.WriteLine($"[LogicClaimStarRoadCommand] Execute called. BrawlerId: {BrawlerId}, HomeMode: {homeMode}");
            int globalId = GlobalId.CreateGlobalId(16, BrawlerId);
            int creditsCost = 0;
            int gemsCost = 0;
            if (homeMode.Avatar.HasHero(globalId)) { Console.WriteLine("[LogicClaimStarRoadCommand] Hero already owned"); return -1; }
            else
            {
                CharacterData characterData = DataTables.Get(16).GetDataByGlobalId<CharacterData>(globalId);
                if (characterData == null) return -1;
                CardData cardData = DataTables.Get(23).GetData<CardData>(characterData.Name + "_unlock");
                if (cardData == null) return -1;
                if (cardData.Rarity == "rare") { creditsCost = 160; gemsCost = 29; }
                if (cardData.Rarity == "super_rare") { creditsCost = 430; gemsCost = 79; }
                if (cardData.Rarity == "epic") { creditsCost = 925; gemsCost = 169; }
                if (cardData.Rarity == "mega_epic") { creditsCost = 1900; gemsCost = 349; }
                if (cardData.Rarity == "legendary") { creditsCost = 3800; gemsCost = 699; }
                // Сначала пробуем списать токены
                if (!homeMode.Avatar.UseRareTokens(creditsCost))
                {
                    // Если не хватает токенов, пробуем списать гемы
                    if (!homeMode.Avatar.UseDiamonds(gemsCost))
                    {
                        // Не хватает ни токенов, ни гемов
                        return -2;
                    }
                }
                homeMode.Avatar.UnlockHero(characterData.GetGlobalId());
                Console.WriteLine($"Hero purchase successful. PlayerId: {homeMode.Avatar.AccountId}, HeroId: {characterData.GetGlobalId()}, GemsUsed: {gemsCost}, CreditsUsed: {creditsCost}");
                // Явно отправляем клиенту команду об успешной покупке
                LogicBrawlerRecruitRoadChangedCommand command = new LogicBrawlerRecruitRoadChangedCommand();
                command.homeMode = homeMode;
                AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                message.Command = command;
                homeMode.GameListener.SendMessage(message);
            }
            return 0;
        }

        public override int GetCommandType()
        {
            return 562;
        }
    }
}
