using Supercell.Laser.Logic.Battle.Structures;
using Supercell.Laser.Logic.Battle;
using Supercell.Laser.Logic.Listener;
using Supercell.Laser.Logic.Team;
using Supercell.Laser.Logic.Home;
using System.Threading.Tasks;
using System.Timers;

namespace Supercell.Laser.Logic.Command
{
    public class PlayAgainCommand : Command
    {
        public override int GetCommandType() => 533;
        private readonly long _accountId;
        private readonly bool _isTeamMode;
        private static readonly Dictionary<long, bool> _teamAgreement = new Dictionary<long, bool>();
        private static readonly object _lock = new object();
        private static System.Timers.Timer _timer;

        public PlayAgainCommand(long accountId, bool isTeamMode)
        {
            _accountId = accountId;
            _isTeamMode = isTeamMode;
        }

        public override int Execute(HomeMode homeMode)
        {
            var player = BattlePlayerManager.Get(_accountId);
            if (player == null)
            {
                Console.WriteLine($"[PlayAgainCommand][Error] Игрок с ID {_accountId} не найден");
                return -1;
            }

            if (!player.BattleEnded)
            {
                player.SendError("Бой еще не завершен");
                return -1;
            }

            if (_isTeamMode)
            {
                HandleTeamMode(player);
            }
            else
            {
                StartSoloBattle(player);
            }
            return 0;
        }

        private void HandleTeamMode(BattlePlayer player)
        {
            lock (_lock)
            {
                _teamAgreement[player.AccountId] = true;
                Console.WriteLine($"[PlayAgainCommand][Info] Игрок {player.AccountId} согласен на новый бой в команде");

                var team = player.CurrentBattle?.m_players?.Where(p => p.TeamIndex == player.TeamIndex).ToList();
                if (team == null || team.Count == 0)
                {
                    player.SendError("Команда не найдена");
                    Console.WriteLine($"[PlayAgainCommand][Error] Команда для игрока {player.AccountId} не найдена");
                    return;
                }
                Console.WriteLine($"[PlayAgainCommand][Info] Найдена команда из {team.Count} игроков для игрока {player.AccountId}");

                // Проверяем, все ли уже согласились
                int agreedCount = team.Count(p => _teamAgreement.ContainsKey(p.AccountId) && _teamAgreement[p.AccountId]);
                Console.WriteLine($"[PlayAgainCommand][Info] Согласных игроков в команде {player.TeamIndex}: {agreedCount} из {team.Count}");
                if (team.All(p => _teamAgreement.ContainsKey(p.AccountId) && _teamAgreement[p.AccountId]))
                {
                    Console.WriteLine($"[PlayAgainCommand][Info] Все игроки команды {player.TeamIndex} согласны на новый бой");
                    StartTeamBattle(team);
                }
                else if (_timer == null || !_timer.Enabled)
                {
                    // Запускаем таймер на 10 секунд, если еще не запущен
                    _timer = new System.Timers.Timer(10000) { AutoReset = false };
                    _timer.Elapsed += (s, e) => OnTimerElapsed(team);
                    _timer.Start();
                    Console.WriteLine($"[PlayAgainCommand][Info] Таймер на 10 секунд запущен для команды {player.TeamIndex} (игроков: {team.Count})");
                }
                else
                {
                    Console.WriteLine($"[PlayAgainCommand][Info] Таймер уже запущен для команды {player.TeamIndex}, ожидание продолжается");
                }
            }
        }

        private void OnTimerElapsed(List<BattlePlayer> team)
        {
            lock (_lock)
            {
                Console.WriteLine($"[PlayAgainCommand][Info] Время ожидания для команды истекло");
                Console.WriteLine($"[PlayAgainCommand][Info] Запускается новый бой для команды, даже если не все согласились");
                StartTeamBattle(team);
                _teamAgreement.Clear();
            }
        }

        private void StartTeamBattle(List<BattlePlayer> team)
        {
            var locationId = team.First().CurrentBattle?.m_locationId ?? 0; // Берем locationId из текущего боя
            var newBattle = new BattleMode(locationId);
            newBattle.m_players = team;

            foreach (var player in team)
            {
                player.ResetForNewBattle();
                player.CurrentBattle = newBattle;
                player.SendNewBattleStart(newBattle);
            }
            _teamAgreement.Clear();
            if (_timer != null)
            {
                _timer.Stop();
                _timer.Dispose();
                _timer = null;
            }
        }

        private void StartSoloBattle(BattlePlayer player)
        {
            Console.WriteLine($"[PlayAgainCommand][Info] Запуск одиночного боя (Showdown) для игрока {player.AccountId}");
            var currentBattle = player.CurrentBattle;
            int locationId = 0; // По умолчанию
            if (currentBattle != null)
            {
                locationId = currentBattle.m_locationId;
                Console.WriteLine($"[PlayAgainCommand][Info] Используется locationId {locationId} из текущего боя для одиночного режима");
            }
            else
            {
                Console.WriteLine($"[PlayAgainCommand][Warn] Текущий бой игрока {player.AccountId} не найден, используется locationId = 0");
            }
            
            var newBattle = new BattleMode(locationId);
            newBattle.m_players = new List<BattlePlayer> { player };
            // Дополнительно устанавливаем параметры для Showdown, если они есть
            if (currentBattle != null)
            {
                // Убрано присвоение GameModeVariation, так как свойство только для чтения
                Console.WriteLine($"[PlayAgainCommand][Info] GameModeVariation текущего боя = {currentBattle.GameModeVariation} (используется для информации)");
            }

            player.ResetForNewBattle();
            player.CurrentBattle = newBattle;
            player.SendNewBattleStart(newBattle);
            Console.WriteLine($"[PlayAgainCommand][Info] Одиночный бой для игрока {player.AccountId} успешно запущен с locationId {locationId}");
        }
    }
}
