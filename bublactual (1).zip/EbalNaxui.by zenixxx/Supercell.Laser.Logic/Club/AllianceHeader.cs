﻿namespace Supercell.Laser.Logic.Club
{
    using Supercell.Laser.Logic.Avatar;
    using Supercell.Laser.Logic.Data.Helper;
    using Supercell.Laser.Logic.Helper;
    using Supercell.Laser.Titan.DataStream;

    public class AllianceHeader
    {
        private long Id;

        private string Name;
        private int Badge;
        private int PlayersCount;
        private int Trophies;
        private int RequiredTrophies;

        private int Type;

        public AllianceHeader(long id, string name, int badge, int playersCount, int trophies, int requiredTrophies, int type)
        {
            Id = id;
            Name = name;
            Badge = badge;
            PlayersCount = playersCount;
            Trophies = trophies;
            RequiredTrophies = requiredTrophies;

            Type = type;
        }

        public void Encode(ByteStream stream)
        {
            stream.WriteLong(Id);
            stream.WriteString(Name ?? "Без названия");
            ByteStreamHelper.WriteDataReference(stream, Badge > 0 ? Badge : GlobalId.CreateGlobalId(8, 0));
            stream.WriteVInt(Type > 0 ? Type : 1);
            stream.WriteVInt(PlayersCount > 0 ? PlayersCount : 1);
            stream.WriteVInt(Trophies >= 0 ? Trophies : 0);
            stream.WriteVInt(RequiredTrophies >= 0 ? RequiredTrophies : 0);
            ByteStreamHelper.WriteDataReference(stream, null);
            stream.WriteString("RU");
            stream.WriteVInt(0);
            stream.WriteBoolean(false);
            stream.WriteVInt(0);
            stream.WriteVInt(0);//v53
        }
    }
}
