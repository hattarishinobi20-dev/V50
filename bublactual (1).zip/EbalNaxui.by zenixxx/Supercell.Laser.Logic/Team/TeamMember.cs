﻿namespace Supercell.Laser.Logic.Team
{
    using Supercell.Laser.Logic.Avatar.Structures;
    using Supercell.Laser.Logic.Helper;
    using Supercell.Laser.Titan.DataStream;
    using Supercell.Laser.Logic.Home;
    public class TeamMember
    {
        public bool IsOwner;
        public long AccountId;

        public int CharacterId;
        public int SkinId;

        public int HeroTrophies;
        public int HeroHighestTrophies;
        public int HeroLevel;

        public int State;
        public bool IsReady;

        public int SelectedStarPowerId;

        public PlayerDisplayData DisplayData;

        public HomeMode homeMode;

        public int TeamIndex;

        public void Encode(ByteStream stream)
        {
            stream.WriteBoolean(IsOwner);
            stream.WriteLong(AccountId);

            ByteStreamHelper.WriteDataReference(stream, CharacterId);
            ByteStreamHelper.WriteDataReference(stream, SkinId);

            stream.WriteVInt(0);
            stream.WriteVInt(HeroTrophies);//tropies
            stream.WriteVInt(HeroHighestTrophies);
            stream.WriteVInt(HeroLevel);//power
            stream.WriteVInt(State);

            stream.WriteBoolean(IsReady);

            stream.WriteVInt(TeamIndex); // team
            stream.WriteVInt(0); // unk
            stream.WriteVInt(0); // unk
            stream.WriteVInt(0); // unk
            stream.WriteVInt(0); // unk
            stream.WriteVInt(0); // unk
            stream.WriteVInt(0); // unk

            DisplayData.Encode(stream);
            
            ByteStreamHelper.WriteDataReference(stream, null); // star power
            ByteStreamHelper.WriteDataReference(stream, null); // star power
            ByteStreamHelper.WriteDataReference(stream, null); // star power
            ByteStreamHelper.WriteDataReference(stream, null); // unk
            ByteStreamHelper.WriteDataReference(stream, null); // OVERCHARGE
            
            stream.WriteVInt(0);
        }

        /// <summary>
        /// Обновляет данные героя в TeamMember после изменения кубков
        /// </summary>
        public void UpdateHeroData(HomeMode homeMode)
        {
            if (homeMode?.Avatar == null) return;
            
            var hero = homeMode.Avatar.GetHero(CharacterId);
            if (hero != null)
            {
                int oldTrophies = HeroTrophies;
                int oldLevel = HeroLevel;
                
                HeroTrophies = hero.Trophies;
                HeroHighestTrophies = hero.HighestTrophies;
                HeroLevel = hero.PowerLevel;
                SkinId = GlobalId.CreateGlobalId(29, hero.SelectedSkinId);
                
                Console.WriteLine($"UpdateHeroData: Игрок {AccountId}, персонаж {CharacterId}, кубки: {oldTrophies} -> {HeroTrophies}, уровень: {oldLevel} -> {HeroLevel}");
            }
            else
            {
                Console.WriteLine($"UpdateHeroData: Герой не найден для игрока {AccountId}, персонаж {CharacterId}");
            }
        }
    }
}
