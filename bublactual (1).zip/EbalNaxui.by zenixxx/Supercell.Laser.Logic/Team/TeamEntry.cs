namespace Supercell.Laser.Logic.Team
{
    using System.Globalization;
    using System.Xml.Linq;
    using Microsoft.Win32.SafeHandles;
    using Supercell.Laser.Logic.Battle.Objects;
    using Supercell.Laser.Logic.Battle.Structures;
    using Supercell.Laser.Logic.Helper;
    using Supercell.Laser.Logic.Listener;
    using Supercell.Laser.Logic.Message.Team;
    using Supercell.Laser.Logic.Message.Team.Stream;
    using Supercell.Laser.Logic.Team.Stream;
    using Supercell.Laser.Titan.DataStream;
    using Supercell.Laser.Titan.Debug;

    public class TeamEntry
    {
        public long Id;
        public int Type;

        public int LocationId;

        public List<TeamMember> Members { get; set; }
        public List<TeamInviteEntry> Invites { get; set; }
        public List<TeamJoinRequest> JoinRequests { get; set; }
        public List<int> DisabledBots { get; set; }
        public int EventSlot { get; set; }
        public List<int> CustomModifiers;

        public BattlePlayerMap BattlePlayerMap;
        private long EntryCounter;
        public List<TeamStreamEntry> Stream { get; private set; }

        public TeamEntry()
        {
            Members = new List<TeamMember>();
            Invites = new List<TeamInviteEntry>();
            JoinRequests = new List<TeamJoinRequest>();
            DisabledBots = new List<int>();
            Stream = new List<TeamStreamEntry>();
            CustomModifiers = new List<int>();

            EventSlot = 1;
            EntryCounter = 0;
        }

        public void AddStreamEntry(TeamStreamEntry entry)
        {
            if (entry == null) return;

            entry.Id = ++EntryCounter;
            Stream.Add(entry);
            TeamStreamMessage message = new TeamStreamMessage();
            message.TeamId = Id;
            message.Entries = new TeamStreamEntry[] { entry };

            foreach (var member in Members)
            {
                if (LogicServerListener.Instance.IsPlayerOnline(member.AccountId))
                {
                    LogicServerListener.Instance.GetGameListener(member.AccountId).SendTCPMessage(message);
                }
            }
        }

        public void StreamUpdated()
        {
            
        }

        public TeamMember GetMember(long id)
        {
            return Members.Find(member => member.AccountId == id);
        }

        public TeamInviteEntry GetInviteById(long id)
        {
            return Invites.Find(invite => invite.Id == id);
        }

        public bool IsEveryoneReady()
        {
            foreach (TeamMember member in Members)
            {
                if (!member.IsReady) return false;
            }
            return true;
        }

        private HashSet<long> playAgainVotes = new HashSet<long>();

        public void AddPlayAgainVote(BattlePlayer player)
        {
            playAgainVotes.Add(player.AccountId);
        }
        public bool AllPlayersWantPlayAgain()
        {
            return playAgainVotes.Count == Members.Count;
        }
        public void ClearPlayAgainVotes()
        {
            playAgainVotes.Clear();
        }
        public List<BattlePlayer> GetPlayers()
        {
            var players = new List<BattlePlayer>();
            foreach (var member in Members)
            {
                var bp = BattlePlayerManager.Get(member.AccountId);
                if (bp != null)
                    players.Add(bp);
            }
            return players;
        }

        public void ResetForNewBattle()
        {
            foreach (var player in GetPlayers())
            {
                player.ResetForNewBattle();
            }
        }

        public void TeamUpdated()
        {
            // Обновляем данные героев для всех участников команды
            foreach (var member in Members)
            {
                if (LogicServerListener.Instance.IsPlayerOnline(member.AccountId))
                {
                    var homeMode = LogicServerListener.Instance.GetHomeMode(member.AccountId);
                    if (homeMode != null)
                    {
                        member.UpdateHeroData(homeMode);
                        Console.WriteLine($"TeamUpdated: Обновлены данные для игрока {member.AccountId}, кубки: {member.HeroTrophies}, уровень: {member.HeroLevel}");
                    }
                }
            }

            TeamMessage message = new TeamMessage();
            message.Team = this;

            foreach (var member in Members)
            {
                //Debugger.Print("isPlayerOnline:" + LogicServerListener.Instance.IsPlayerOnline(member.AccountId));
                if (LogicServerListener.Instance.IsPlayerOnline(member.AccountId))
                {
                    LogicServerListener.Instance.GetGameListener(member.AccountId).SendTCPMessage(message);
                    Console.WriteLine($"TeamUpdated: Отправлено сообщение игроку {member.AccountId}");
                }
            }
            //Debugger.Print(LocationId.ToString());
        }

        public bool CanAddMember()
        {
            // Для дружеских матчей нет ограничений по количеству участников
            if (Type == 1) // 1 - дружеский матч
            {
                return true;
            }
            
            // Для обычных команд лимит - 3 участника
            return Members.Count < 3;
        }

        public bool AddMember(TeamMember member)
        {
            // Проверяем, не находится ли игрок уже в команде
            if (Members.Any(m => m.AccountId == member.AccountId))
            {
                Console.WriteLine($"Игрок {member.AccountId} уже находится в команде {Id}");
                return false;
            }

            // Проверяем лимит участников (3 для обычных команд, без ограничений для дружеских матчей)
            if (!CanAddMember())
            {
                // Отправляем уведомление игроку о том, что команда заполнена
                SendTeamFullNotification(member.AccountId);
                Console.WriteLine($"Не удалось добавить участника {member.AccountId} в команду {Id}. Команда уже полная (3 участника).");
                return false;
            }

            // Добавляем участника
            Members.Add(member);
            TeamUpdated();
            Console.WriteLine($"Добавлен новый участник {member.AccountId} в команду {Id}. Текущий размер команды: {Members.Count}");
            return true;
        }

        private void SendTeamFullNotification(long accountId)
        {
            if (LogicServerListener.Instance.IsPlayerOnline(accountId))
            {
                var listener = LogicServerListener.Instance.GetGameListener(accountId);
                if (listener != null)
                {
                    var notification = new Supercell.Laser.Logic.Notification.FloaterTextNotification("Команда заполнена. Пожалуйста, попробуйте позже.");
                    var command = new Supercell.Laser.Logic.Command.Home.LogicAddNotificationCommand();
                    command.Notification = notification;
                    var message = new Supercell.Laser.Logic.Message.Home.AvailableServerCommandMessage();
                    message.Command = command;
                    listener.SendTCPMessage(message);
                }
            }
        }

        public void Encode(ByteStream stream)
        {
            stream.WriteVInt(Type);
            stream.WriteBoolean(Type == 1);
            stream.WriteVInt(3); // Team capacity

            stream.WriteLong(Id);

            stream.WriteVInt(0);
            stream.WriteBoolean(false);
            stream.WriteBoolean(false);
            stream.WriteVInt(0);
            stream.WriteVInt(0);
            stream.WriteVInt(0);

            //if(LocationId==15000057) ByteStreamHelper.WriteDataReference(stream, 15000459);
            ByteStreamHelper.WriteDataReference(stream, LocationId);
            ByteStreamHelper.WriteBattlePlayerMap(stream, BattlePlayerMap);

            stream.WriteVInt(Members.Count);
            foreach (TeamMember entry in Members.ToArray())
            {
                entry.Encode(stream);
            }

            stream.WriteVInt(Invites.Count);
            foreach (TeamInviteEntry entry in Invites.ToArray())
            {
                entry.Encode(stream);
            }

            stream.WriteVInt(JoinRequests.Count);
            foreach (TeamJoinRequest request in JoinRequests.ToArray())
            {
                request.Encode(stream);
            }

            stream.WriteVInt(DisabledBots.Count);
            foreach(int i in DisabledBots)
            {
                stream.WriteVInt(i);
            }

            stream.WriteBoolean(true);//enable chat
            stream.WriteBoolean(true);//Show Accessory
            stream.WriteBoolean(true);//Show Gears
            //stream.WriteBoolean(false);

            ByteStreamHelper.WriteIntList(stream, CustomModifiers);
        }
        
        public void EncodeAllianceTeamEntry(ByteStream stream)
        {
            stream.WriteVInt(Type);
            stream.WriteVInt(3);//MaxPlayer
            stream.WriteLong(Id);
            stream.WriteVInt(0);//?

            stream.WriteVInt(0);
            stream.WriteVInt(0);

            stream.WriteVInt(0);
            stream.WriteVInt(0);

            stream.WriteBoolean(false);
            stream.WriteBoolean(false);
            stream.WriteBoolean(false);

            stream.WriteVInt(Members.Count);
            foreach (TeamMember entry in Members.ToArray())
            {
                entry.Encode(stream);
            }

            ByteStreamHelper.WriteDataReference(stream, LocationId);
            stream.WriteVInt(0);
            stream.WriteBoolean(false);
        }
    }
}
