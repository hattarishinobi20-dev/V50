namespace Supercell.Laser.Logic.Avatar
{
    using Newtonsoft.Json;
    using Supercell.Laser.Titan.DataStream;
    using Supercell.Laser.Logic.Friends;
    using Supercell.Laser.Logic.Helper;
    using Supercell.Laser.Logic.Home;
    using Supercell.Laser.Logic.Home.Structures;
    using Supercell.Laser.Titan.DataStream;
    using Supercell.Laser.Titan.Debug;
    using System.IO;
    using Supercell.Laser.Logic.Data;
    using Supercell.Laser.Logic.Battle.Objects;
    using System.Numerics;
    using System.Security.Cryptography;
    using System.Security.Principal;
    using Supercell.Laser.Logic.Avatar.Structures;

    public enum AllianceRole
    {
        None = 0,
        Member = 1,
        Leader = 2,
        Elder = 3,
        CoLeader = 4
    }

    [JsonObject(MemberSerialization.OptIn)]
    public class ClientAvatar
    {
        [JsonProperty] public long AccountId;
        [JsonProperty] public string PassToken;

        [JsonProperty] private string _name;
        public string Name
        {
            get
            {
                string cleanName = _name.StartsWith("[VIP] ") ? _name.Substring(6) : _name;
                if (IsVIP && VIPExpire > DateTime.UtcNow)
                {
                    return "[VIP] " + cleanName;
                }
                return cleanName;
            }
            set
            {
                _name = value;
            }
        }
        [JsonProperty] public bool NameSetByUser;
        [JsonProperty] public int TutorialsCompletedCount = 2;

        [JsonIgnore] public HomeMode HomeMode;

        [JsonProperty] public int Gold;
        [JsonProperty] public int Diamonds;
        [JsonProperty] public string Password;

        [JsonProperty] public List<Hero> Heroes;

        [JsonProperty] public int TrioWins;
        [JsonProperty] public int DuoWins;
        [JsonProperty] public int SoloWins;

        [JsonProperty] public int Tokens;
        [JsonProperty] public int StarTokens;
        [JsonProperty] public int StarPoints;
        [JsonProperty] public int FamePoints;
        [JsonProperty] public int Blings;
        [JsonProperty] public int PowerPoints;
        [JsonProperty] public int RareTokens;

        // ��������� �������������� ����������
        [JsonProperty] public HashSet<string> RedeemedPromoCodes = new HashSet<string>();
        // ��������� ���������������� ������
        [JsonProperty] public List<int> UnlockedSkins = new List<int>();
        // ��������� ���������������� ������ (�����)
        [JsonProperty] public List<int> UnlockedEmotes = new List<int>();

        [JsonProperty] public bool IsDev;
        [JsonProperty] public bool IsPremium;
        [JsonProperty] public bool IsVIP { get; set; }
        [JsonProperty] public DateTime VIPExpire { get; set; }

        // Новые поля для системы банов
        [JsonProperty] public bool IsBanned;
        [JsonProperty] public string BanReason;
        [JsonProperty] public DateTime? BanUntil;

        // Новые поля для системы мута чата клуба
        [JsonProperty] public bool IsMutedInClub;
        [JsonProperty] public string MuteReasonInClub;
        [JsonProperty] public DateTime? MuteUntilInClub;

        [JsonProperty] public long AllianceId;
        [JsonProperty] public AllianceRole AllianceRole;

        [JsonProperty] public DateTime LastOnline;

        [JsonProperty] public List<Friend> Friends;
        [JsonProperty] public bool Banned;

        [JsonProperty] public int ChatBanCount;
        [JsonProperty] public int BanCount;
        [JsonProperty] public int BanType;
        [JsonProperty] public int BanID;
        [JsonProperty] public string TextReason;
        [JsonProperty] public DateTime BanEndTime;

        [JsonProperty] public DateTime PremiumTime;

        [JsonProperty] public List<string> ClaimedRewards;

        [JsonIgnore] public int PlayerStatus;
        [JsonIgnore] public long TeamId;

        [JsonIgnore] public long BattleId;
        [JsonIgnore] public long UdpSessionId;
        [JsonIgnore] public int TeamIndex;
        [JsonIgnore] public int OwnIndex;

        [JsonProperty] public int HighestTrophies;

        [JsonProperty] public int RollsSinceGoodDrop;

        [JsonProperty] public List<int> SPGS;
        [JsonProperty] public List<int> SelectedSPGS;

        [JsonProperty] public string Region;
        [JsonProperty] public int WinStreak;
        [JsonProperty] public int DoNotDisturb;
        [JsonProperty] public int DailyWins;
        [JsonProperty] public int MegaBoxesAwarded;
        [JsonProperty] public DateTime LastMegaBoxReset;
        [JsonProperty] public bool MegaBoxReady { get; set; }
        
        public int Trophies
        {
            get
            {
                int result = 0;
                foreach (Hero hero in Heroes.ToArray())
                {
                    result += hero.Trophies;
                }
                return result;
            }
        }

        public void AddTrophies(int t)
        {
            HighestTrophies = Math.Max(HighestTrophies, Trophies + t);
        }

        public int GetUnlockedBrawlersCountWithRarity(string rarity)
        {
            return Heroes.Count(x => x.CardData.Rarity == rarity);
        }

        public void ResetTrophies()
        {
            foreach (Hero hero in Heroes.ToArray())
            {
                hero.Trophies = 0;
                hero.HighestTrophies = 0;
            }
        }

        public int GetUnlockedHeroesCount()
        {
            return Heroes.Count;
        }

        public void UnlockHero(int characterId)
        {
            Hero heroEntry = new Hero(characterId);
            Heroes.Add(heroEntry);
        }

        public void UpgradeHero(int characterId)
        {
            Hero heroEntry = GetHero(characterId);
            if (heroEntry.SelectedOverChargeId == 0)
            {
                CardData o = heroEntry.GetDefaultMetaForHero(6);
                if (o != null) heroEntry.SelectedOverChargeId = o.GetInstanceId();
            }
        }

        public void RemoveHero(int characterId)
        {
            Heroes.RemoveAll(x => x.CharacterId == characterId);
        }

        public bool HasHero(int characterId)
        {
            return Heroes.Find(x => x.CharacterId == characterId) != null;
        }
        public Hero GetHero(int characterId)
        {
            return Heroes.Find(x => x.CharacterId == characterId);
        }
        public Hero GetHeroForCard(CardData cardData)
        {
            //Debugger.Print(DataTables.Get(16).GetData<CharacterData>(cardData.Target).GetInstanceId() + "");
            return GetHero(DataTables.Get(16).GetData<CharacterData>(cardData.Target).GetInstanceId() + 16000000);
        }


        public void SetEmoteForBrawler(int characterId, int slot, int pin)
        {
            Hero heroEntry = GetHero(characterId);
            heroEntry.emote[slot] = pin;
        }

        public bool UseDiamonds(int count)
        {
            if (count > Diamonds) return false;

            Diamonds -= count;
            return true;
        }

        public bool UseRareTokens(int count)
        {
            if (count > RareTokens) return false;

            RareTokens -= count;
            return true;
        }

        public bool UseBlings(int count)
        {
            if (count > Blings) return false;

            Blings -= count;
            return true;
        }

        public bool UseGold(int count)
        {
            if (count > Gold) return false;

            Gold -= count;
            return true;
        }

        public void AddDiamonds(int count)
        {
            Diamonds += count;
        }

        public void AddGold(int count)
        {
            Gold += count;
        }

        public bool UseTokens(int count)
        {
            if (count > Tokens) return false;

            Tokens -= count;
            return true;
        }

        public void AddTokens(int count)
        {
            HomeMode.Home.BrawlPassTokens += count;
        }

        public bool UseStarTokens(int count)
        {
            if (count > StarTokens) return false;

            StarTokens -= count;
            return true;
        }

        public void AddStarTokens(int count)
        {
            StarTokens += count;
        }

        public void AddPowerPoints(int count)
        {
            PowerPoints += count;
        }

        public void AddRareTokens(int count)
        {
            RareTokens += count;
        }

        public void AddFamePoints(int count)
        {
            FamePoints += count;
        }

        public void AddBlings(int count)
        {
            Blings += count;
        }

        public void UpdateProfileName()
        {
            // Этот метод может быть вызван при изменении VIP-статуса или при входе в профиль
            // Сначала очищаем имя от возможного префикса [VIP]
            string cleanName = _name.StartsWith("[VIP] ") ? _name.Substring(6) : _name;
            if (IsVIP && VIPExpire > DateTime.UtcNow)
            {
                // Добавляем префикс [VIP] только если статус активен
                _name = "[VIP] " + cleanName;
            }
            else
            {
                // Устанавливаем чистое имя без префикса
                _name = cleanName;
            }
        }

        public ClientAvatar()
        {
            Name = "Brawler";

            Gold = 100;
            Diamonds = 0;

            Heroes = new List<Hero>();

            ClaimedRewards = new List<string>();
            SPGS = new List<int>();
            SelectedSPGS = new List<int>();
            IsDev = false;
            IsPremium = false;
            Region = "RU";

            AllianceRole = AllianceRole.None;
            AllianceId = -1;

            LastOnline = DateTime.UtcNow;
            Friends = new List<Friend>();
            if (HighestTrophies == 0 && Trophies != 0)
            {
                HighestTrophies = Trophies;
            }
        }

        public void SkipTutorial()
        {
            TutorialsCompletedCount = 2;
        }

        public bool IsTutorialState()
        {
            return TutorialsCompletedCount < 2;
        }

        public Friend GetRequestFriendById(long id)
        {
            return Friends.Find(friend => friend.AccountId == id && friend.FriendState != 4);
        }

        public Friend GetAcceptedFriendById(long id)
        {
            return Friends.Find(friend => friend.AccountId == id && friend.FriendState == 4);
        }
        public EmoteData GetDefaultEmoteForCharacter(string Character, string Type)
        {
            foreach (EmoteData emoteData in DataTables.Get(DataType.Emote).GetDatas())
            {
                if (emoteData.Character == Character && emoteData.EmoteType == Type) return emoteData;
            }
            return null;
        }
        public Friend GetFriendById(long id)
        {
            return Friends.Find(friend => friend.AccountId == id);
        }
        public void Refresh()
        {
            for (int i = 0; ; i++)
            {
                CharacterData character = DataTables.Get(16).GetDataWithId<CharacterData>(i);
                if (character.Disabled && !character.LockedForChronos)
                {
                    RemoveHero(character.GetGlobalId());
                    continue;
                }
                if (!HasHero(16000000 + i))
                {
                    if (!character.IsHero()) break;
                    UnlockHero(character.GetGlobalId());
                }
            }
        }
        public int Checksum
        {
            get
            {
                ChecksumEncoder encoder = new ChecksumEncoder();
                Encode(encoder);
                return encoder.GetCheckSum();
            }
        }
        //64 vint 36 int 32 boolean
        //124 VInt 108 Int 104 Boolean
        public void Encode(ChecksumEncoder stream)
        {
            UpdateProfileName(); // Обновляем имя перед отправкой клиенту
            stream.WriteVLong(AccountId);
            stream.WriteVLong(AccountId);
            stream.WriteVLong(AccountId);
            stream.WriteString(Name); // Здесь используется свойство Name, которое уже включает [VIP], если статус активен
            stream.WriteBoolean(NameSetByUser);
            stream.WriteInt(-1);

            stream.WriteVInt(17);
            stream.WriteVInt(4 + Heroes.Count);//1
            {
                ByteStreamHelper.WriteDataReference(stream, 5000008);
                stream.WriteVInt(-1);
                stream.WriteVInt(Gold);

                ByteStreamHelper.WriteDataReference(stream, 5000021);
                stream.WriteVInt(-1);
                stream.WriteVInt(FamePoints); //fame

                ByteStreamHelper.WriteDataReference(stream, 5000022);
                stream.WriteVInt(-1);
                stream.WriteVInt(PowerPoints);

                ByteStreamHelper.WriteDataReference(stream, 5000023);
                stream.WriteVInt(-1);
                stream.WriteVInt(Blings);

                foreach (Hero hero in Heroes)
                {
                    ByteStreamHelper.WriteDataReference(stream, hero.CardData);
                    stream.WriteVInt(-1);
                    stream.WriteVInt(1);
                }
            }

            stream.WriteVInt(Heroes.Count);//2
            foreach (Hero hero in Heroes)
            {
                ByteStreamHelper.WriteDataReference(stream, hero.CharacterData);
                stream.WriteVInt(-1);
                stream.WriteVInt(hero.Trophies);
            }

            stream.WriteVInt(Heroes.Count);//3
            foreach (Hero hero in Heroes)
            {
                ByteStreamHelper.WriteDataReference(stream, hero.CharacterData);
                stream.WriteVInt(-1);
                stream.WriteVInt(hero.HighestTrophies);
            }

            stream.WriteVInt(Heroes.Count);//4
            foreach (Hero hero in Heroes)
            {
                ByteStreamHelper.WriteDataReference(stream, hero.CharacterData);
                stream.WriteVInt(-1);
                stream.WriteVInt(RandomNumberGenerator.GetInt32(4));
            }

            stream.WriteVInt(Heroes.Count);//5
            foreach (Hero hero in Heroes)
            {
                ByteStreamHelper.WriteDataReference(stream, hero.CharacterData);
                stream.WriteVInt(-1);
                stream.WriteVInt(hero.PowerPoints);
            }

            stream.WriteVInt(Heroes.Count);//6
            foreach (Hero hero in Heroes)
            {
                ByteStreamHelper.WriteDataReference(stream, hero.CharacterData);
                stream.WriteVInt(-1);
                stream.WriteVInt(hero.PowerLevel - 1);
            }

            stream.WriteVInt(SPGS.Count);//7
            foreach (int s in SPGS) 
            {
                ByteStreamHelper.WriteDataReference(stream, s);
                stream.WriteVInt(-1);
                stream.WriteVInt(SelectedSPGS.Contains(s) ? 2 : 1);//0 lock 1 unlock 2 chosen
            }

            
            stream.WriteVInt(0);//8
            stream.WriteVInt(0);//9
            stream.WriteVInt(0);//10
            stream.WriteVInt(0);//11
            stream.WriteVInt(0);//12
            stream.WriteVInt(0);//13
            stream.WriteVInt(0);//14
            stream.WriteVInt(0);//15
            stream.WriteVInt(0);//16(PowerPoints)
            stream.WriteVInt(0);//17

            stream.WriteVInt(Diamonds); // Diamonds
            stream.WriteVInt(0); // CumulativePurchasedDiamonds

            stream.WriteVInt(0);//player level
            stream.WriteVInt(0);
            stream.WriteVInt(0);//Cumulative
            stream.WriteVInt(1);//battle count
            stream.WriteVInt(0);
            stream.WriteVInt(0);
            stream.WriteVInt(0);
            stream.WriteVInt(0);
            stream.WriteVInt(0);
            stream.WriteVInt(2);//tutorial count
            stream.WriteVInt(19);//LogicDataTables::GetRankedRankDataByRank
            stream.WriteVInt(1000);//IsOldPlayer????
            stream.WriteVInt(15);//????
            stream.WriteString(null);
            stream.WriteVInt(0);
            stream.WriteVInt(0);
            stream.WriteVInt(1);





            //stream.WriteVLong(AccountId);
            //stream.WriteVLong(AccountId);
            //stream.WriteVLong(AccountId);


            //stream.WriteString("shit");
            //stream.WriteVInt(1);

            //stream.WriteInt(0);

            //stream.WriteVInt(8);
            //stream.WriteVInt(0);
            //stream.WriteVInt(0);
            //stream.WriteVInt(0);
            //stream.WriteVInt(0);
            //stream.WriteVInt(0);
            //stream.WriteVInt(0);
            //stream.WriteVInt(0);
            //stream.WriteVInt(0);


            //stream.WriteVInt(0);
            //stream.WriteVInt(0);

            //stream.WriteVInt(0);
            //stream.WriteVInt(0);
            //stream.WriteVInt(0);
            //stream.WriteVInt(0);
            //stream.WriteVInt(0);
            //stream.WriteVInt(0);
            //stream.WriteVInt(0);
            //stream.WriteVInt(0);
            //stream.WriteVInt(0);

            //stream.WriteVInt(2);
        }
        public void SetVIP(bool isVIP, DateTime expire)
        {
            IsVIP = isVIP;
            VIPExpire = expire;
            UpdateProfileName(); // Обновляем имя при изменении VIP-статуса
        }
    }

}
