﻿namespace Supercell.Laser.Logic.Avatar.Structures
{
    using Supercell.Laser.Titan.DataStream;

    public class PlayerDisplayData
    {
        public int ThumbnailId;
        public int NameColorId;
        public string Name;
        public int NameGradientId;

        public PlayerDisplayData()
        {
            ;
        }

        public PlayerDisplayData(int thumbnail, int namecolor, string name, int nameGradientId = 0)
        {
            ThumbnailId = thumbnail;
            NameColorId = namecolor;
            Name = name;
            NameGradientId = nameGradientId;
        }

        public void Encode(ByteStream stream)
        {
            stream.WriteString(Name);
            stream.WriteVInt(NameGradientId); // сериализация градиента
            stream.WriteVInt(ThumbnailId);
            stream.WriteVInt(NameColorId);
            stream.WriteVInt(-1);
        }
    }
}
